# 第三方来源

`firmware/components/m5stack_tab5`、`esp_lcd_st7121`、`esp_lvgl_port` 来自 M5Stack 官方 M5Tab5-UserDemo：
https://github.com/m5stack/M5Tab5-UserDemo

固定来源 commit：`b4e356bc491ca070d54004718dad789c07d5fc93`。
保留组件内的 SPDX、Apache-2.0 等许可标识及官方根目录 MIT 许可 `firmware/components/M5Stack-LICENSE`。
本项目移除了 ST7121 CMake 对示例专用 `package_manager` 的版本生成调用，其余驱动来源与后续修改应在此记录。

2026-09-24：`esp_lvgl_port/src/lvgl9/esp_lvgl_port_disp.c` 的横屏旋转改用 LVGL CPU 软件旋转，移除该显示路径的 PPA 客户端及阻塞式旋转。现场 JTAG 读取确认界面任务停在 PPA 完成信号量等待；保留原显示坐标转换和传输完成回调。此修复需要重新构建、刷入并验证长时间运行，CPU 占用与帧率也需真机评估。

摄像头预览新增的 `esp_video` 0.7.0、`esp_cam_sensor` 0.7.1、`esp_sccb_intf` 0.0.4 与 `esp_ipa` 0.1.0 也取自上述 M5Stack 官方示例快照。它们的组件目录保留各自的 `LICENSE` 和来源元数据；`esp_ipa` 包含 ESP32-P4 预编译库，适用许可详见其目录。设备代码仅启用示例中的 SC202CS/MIPI CSI 配置，硬件模组批次仍待真机核对。
摄像头时钟 BSP 调用改为返回 LEDC 实际初始化错误，以便设备在摄像头不可用时显示失败，而不是继续取帧。

2026-10-02：本地修改 `esp_video/src/esp_video.c` 与 `esp_video_ioctl.c`，支持停止状态下的 `VIDIOC_REQBUFS(count=0)`：清空队列、释放帧缓冲及信号量，不再创建替代缓冲。用于 ISP 持有设备引用时显式回收相机池；保留正在采集时拒绝释放的保护及原许可。相机调用方在显示解绑、停止采集和解除映射后请求释放。

BSP 音频配置的四处旧 `ES7120_SEL_MIC*` 名称改为 esp_codec_dev 1.6.2 的 `ES7210_SEL_MIC*`，修复依赖升级后的编译错误。首阶段尚未启用或验收音频功能。

ESP-IDF v5.4.2（Apache-2.0）、LVGL 9.2.2（MIT）、ESP-Hosted 1.4.0、esp_wifi_remote 0.8.5 等构建依赖由官方组件管理器获取，具体版本以 `firmware/dependencies.lock` 为准。发布时收集全部实际依赖许可，不能只分发裸二进制。

没有复制旧 ESP8266 项目的第三方宠物素材或图标。内置文字使用 LVGL 提供的字体。
# Noto Sans CJK font

`firmware/main/tab5_font_24.c` is a 24 px, 2 bpp subset of Noto Sans CJK SC Regular.
Copyright (c) 2014-2021 Adobe (http://www.adobe.com/). Licensed under SIL OFL 1.1;
the complete license is in `firmware/main/NotoSans-OFL.txt`.
Source: https://github.com/notofonts/noto-cjk/blob/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf
Source SHA-256: `2C76254F6FC379FDDFCE0A7E84FB5385BB135D3E399294F6EEB6680D0365B74B`.
Generated with official `lv_font_conv` 1.5.3; see `scripts/generate-font.py`.


30 px 中文字库 tab5_font_30.c 同样来自上述 Noto 字体，2 bpp；生成脚本为 scripts/generate-workbench-fonts.py。

# Montserrat digit fonts

tab5_digits_72.c / tab5_digits_96.c 为 LVGL 9.2.2 scripts/built_in_font/Montserrat-Medium.ttf 的数字子集，4 bpp。源 SHA-256：421F26B23E2BE6B98373D32ACD3CB2897B154D4BF0A77D26534CE476E4CBED53。
字体内嵌版权为 Copyright 2011 The Montserrat Project Authors (https://github.com/JulietaUla/Montserrat)，SIL OFL 1.1；完整许可见 firmware/main/Montserrat-OFL.txt。

SDK 显示诊断：scripts/apply-display-diagnostics.py 对 ESP-IDF 5.4.2 esp_lcd_panel_dpi.c 的 underrun 分支加入只读计数回调；保留原 Apache-2.0 许可和错误处理。

# 离线拼音词库与服务标识

`firmware/third_party/rime-pinyin-simp` 保存 Rime/Android 简体拼音词库、作者名单和 Apache-2.0 许可。固定来源版本、SHA-256 及生成规则见该目录的 `SOURCE.md`；生成的 `firmware/main/tab5_pinyin_dict.inc` 随源码保存。

服务标识的来源和使用边界见 `firmware/assets/brands/README.md`。这些标识属于各自权利人。
