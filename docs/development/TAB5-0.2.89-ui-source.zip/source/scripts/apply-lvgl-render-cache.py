"""Install narrow optional cache hooks; fail on an unknown LVGL source layout."""
from pathlib import Path
import sys

root=Path(sys.argv[1])/'managed_components/lvgl__lvgl/src/core'
changes={
    'lv_refr.c':[
        ('static void refr_area_part(lv_layer_t * layer)\n{',
         'bool (*tab5_lvgl_native_render)(lv_layer_t *) = NULL;\n'
         'static void refr_area_part(lv_layer_t * layer)\n{'),
        ('    /*If the screen is transparent initialize it when the flushing is ready*/',
         '    // TAB5_NATIVE_CACHE: keep the normal draw-buffer and DMA ownership path.\n'
         '    if(!disp_refr->prev_scr && tab5_lvgl_native_render && tab5_lvgl_native_render(layer)) {\n'
         '        draw_buf_flush(disp_refr);\n'
         '        LV_PROFILER_END;\n'
         '        return;\n'
         '    }\n'
         '    /*If the screen is transparent initialize it when the flushing is ready*/'),
        ('void lv_obj_redraw(lv_layer_t * layer, lv_obj_t * obj)\n{',
         '// TAB5_RENDER_CACHE_HOOKS\n'
         'bool (*tab5_lvgl_cache_ready)(const lv_obj_t *) = NULL;\n'
         'bool (*tab5_lvgl_cache_draw)(lv_layer_t *, lv_obj_t *) = NULL;\n'
         'void (*tab5_lvgl_cache_dirty)(const lv_obj_t *, const lv_area_t *) = NULL;\n\n'
         'void lv_obj_redraw(lv_layer_t * layer, lv_obj_t * obj)\n{\n'
         '    if(tab5_lvgl_cache_draw && tab5_lvgl_cache_draw(layer, obj)) return;'),
        ('    if(info.res == LV_COVER_RES_MASKED) return NULL;\n',
         '    if(info.res == LV_COVER_RES_MASKED) return NULL;\n'
         '    if(info.res == LV_COVER_RES_COVER && tab5_lvgl_cache_ready && tab5_lvgl_cache_ready(obj)) return obj;\n'),
    ],
    'lv_obj_pos.c':[
        ('void lv_obj_get_transformed_area(const lv_obj_t * obj, lv_area_t * area, lv_obj_point_transform_flag_t flags)\n{',
         'void lv_obj_get_transformed_area(const lv_obj_t * obj, lv_area_t * area, lv_obj_point_transform_flag_t flags)\n{\n'
         '    // TAB5_IDENTITY_DAMAGE: an identity transform must preserve inclusive bounds.\n'
         '    // The generic corner path conservatively adds one pixel on the right/bottom;\n'
         '    // that single pixel prevents opaque children from covering any scroll strip.\n'
         '#if !LV_DRAW_TRANSFORM_USE_MATRIX\n'
         '    const lv_obj_t * ancestor = obj;\n'
         '    while(ancestor) {\n'
         '        if(lv_obj_get_layer_type(ancestor) == LV_LAYER_TYPE_TRANSFORM) break;\n'
         '        if(!(flags & LV_OBJ_POINT_TRANSFORM_FLAG_RECURSIVE)) {ancestor = NULL; break;}\n'
         '        ancestor = lv_obj_get_parent(ancestor);\n'
         '    }\n'
         '    if(!ancestor) return;\n'
         '#endif'),
        ('void lv_obj_invalidate_area(const lv_obj_t * obj, const lv_area_t * area)\n{',
         'extern void (*tab5_lvgl_cache_dirty)(const lv_obj_t *, const lv_area_t *);\n'
         'void lv_obj_invalidate_area(const lv_obj_t * obj, const lv_area_t * area)\n{\n'
         '    if(tab5_lvgl_cache_dirty) tab5_lvgl_cache_dirty(obj, area);'),
    ],
}
for name,replacements in changes.items():
    path=root/name;text=path.read_text(encoding='utf-8');original=text
    # Upgrade the exact previous local hook; unrelated source layouts still fail.
    text=text.replace('(*tab5_lvgl_cache_dirty)(const lv_obj_t *)',
                      '(*tab5_lvgl_cache_dirty)(const lv_obj_t *, const lv_area_t *)')
    text=text.replace('tab5_lvgl_cache_dirty(obj);','tab5_lvgl_cache_dirty(obj, area);')
    for old,new in replacements:
        if new in text:continue
        if text.count(old)!=1:raise SystemExit(f'Unsupported cache hook source: {name}')
        text=text.replace(old,new,1)
    if text!=original:path.write_text(text,encoding='utf-8',newline='\n')
print('LVGL_RENDER_CACHE_HOOKS_OK')
