$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
if (-not ('Tab5ShortPath' -as [type])) {
    Add-Type 'using System; using System.Text; using System.Runtime.InteropServices; public static class Tab5ShortPath { [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern uint GetShortPathName(string p, StringBuilder b, uint n); }'
}
$shortBuffer = [System.Text.StringBuilder]::new(4096)
if ([Tab5ShortPath]::GetShortPathName($projectRoot, $shortBuffer, 4096) -eq 0) { throw 'Cannot resolve project path' }
$idfProjectRoot = $shortBuffer.ToString()
if ($idfProjectRoot.Contains(' ')) { throw 'ESP-IDF requires a path without spaces; Windows short paths are unavailable.' }
$env:IDF_PATH = Join-Path $idfProjectRoot '.tools\esp-idf'
$env:IDF_TOOLS_PATH = Join-Path $idfProjectRoot '.tools\idf-tools'
$env:IDF_TARGET = 'esp32p4'
$env:ESP_IDF_VERSION = '5.4'
