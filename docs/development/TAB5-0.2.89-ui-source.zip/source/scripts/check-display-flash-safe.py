"""Check the built scanout ISR chain, not only Kconfig/source annotations."""
import argparse,json,re,subprocess
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('elf',type=Path);p.add_argument('--objdump',type=Path,required=True)
p.add_argument('--output',type=Path);a=p.parse_args()
roots=['dma_trans_done_cb','lvgl_port_camera_refresh_callback','tab5_lcd_frame_tick',
       'tab5_lcd_underrun','dw_gdma_channel_enable_ctrl','dw_gdma_channel_use_link_list',
       'dw_gdma_link_list_get_item','dw_gdma_lli_set_block_markers','dw_gdma_channel_default_isr',
       'tab5_flash_guard_begin','tab5_flash_guard_end','crash_record_checkpoint']
table=subprocess.check_output([str(a.objdump),'-t',str(a.elf)],text=True)
symbols={}
for line in table.splitlines():
    fields=line.split()
    if len(fields)>=6 and fields[-1] in roots:
        symbols[fields[-1]]=dict(address=fields[0],section=fields[-3])
for name in roots:
    assert name in symbols and symbols[name]['section']=='.iram0.text',(name,symbols.get(name))
    body=subprocess.check_output([str(a.objdump),'-d','--disassemble='+name,str(a.elf)],text=True)
    calls=[]
    for line in body.splitlines():
        if not re.search(r'\b(?:jal|jalr|j)\b',line):continue
        m=re.search(r'(?:#\s*)?([0-9a-f]{8})\s+<([^>]+)>',line)
        if not m:continue # indirect user callback is checked on registration
        address=int(m[1],16)
        assert not 0x40000000<=address<0x48000000,(name,'flash call',line)
        calls.append(m[2])
    symbols[name]['calls']=sorted(set(calls))
result={'passed':True,'symbols':symbols}
if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('DISPLAY_FLASH_SAFE_ELF_PASS: scanout ISR and helpers in IRAM; no direct flash calls')
