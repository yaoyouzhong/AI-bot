"""Allow pinned IDF 5.4.2 JPEG descriptors to use the reserved DMA heap.

esp_psram_extram_reserve_dma_pool deliberately omits MALLOC_CAP_DEFAULT.
Descriptor storage must also cover the whole cache range synced by the driver.
Keep general codec allocations, image buffers and cache synchronization intact.
"""
from pathlib import Path
import sys

OLD = 'heap_caps_aligned_calloc(alignment, 1, sizeof(dma2d_descriptor_t), MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL | JPEG_MEM_ALLOC_CAPS)'
NEW = 'heap_caps_aligned_calloc(alignment, 1, dma_desc_mem_size, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT)'
MARKER = '    // TAB5: DMA reserve excludes DEFAULT; allocate the entire synced cache line.\n'

def patch(source: str) -> str:
    if source.count(NEW) == 2 and OLD not in source and source.count(MARKER) == 1:
        return source
    if source.count(OLD) != 2 or NEW in source or MARKER in source:
        raise RuntimeError('Unknown JPEG encoder descriptor allocation; inspect SDK before patching')
    anchor = '    encoder_engine->rxlink = (dma2d_descriptor_t*)' + OLD
    if source.count(anchor) != 1:
        raise RuntimeError('JPEG encoder allocation anchor not found')
    return source.replace(anchor, MARKER + anchor).replace(OLD, NEW)

if __name__ == '__main__':
    file = Path(sys.argv[1])/'components/esp_driver_jpeg/jpeg_encode.c'
    source = file.read_text(encoding='utf-8')
    updated = patch(source)
    if updated != source:
        file.write_text(updated, encoding='utf-8')
    print('TAB5 JPEG DMA reserve and descriptor size patch ready')
