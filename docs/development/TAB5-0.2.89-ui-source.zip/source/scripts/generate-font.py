"""Regenerate the vendored LVGL font using local Noto Sans CJK and lv_font_conv 1.5.3."""
from pathlib import Path
import hashlib
import subprocess

root = Path(__file__).resolve().parents[1]
font = root / '.tools/font-builder/NotoSansCJKsc-Regular.otf'
expected = '2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b'
if hashlib.sha256(font.read_bytes()).hexdigest() != expected:
    raise SystemExit('Unexpected source font; verify provenance before regenerating.')
chars = set(chr(x) for x in range(32, 127))
for a in range(0xa1, 0xf8):
    for b in range(0xa1, 0xff):
        try:
            chars.add(bytes([a, b]).decode('gb2312'))
        except UnicodeDecodeError:
            pass
chars.update('·℃→')
chars.update('¥€£—•')  # Reply amounts and ordinary Unicode punctuation beyond GB2312.
chars.update('\u00a0\u2010\u2011\u2012\u2013\u202f\u2212')
subprocess.run([
    'node', str(root / '.tools/font-builder/node_modules/lv_font_conv/lv_font_conv.js'),
    '--font', str(font), '--symbols', ''.join(sorted(chars)), '--size', '24',
    '--format', 'lvgl', '--bpp', '2', '--no-compress', '--no-kerning',
    '--lv-include', 'lvgl.h', '--lv-font-name', 'tab5_font_24',
    '-o', str(root / 'firmware/main/tab5_font_24.c')
], check=True)
print(f'Generated {len(chars)} glyphs.')
