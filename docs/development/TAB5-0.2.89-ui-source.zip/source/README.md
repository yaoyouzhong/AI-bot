# AI-bot TAB5 客户端

独立的 M5Stack TAB5 触屏客户端，与原 ESP8266 小屏共用 AI-bot 电脑桥接程序。

本工程自有代码采用 [MIT License](LICENSE)，版权属于姚有忠；与合并后的 AI-bot 项目统一许可。第三方组件、字体、词库及服务标识保留各自许可与权利，见 [第三方来源](THIRD_PARTY_NOTICES.md)。

Own code is MIT licensed, copyright 2026 姚有忠, matching the merged AI-bot project. Third-party components and marks retain their original terms.

当前源码与现场版本 **0.2.89-ui**，配套桥接在原目录运行，启动核验通过。本轮设置布局、相机循环、语音光标与断线文字回收、附件回执查询等已按项验收，原自动轮播已恢复；具体范围见相邻 [AI-bot 验收记录](../AI-bot/docs/ACCEPTANCE-2026-10-02.md)。USB 升级中断原因按用户要求暂缓定位，实体键盘、双设备隔离及其他环境仍待验收，不称为全量通过。历史测速保留在[性能记录](docs/TRANSPORT-PERFORMANCE-070.md)。

历史功能状态见 [0.2.52 收尾清单](docs/CLOSEOUT-052.md)。0.2.52 的固件更新仅支持 Wi-Fi / USB；0.2.65 重新加入绑定所选通道的 BLE OTA，生产代码故障测试通过，真实 BLE 升级和速率仍待验收。

后续工作台与分区迁移进展见 [工作台记录](docs/WORKBENCH-NEXT.md)，显示优化见 [滚动性能记录](docs/SCROLL-PERFORMANCE.md)。[验收记录](docs/ACCEPTANCE.md) 及以下版本段落是早期阶段记录；各功能最新验证边界以对应专题文档为准，代码存在不代表已完成真机验收。

历史：0.2.39 曾增加 USB / BLE 固件更新和双向 Codex 请求，合并屏幕与声音设置并修复轮播状态。首次安装与验证边界见 [三通道 RPC 记录](docs/TRANSPORT-RPC-039.md)。

## 早期开发记录

2026-09-23：首版 USB、Wi-Fi、BLE 的真实数据显示和手动模式已通过设备反馈确认。0.2.0-dev 继续迁入十个平台的额度/余额与重置时间、桌宠、音乐封面和进度、网速曲线、农历时钟、独立轮播及屏保；范围见 [功能迁移表](docs/FEATURE-MIGRATION.md)，验证程度见验收记录。语音已加入大疆优先、TAB5 回退的开发源码及模拟验证，尚未部署或进行真实识别验收，详见 [双音源语音输入](docs/VOICE-INPUT.md)。

2026-09-24：新增 [Codex 任务入口](docs/CODEX-REMOTE.md)、[摄像头本机预览](docs/CAMERA.md) 和 [OTA 无线升级源码](docs/OTA.md)。摄像头画面、照片送入任务、无线升级、真实豆包转写及 macOS 桥接仍需分别验收或实现；当前固件与电脑桥接的开发构建不等于已部署版本。

0.2.1-dev 已加入九页图形布局、等比居中桌宠、节气和节假日信息，以及三款可保存选择的表盘。网络配色沿用原小屏的黄色上传、绿色下载。设计与数据年份范围见 [布局说明](docs/UI-DESIGN.md)。网易云音乐当前未向 Windows 上报时间线，未知时长明确显示待提供。

0.2.2-dev 重排总览和模型额度页：Codex 按套餐显示限制，PRO 金色描边，独立重置卡到期列表及真实每日用量图。时钟直接点击表盘循环切换并保存。

0.2.3-dev 总览只显示 Codex，增加美股/港股/A股三列、网络纵轴、重置卡票券和 PAYG 余额/消费双卡；修复日额度漏记及心跳引起的走时跳动。采样口径和真机验证边界见验收记录。

0.2.4-dev 总览右侧可勾选 Codex/DeepSeek/智谱，默认三项；农历与节气单行合并。时钟提供四款指针表盘及一款纯数字，新增低背光移动屏保。天气卡片重排，并接通真实 AQI 和带类型的气压数值。

## 目录

- `firmware/`：ESP-IDF 5.4.2、LVGL 9.2.2、官方 TAB5 BSP（ST7121/ST7123 自动识别）。
- `scripts/`：项目内工具链安装、构建和本地测试。
- `tests/`：实际 C 通道状态机测试。
- `docs/PROTOCOL.md`：USB/Wi-Fi/BLE 协议和配对边界。
- 电脑端改动位于相邻 `AI-bot/windows-app/AIBotBridge/Tab5*.cs`，在原托盘 App 中集成。

## 构建

新设备 USB 首次安装、原固件备份与恢复见 [首次安装指南](docs/FIRST-INSTALL.md)。Windows 桥接入口为“TAB5 连接 → USB 配对 → 新设备首次安装”；目前为本地候选功能，尚待出厂设备完整验收。已有 AI-bot 固件继续使用 [OTA 升级](docs/OTA.md)。

需要 Windows、PowerShell 7、Git、Python 3.12；本地 C 测试还需要 MSVC Build Tools。首次在项目 `.tools/esp-idf` 克隆官方 ESP-IDF **v5.4.2**（包含 submodule），然后运行：

```powershell
git clone --branch v5.4.2 --recursive https://github.com/espressif/esp-idf.git .tools/esp-idf
pwsh -File scripts/setup-idf.ps1
pwsh -File scripts/build.ps1
pwsh -File scripts/test-link-state.ps1
```

首次构建会按 `firmware/dependencies.lock` 下载组件，再应用本项目补丁。后续构建复用本地依赖。默认构建不烧录设备；`scripts/start-bridge.ps1` 是本机候选桥接的启动辅助脚本，其 `.tools` 中的程序不随本仓库分发。

完整 LVGL 预览和显示/相机测试会编译使用 GNU C 扩展的 SDK 代码，需要 Visual Studio 的 LLVM/Clang 组件。使用 `pwsh -File scripts/preview-ui.ps1 -Clang` 构建并运行预览；单项测试程序生成在 `.tools/ui-preview-clang64/`。不带 `-Clang` 的 MSVC 路径目前不能编译完整测试集。

工具安装到本项目 `.tools/idf-tools`，不修改系统 PATH。Windows 使用现有 Python 3.12，C 状态机测试使用现有 MSVC Build Tools。
设备烧录前应核对芯片和 USB 身份、备份原闪存；该动作会替换 UIFlow2 应用。

## 首次连接

1. 安装本项目 TAB5 固件与包含 TAB5 支持的电脑桥接候选版本。
2. 使用 USB-C 数据线连接电脑，桥接托盘菜单选择“设备连接 → TAB5 连接”。
3. 选择设备并点击“通过 USB 配对”。
4. 同一窗口可将 Wi-Fi 名称和密码通过 USB 写入设备。密码不会写入电脑项目文件。
5. TAB5 的“设置”页选择自动、仅 USB、仅 Wi-Fi 或仅蓝牙。顶部显示实际有效数据通道。

配对密钥位于电脑用户配置的 DPAPI 文件和 TAB5 NVS。备份闪存可能包含设备配置，`.local/` 不得提交或发布。

## 发布

公共电脑桥接继续由 AI-bot 仓库发布；TAB5 固件使用独立版本与发布入口。每次 TAB5 发布记录最低桥接版本、协议版本、P4 固件与 C6 无线固件的验证组合、SHA-256 和真机验证范围。
源码上传、固件标签和 GitHub Release 分别处理。构建产物、工具链、设备备份及凭据不提交；源码构建与模拟测试结果不替代三通道及交互功能的真机验收。
