// Compile the actual viewport body with a deterministic display-port facade.
// Real LVGL snapshots and the real compositor produce every pixel under test.
#undef NDEBUG
#include "lvgl.h"
#include "src/core/lv_obj_private.h"
#include "src/core/lv_obj_draw_private.h"
#include "camera_compositor.h"
#include <assert.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SW 1280u
#define SH 720u
#define DW 720u
#define DH 1280u
#define BYTES ((size_t)SW*SH*2)
#define MALLOC_CAP_SPIRAM 1
#define MALLOC_CAP_8BIT 2

typedef struct { void *raw; uint8_t *ptr; size_t size; } allocation;
static allocation allocations[8];
static unsigned allocation_calls, fail_allocation, live_allocations;
static unsigned begin_calls, back_calls, present_calls, end_calls, delays;
static unsigned check_count;
static bool begin_ok=true, back_ok=true, present_ok=true, end_ok=true, port_active;
static uint16_t *framebuffers[2], *source_pixels, *render_pixels, *expected;
static unsigned front_index;
static lv_display_t *fixture_display;
static lv_obj_t *fixture_canvas, *fixture_shutter, *fixture_close;
static int64_t fake_time;

static void *allocate(size_t size,size_t align) {
    allocation_calls++;
    if(fail_allocation==allocation_calls)return NULL;
    unsigned slot=0;while(slot<8 && allocations[slot].raw)slot++;
    assert(slot<8 && align && !(align&(align-1)));
    uint8_t *raw=malloc(size+align+32);assert(raw);
    uintptr_t aligned=((uintptr_t)(raw+16)+align-1)&~(uintptr_t)(align-1);
    uint8_t *ptr=(uint8_t *)aligned;
    memset(ptr-16,0xa5,16);memset(ptr+size,0xa5,16);
    allocations[slot]=(allocation){raw,ptr,size};live_allocations++;
    return ptr;
}
static void *heap_caps_aligned_alloc(size_t align,size_t size,unsigned caps) {
    assert(caps==(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));return allocate(size,align);
}
static void *heap_caps_malloc(size_t size,unsigned caps) {
    assert(caps==(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));return allocate(size,16);
}
static void tracked_free(void *ptr) {
    if(!ptr)return;
    unsigned slot=0;while(slot<8 && allocations[slot].ptr!=ptr)slot++;
    assert(slot<8);
    allocation *a=&allocations[slot];
    for(unsigned i=0;i<16;i++) {assert(a->ptr[(int)i-16]==0xa5);assert(a->ptr[a->size+i]==0xa5);}
    free(a->raw);memset(a,0,sizeof(*a));live_allocations--;
}
static int64_t esp_timer_get_time(void) { fake_time+=2300;return fake_time; }
static void vTaskDelay(unsigned ticks) { assert(ticks==1);delays++;fake_time+=1000; }
static bool lvgl_port_camera_begin(lv_display_t *d) {
    assert(d==fixture_display);begin_calls++;port_active=true;
    return begin_ok;
}
static uint16_t *lvgl_port_camera_back_buffer(lv_display_t *d) {
    assert(d==fixture_display && port_active);back_calls++;
    return back_ok?framebuffers[1-front_index]:NULL;
}
static bool lvgl_port_camera_present(lv_display_t *d,unsigned timeout) {
    assert(d==fixture_display && port_active && timeout==250);present_calls++;
    if(present_ok)front_index=1-front_index;
    return present_ok;
}
static bool lvgl_port_camera_end(lv_display_t *d,unsigned timeout) {
    assert(d==fixture_display && timeout==250);end_calls++;
    if(end_ok)port_active=false;
    return end_ok;
}

#define free tracked_free
#include "camera_viewport_under_test.inc"
#undef free

static void flush(lv_display_t *d,const lv_area_t *a,uint8_t *pixels) {
    (void)a;(void)pixels;lv_display_flush_ready(d);
}
static lv_obj_t *plain(lv_obj_t *parent,int x,int y,int w,int h) {
    lv_obj_t *o=lv_obj_create(parent);lv_obj_remove_style_all(o);
    lv_obj_set_pos(o,x,y);lv_obj_set_size(o,w,h);
    lv_obj_remove_flag(o,LV_OBJ_FLAG_SCROLLABLE);return o;
}
static lv_obj_t *caption(lv_obj_t *parent,const char *value,int x,int y) {
    lv_obj_t *o=lv_label_create(parent);lv_obj_remove_style_all(o);
    lv_label_set_text(o,value);lv_obj_set_pos(o,x,y);
    lv_obj_set_style_text_font(o,&lv_font_montserrat_24,0);
    lv_obj_set_style_text_color(o,lv_color_hex(0xf1f7ff),0);return o;
}
static void fixtures(void) {
    lv_obj_t *screen=lv_screen_active();lv_obj_remove_style_all(screen);
    lv_obj_set_style_bg_opa(screen,LV_OPA_COVER,0);
    fixture_canvas=lv_canvas_create(screen);
    lv_canvas_set_buffer(fixture_canvas,source_pixels,SW,SH,LV_COLOR_FORMAT_RGB565);
    lv_obj_set_pos(fixture_canvas,0,0);
    fixture_shutter=plain(screen,0,208,188,304);
    lv_obj_set_style_opa(fixture_shutter,LV_OPA_40,LV_STATE_DISABLED);
    lv_obj_t *ring=plain(fixture_shutter,30,64,128,128);
    lv_obj_set_style_radius(ring,LV_RADIUS_CIRCLE,0);
    lv_obj_set_style_border_width(ring,4,0);
    lv_obj_set_style_border_color(ring,lv_color_hex(0xf1f7ff),0);
    lv_obj_t *disc=plain(fixture_shutter,42,76,104,104);
    lv_obj_set_style_radius(disc,LV_RADIUS_CIRCLE,0);
    lv_obj_set_style_bg_color(disc,lv_color_hex(0xf1f7ff),0);
    lv_obj_set_style_bg_opa(disc,LV_OPA_COVER,0);
    caption(fixture_shutter,"Shoot",54,218);
    fixture_close=plain(screen,1104,16,148,56);
    lv_obj_set_style_radius(fixture_close,14,0);
    lv_obj_set_style_bg_opa(fixture_close,LV_OPA_60,0);
    lv_obj_set_style_bg_color(fixture_close,lv_color_hex(0x324654),0);
    lv_obj_set_style_bg_color(fixture_close,lv_color_hex(0xff0033),LV_STATE_DISABLED);
    caption(fixture_close,"Close",35,14);
    camera_viewport_set_controls(fixture_shutter,fixture_close);
}
static void oracle(void) {
    // LVGL renders its own flattened widget sprites over the actual camera
    // source. Its native rotation is an independent oracle for the viewport.
    lv_obj_t *widgets[]={fixture_shutter,fixture_close}, *images[2];
    lv_draw_buf_t *snapshots[2];
    for(unsigned i=0;i<2;i++) {
        lv_obj_remove_flag(widgets[i],LV_OBJ_FLAG_HIDDEN);
        lv_obj_remove_state(widgets[i],LV_STATE_ANY);lv_obj_update_layout(widgets[i]);
        lv_area_t a;lv_obj_get_coords(widgets[i],&a);
        int ext=lv_obj_get_ext_draw_size(widgets[i]);
        snapshots[i]=lv_snapshot_take(widgets[i],LV_COLOR_FORMAT_ARGB8888);assert(snapshots[i]);
        lv_obj_add_flag(widgets[i],LV_OBJ_FLAG_HIDDEN);
        images[i]=lv_image_create(lv_screen_active());
        lv_image_set_src(images[i],snapshots[i]);lv_obj_set_pos(images[i],a.x1-ext,a.y1-ext);
    }
    lv_obj_invalidate(lv_screen_active());lv_refr_now(fixture_display);
    lv_draw_sw_rotate(render_pixels,expected,SW,SH,SW*2,DW*2,
                      LV_DISPLAY_ROTATION_90,LV_COLOR_FORMAT_RGB565);
    for(unsigned i=0;i<2;i++) {lv_obj_delete(images[i]);lv_draw_buf_destroy(snapshots[i]);}
    lv_obj_add_flag(fixture_shutter,LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_state(fixture_shutter,LV_STATE_DISABLED|LV_STATE_PRESSED);
    lv_obj_remove_flag(fixture_close,LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_state(fixture_close,LV_STATE_DISABLED|LV_STATE_FOCUSED|LV_STATE_FOCUS_KEY);
}
static void states_restored(void) {
    assert(lv_obj_has_flag(fixture_shutter,LV_OBJ_FLAG_HIDDEN));
    assert(lv_obj_get_state(fixture_shutter)==(LV_STATE_DISABLED|LV_STATE_PRESSED));
    assert(!lv_obj_has_flag(fixture_close,LV_OBJ_FLAG_HIDDEN));
    assert(lv_obj_get_state(fixture_close)==(LV_STATE_DISABLED|LV_STATE_FOCUSED|LV_STATE_FOCUS_KEY));
}
static void reset_facade(void) {
    assert(!live_allocations && !port_active);
    allocation_calls=fail_allocation=begin_calls=back_calls=present_calls=end_calls=delays=0;
    begin_ok=back_ok=present_ok=end_ok=true;
    front_index=0;memset(framebuffers[0],0x5a,BYTES);memset(framebuffers[1],0xa5,BYTES);
}
static void diagnostics(unsigned count,unsigned mode) {
    unsigned n,c,p,m;camera_viewport_diagnostics(&n,&c,&p,&m);
    assert(n==count && m==mode);
    if(n)assert(c>0 && p>0);
}
static void successful_session(void) {
    reset_facade();assert(camera_viewport_begin(fixture_canvas)==1);
    assert(live_allocations==2 && allocation_calls==4 && begin_calls==1);
    states_restored();diagnostics(0,1);
    assert(camera_viewport_begin(fixture_canvas)==-1);
    assert(camera_viewport_frame(source_pixels,NULL,NULL));
    assert(!memcmp(framebuffers[front_index],expected,BYTES));
    assert(front_index==1 && present_calls==1 && delays>0);diagnostics(1,1);
    assert(camera_viewport_frame(source_pixels,NULL,NULL));
    assert(front_index==0 && present_calls==2);
    assert(!memcmp(framebuffers[front_index],expected,BYTES));diagnostics(2,1);
    assert(camera_viewport_end());assert(!live_allocations && !port_active);
    assert(end_calls==1);assert(camera_viewport_end());assert(end_calls==1);
    assert(!camera_viewport_frame(source_pixels,NULL,NULL));diagnostics(2,0);
    states_restored();check_count++;
}
typedef struct { unsigned calls, stop; } cancellation;
static bool keep_frame(void *context) {
    cancellation *c=context;return ++c->calls<c->stop;
}
static void cancellation_sessions(void) {
    unsigned stops[]={1,20,40,41};
    for(unsigned i=0;i<sizeof(stops)/sizeof(stops[0]);i++) {
        reset_facade();assert(camera_viewport_begin(fixture_canvas)==1);
        cancellation c={0,stops[i]};
        assert(!camera_viewport_frame(source_pixels,keep_frame,&c));
        assert(c.calls==stops[i] && !present_calls && front_index==0);
        for(size_t j=0;j<BYTES/2;j++)assert(framebuffers[front_index][j]==0x5a5a);
        diagnostics(0,1);assert(camera_viewport_end());assert(!live_allocations);check_count++;
    }
}
static void allocation_failures(void) {
    for(unsigned fail=1;fail<=4;fail++) {
        reset_facade();fail_allocation=fail;
        assert(camera_viewport_begin(fixture_canvas)==0);
        assert(!live_allocations && !begin_calls && !port_active);
        assert(!camera_viewport_frame(source_pixels,NULL,NULL));
        states_restored();assert(camera_viewport_end());diagnostics(0,0);check_count++;
    }
    reset_facade();assert(camera_viewport_begin(NULL)==0);assert(!allocation_calls);
    camera_viewport_set_controls(fixture_shutter,NULL);
    assert(camera_viewport_begin(fixture_canvas)==0);assert(!live_allocations && !begin_calls);
    camera_viewport_set_controls(fixture_shutter,fixture_close);states_restored();check_count++;
}
static void port_failures(void) {
    reset_facade();begin_ok=false;
    assert(camera_viewport_begin(fixture_canvas)==0);
    assert(begin_calls==1 && end_calls==1 && !live_allocations && !port_active);
    diagnostics(0,0);check_count++;

    reset_facade();begin_ok=false;end_ok=false;
    assert(camera_viewport_begin(fixture_canvas)==-1);
    assert(port_active && begin_calls==1 && end_calls==1);diagnostics(0,2);
    assert(camera_viewport_begin(fixture_canvas)==-1);assert(begin_calls==1);
    assert(!camera_viewport_end());assert(port_active);
    end_ok=true;assert(camera_viewport_end());assert(!port_active && !live_allocations);
    diagnostics(0,0);check_count++;

    reset_facade();assert(camera_viewport_begin(fixture_canvas)==1);back_ok=false;
    assert(!camera_viewport_frame(source_pixels,NULL,NULL));assert(!present_calls && back_calls==1);
    assert(camera_viewport_end());assert(!live_allocations);check_count++;

    reset_facade();assert(camera_viewport_begin(fixture_canvas)==1);present_ok=false;
    assert(!camera_viewport_frame(source_pixels,NULL,NULL));assert(present_calls==1 && front_index==0);
    diagnostics(0,2);assert(camera_viewport_end());assert(!live_allocations);check_count++;

    reset_facade();assert(camera_viewport_begin(fixture_canvas)==1);end_ok=false;
    assert(!camera_viewport_end());assert(port_active);diagnostics(0,2);
    assert(camera_viewport_begin(fixture_canvas)==-1);
    end_ok=true;assert(camera_viewport_end());assert(!port_active && !live_allocations);
    check_count++;
}
int main(void) {
    lv_init();source_pixels=malloc(BYTES);render_pixels=malloc(BYTES);expected=malloc(BYTES);
    framebuffers[0]=malloc(BYTES);framebuffers[1]=malloc(BYTES);
    assert(source_pixels && render_pixels && expected && framebuffers[0] && framebuffers[1]);
    for(unsigned y=0;y<SH;y++)for(unsigned x=0;x<SW;x++)
        source_pixels[(size_t)y*SW+x]=(uint16_t)(((x+y*7)&31)<<11|((x*3+y)&63)<<5|((x*13+y*3)&31));
    fixture_display=lv_display_create(SW,SH);assert(fixture_display);
    lv_display_set_color_format(fixture_display,LV_COLOR_FORMAT_RGB565);
    lv_display_set_buffers(fixture_display,render_pixels,NULL,BYTES,LV_DISPLAY_RENDER_MODE_FULL);
    lv_display_set_flush_cb(fixture_display,flush);
    fixtures();oracle();successful_session();allocation_failures();cancellation_sessions();port_failures();
    // Retake reopens after every failure, rebuilding snapshots without leaks.
    for(unsigned i=0;i<3;i++)successful_session();
    assert(!live_allocations);lv_display_delete(fixture_display);lv_deinit();
    free(framebuffers[0]);free(framebuffers[1]);free(expected);free(render_pixels);free(source_pixels);
    printf("CAMERA_VIEWPORT_PASS: %u sessions; actual snapshots, exact frame pixels, state restoration, allocation and port failures, cancellation, repeat open/close\n",check_count);
    return 0;
}
