// Execute the actual camera task against an ownership-checking V4L2 mock and
// real LVGL canvas. This tests buffer lifetime, not sensor/interrupt throughput.
#undef NDEBUG
#include "camera_preview.h"
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RTC_NOINIT_ATTR
typedef int (*vprintf_like_t)(const char *,va_list);
typedef void *TaskHandle_t;
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(p) ((void)(p))
#define portEXIT_CRITICAL(p) ((void)(p))
static TaskHandle_t mock_task=(void *)1;
static bool mock_isr;
static bool xPortInIsrContext(void){return mock_isr;}
static TaskHandle_t xTaskGetCurrentTaskHandle(void){return mock_task;}
static char forwarded_log[256];
static int log_sink(const char *format,va_list args){return vsnprintf(forwarded_log,sizeof(forwarded_log),format,args);}
static vprintf_like_t installed_log=log_sink;
static vprintf_like_t esp_log_set_vprintf(vprintf_like_t cb){vprintf_like_t old=installed_log;installed_log=cb;return old;}
static void test_log(const char *format,...){va_list args;va_start(args,format);installed_log(format,args);va_end(args);}
#define ESP_OK 0
#define ESP_LOGE(...) ((void)0)
#define MALLOC_CAP_INTERNAL 1
#define MALLOC_CAP_8BIT 2
#define MALLOC_CAP_SPIRAM 4
#define O_RDONLY 0
#define PROT_READ 1
#define PROT_WRITE 2
#define MAP_SHARED 1
#define pdPASS 1
#define pdMS_TO_TICKS(x) (x)
#define ESP_VIDEO_MIPI_CSI_DEVICE_NAME "mock-camera"
#define V4L2_BUF_TYPE_VIDEO_CAPTURE 1
#define V4L2_MEMORY_MMAP 1
#define V4L2_PIX_FMT_RGB565 565
enum {VIDIOC_G_FMT=1,VIDIOC_S_FMT,VIDIOC_REQBUFS,VIDIOC_QUERYBUF,VIDIOC_QBUF,
      VIDIOC_STREAMON,VIDIOC_STREAMOFF,VIDIOC_DQBUF_TIMEOUT};
struct v4l2_format {int type;struct {struct {unsigned width,height,pixelformat,bytesperline;} pix;} fmt;};
struct v4l2_requestbuffers {unsigned count;int type,memory;};
struct v4l2_buffer {unsigned index,length,bytesused;int type,memory;union {unsigned offset;} m;};
typedef struct {unsigned timeout_ms;struct v4l2_buffer buffer;} esp_video_dqbuf_timeout_t;
typedef struct {struct {bool init_sccb;void *i2c_handle;unsigned freq;} sccb_config;int reset_pin,pwdn_pin;} esp_video_init_csi_config_t;
typedef struct {esp_video_init_csi_config_t *csi;void *dvp,*jpeg;} esp_video_init_config_t;
enum {NORMAL,STOP,FAIL_DQ,FAIL_QBUF,FAIL_MAP,BAD_STRIDE,FAIL_START,FAIL_REQBUFS,LOW_MEMORY,FAIL_PRESENT,FAIL_RESTORE};
static bool use_direct,direct_active;
static const uint16_t *presented_source;
static unsigned direct_presented;
static int scenario;
static lv_obj_t *canvas;
static void (*scheduled_task)(void *);
static uint8_t *buffers[3];
static bool queued[3],streaming_mock,locked;
static unsigned delivered,returned,unmapped,closed,frame_copies,last_pixel;
static int64_t mock_time;
static const size_t frame_bytes=1280*720*2;
static uint8_t *canvas_pixels(void) {
    lv_draw_buf_t *b=lv_canvas_get_draw_buf(canvas);return b?b->data:NULL;
}
static bool canvas_uses_driver(void) {
    for(unsigned i=0;i<3;i++)if(buffers[i]&&canvas_pixels()==buffers[i])return true;
    return false;
}
static void verify_display_is_owned(void) {
    for(unsigned i=0;i<3;i++)if(buffers[i]&&canvas_pixels()==buffers[i])assert(!queued[i]);
}
static unsigned heap_caps_get_free_size(int caps){(void)caps;return scenario==LOW_MEMORY?8192:131072;}
static unsigned heap_caps_get_largest_free_block(int caps){return heap_caps_get_free_size(caps);}
static void *heap_caps_malloc(size_t size,int caps){(void)caps;return malloc(size);}
static int bsp_cam_osc_init(void){return ESP_OK;}
static void *bsp_i2c_get_handle(void){return NULL;}
static int esp_video_init(const esp_video_init_config_t *c){assert(c->csi);return ESP_OK;}
static int64_t esp_timer_get_time(void){return ++mock_time;}
static void bsp_display_lock(int timeout){(void)timeout;assert(!locked);verify_display_is_owned();locked=true;}
static void bsp_display_unlock(void){assert(locked);verify_display_is_owned();locked=false;}
static int xTaskCreatePinnedToCoreWithCaps(void (*task)(void *),const char *name,unsigned stack,void *arg,
                                         unsigned priority,void *handle,int core,unsigned caps) {
    (void)name;(void)stack;(void)arg;(void)priority;(void)handle;(void)caps;assert(core==0);
    if(scenario==FAIL_START)return 0;scheduled_task=task;return pdPASS;
}
static void vTaskDeleteWithCaps(void *task){(void)task;assert(!locked&&!streaming_mock);}
static void vTaskDelay(unsigned ticks) {
    (void)ticks;
    if(!streaming_mock)return;
    if(scenario==STOP&&delivered==4)camera_preview_stop();
    else if(delivered==8){assert(camera_preview_capture());assert(!camera_preview_capture());}
}
static int mock_open(const char *name,int flags){(void)flags;assert(!strcmp(name,ESP_VIDEO_MIPI_CSI_DEVICE_NAME));return 10;}
static int mock_ioctl(int fd,int request,void *arg) {
    assert(fd==10);
    switch(request) {
    case VIDIOC_G_FMT:{struct v4l2_format *f=arg;f->fmt.pix.width=1280;f->fmt.pix.height=720;
        f->fmt.pix.pixelformat=V4L2_PIX_FMT_RGB565;f->fmt.pix.bytesperline=scenario==BAD_STRIDE?2564:0;return 0;}
    case VIDIOC_S_FMT:return 0;
    case VIDIOC_REQBUFS:{struct v4l2_requestbuffers *r=arg;
        if(r->count==0) {
            assert(!streaming_mock&&!canvas_uses_driver()&&!direct_active);
            for(unsigned i=0;i<3;i++){free(buffers[i]);buffers[i]=NULL;queued[i]=false;}
            return 0;
        }
        assert(r->count==3);
        for(unsigned i=0;i<3;i++) {
            buffers[i]=malloc(frame_bytes);assert(buffers[i]);
            if(scenario==FAIL_REQBUFS){errno=ENOMEM;return -1;}
        }return 0;}
    case VIDIOC_QUERYBUF:{struct v4l2_buffer *b=arg;assert(b->index<3);b->length=(unsigned)frame_bytes;b->m.offset=b->index;return 0;}
    case VIDIOC_QBUF:{struct v4l2_buffer *b=arg;unsigned i=b->index;assert(i<3&&!queued[i]);
        // A displayed frame cannot be offered back to DMA, even during retake.
        assert(canvas_pixels()!=buffers[i]);
        if(scenario==FAIL_QBUF&&delivered==4){errno=EIO;return -1;}
        queued[i]=true;returned++;return 0;}
    case VIDIOC_STREAMON:streaming_mock=true;return 0;
    case VIDIOC_STREAMOFF:assert(!canvas_uses_driver());streaming_mock=false;return 0;
    case VIDIOC_DQBUF_TIMEOUT:{
        assert(streaming_mock&&!locked);verify_display_is_owned();
        if(scenario==FAIL_DQ&&delivered==4){errno=EIO;return -1;}
        // With the real driver's backup disabled, a completed buffer cannot
        // be delivered until another driver-owned buffer takes over capture.
        unsigned driver_owned=0;for(unsigned i=0;i<3;i++)if(queued[i])driver_owned++;
        assert(driver_owned>=2);
        unsigned chosen=3;
        for(unsigned offset=0;offset<3;offset++){unsigned i=(delivered+offset)%3;if(queued[i]){chosen=i;break;}}
        assert(chosen<3&&canvas_pixels()!=buffers[chosen]);queued[chosen]=false;
        delivered++;last_pixel=delivered;memset(buffers[chosen],(int)last_pixel,frame_bytes);
        assert(frame_copies==0); // No full-frame copy anywhere in the live loop.
        esp_video_dqbuf_timeout_t *r=arg;r->buffer.index=chosen;r->buffer.bytesused=(unsigned)frame_bytes;return 0;
    }
    default:assert(!"Unexpected camera ioctl");return -1;
    }
}
static void *mock_mmap(void *address,size_t length,int prot,int flags,int fd,unsigned offset) {
    (void)address;(void)prot;(void)flags;assert(fd==10&&length==frame_bytes&&offset<3);
    if(scenario==FAIL_MAP&&offset==1)return NULL;return buffers[offset];
}
static int mock_munmap(void *address,size_t length) {
    assert(!streaming_mock&&canvas_pixels()!=address&&length==frame_bytes);unmapped++;
    memset(address,0xdd,length);return 0;
}
static int mock_close(int fd) {
    assert(fd==10&&!canvas_uses_driver()&&!streaming_mock);closed++;
    // The real ISP retains a reference. close must not be relied on to free
    // its pool: every successful/failing capture must already have released it.
    for(unsigned i=0;i<3;i++)assert(!buffers[i]);return 0;
}
static void observe_frame_copy(uint16_t *out,const uint8_t *source,size_t stride) {
    assert(!locked);
    assert(use_direct?(const uint8_t *)presented_source==source:canvas_pixels()==source);frame_copies++;
    camera_frame_view(out,source,stride);
}
static int camera_viewport_begin(lv_obj_t *c) {
    assert(locked&&c==canvas&&!direct_active);direct_active=use_direct;return use_direct?1:0;
}
static bool camera_viewport_frame(const uint16_t *source,bool (*keep)(void *),void *ctx) {
    assert(direct_active&&!locked&&!canvas_uses_driver());assert(keep(ctx));
    bool owned=false;
    for(unsigned i=0;i<3;i++)if(source==(uint16_t *)buffers[i]){owned=true;assert(!queued[i]);}
    assert(owned);
    if(scenario==FAIL_PRESENT&&delivered==4)return false;
    presented_source=source;direct_presented++;return true;
}
static bool camera_viewport_end(void) {
    assert(locked&&direct_active&&!canvas_uses_driver());direct_active=false;return scenario!=FAIL_RESTORE;
}
static void camera_viewport_diagnostics(unsigned *a,unsigned *b,unsigned *c,unsigned *d) {
    *a=direct_presented;*b=*c=0;*d=direct_active;
}
#define open mock_open
#define ioctl mock_ioctl
#define mmap mock_mmap
#define munmap mock_munmap
#define close mock_close
#define camera_frame_view observe_frame_copy
#include "camera_preview_under_test.inc"
#undef camera_frame_view

int main(void) {
    camera_preview_init_diagnostics();camera_log_task=mock_task;
    test_log("I (10) csi: starting %d",1);assert(!driver_error[0]);
    mock_task=(void *)2;test_log("E (11) other: excluded");assert(!driver_error[0]);mock_task=(void *)1;
    mock_isr=true;test_log("E (12) ISR: excluded");assert(!driver_error[0]);mock_isr=false;
    test_log("E (13) tab5_camera: summary excluded");assert(!driver_error[0]);
    test_log("\033[0;31mE (14) csi: resource %d unavailable\033[0m",19);
    assert(strstr(driver_error,"resource 19 unavailable"));
    char first[160];snprintf(first,sizeof(first),"%s",driver_error);
    test_log("E (15) video: outer error");assert(!strcmp(driver_error,first)&&strstr(forwarded_log,"outer error"));
    char hex[320];camera_preview_driver_error_hex(hex,sizeof(hex));assert(strlen(hex)==strlen(first)*2);
    for(unsigned i=0;i<strlen(first);i++){unsigned byte;assert(sscanf(hex+i*2,"%2x",&byte)==1&&byte==(unsigned char)first[i]);}
    char bounded[4]={'X','X','X','Z'};camera_preview_driver_error_hex(bounded,3);assert(bounded[2]==0&&bounded[3]=='Z');
    camera_log_task=NULL;
    puts("CAMERA_LOG_OK first_driver_error_task_isolation_forwarding_bounded_hex");
    lv_init();lv_display_create(1280,720);
    for(unsigned pipeline=0;pipeline<2;pipeline++) {
    use_direct=pipeline!=0;
    for(int mode=NORMAL;mode<=(use_direct?FAIL_RESTORE:LOW_MEMORY);mode++) {
        // Reopen the successful session twice with the same still allocation.
        for(unsigned run=0;run<(mode==NORMAL?2u:1u);run++) {
            scenario=mode;delivered=returned=unmapped=closed=frame_copies=last_pixel=direct_presented=0;
            direct_active=false;presented_source=NULL;
            canvas=lv_canvas_create(lv_screen_active());scheduled_task=NULL;
            if(mode==FAIL_START){assert(!camera_preview_start(canvas)&&!camera_preview_busy());lv_obj_delete(canvas);continue;}
            assert(camera_preview_start(canvas)&&scheduled_task);assert(!camera_preview_start(canvas));
            scheduled_task(NULL);assert(!camera_preview_busy());
            if(mode==NORMAL) {
                assert(camera_preview_get_state()==CAMERA_PREVIEW_CAPTURED&&delivered==9);
                assert(frame_copies==1&&unmapped==3&&closed==1);
                const uint8_t *copy=camera_preview_acquire();assert(copy&&camera_preview_busy());
                assert(!camera_preview_acquire()&&!camera_preview_start(canvas));
                // DMA storage was poisoned and freed; preview and attachment
                // must still contain the same captured frame, not freed memory.
                for(size_t i=0;i<frame_bytes;i++)assert(copy[i]==last_pixel&&canvas_pixels()[i]==last_pixel);
                camera_preview_stop();assert(camera_preview_busy());
                camera_preview_release(copy);assert(!camera_preview_busy());
                assert(camera_preview_acquire()==copy);camera_preview_release(copy);
            } else if(mode==STOP) {
                assert(camera_preview_get_state()==CAMERA_PREVIEW_OFF&&delivered==4&&frame_copies==1);
            } else {
                assert(camera_preview_get_state()==CAMERA_PREVIEW_ERROR);
                assert(frame_copies==((mode==FAIL_DQ||mode==FAIL_QBUF||mode==FAIL_PRESENT||mode==FAIL_RESTORE)?1u:0u));
            }
            if(mode!=NORMAL)assert(!camera_preview_acquire()&&!camera_preview_busy());
            lv_obj_delete(canvas);assert(!locked&&!streaming_mock);
        }
    }
    }
    free(still_pixels);
    puts("CAMERA_OWNERSHIP_OK: no live copies; retain until replacement; still survives unmap; retake, stop and faults safe");
    return 0;
}
