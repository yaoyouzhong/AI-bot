import importlib.util
from pathlib import Path
import struct
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('migration',Path(__file__).resolve().parents[1]/'scripts/migrate-ota.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def table(parts):
    data=b''.join(struct.pack('<HBBII16sI',0x50aa,*values[:2],*values[2:],name.encode(),0) for name,values in parts.items())
    return data.ljust(4096,b'\xff')

class MigrationTests(unittest.TestCase):
    def bundle(self,root):
        backup=root/'backup.bin';raw=bytearray(b'\xff'*m.FLASH_SIZE)
        raw[0x8000:0x9000]=table(m.OLD)
        raw[0x9000:0x10000]=b'P'*0x7000
        raw[0xb00000:0xd00000]=b'A'*0x200000;backup.write_bytes(raw)
        build=root/'build';(build/'bootloader').mkdir(parents=True);(build/'partition_table').mkdir()
        (build/'bootloader/bootloader.bin').write_bytes(b'B'*0x5ae0)
        (build/'partition_table/partition-table.bin').write_bytes(table(m.NEW))
        image=bytearray(6451456);image[0]=0xe9;image[80:91]=b'aibot_tab5\0'
        (build/'aibot_tab5.bin').write_bytes(image)
        bundle=root/'bundle';m.prepare(backup,build,bundle);return bundle,backup

    def test_preservation_and_write_order(self):
        with tempfile.TemporaryDirectory() as d:
            bundle,backup=self.bundle(Path(d));commands=[]
            m.install(bundle,'MOCK',lambda *args:commands.append(args))
            self.assertEqual((bundle/'nvs-phy.bin').read_bytes(),b'P'*0x7000)
            self.assertEqual((bundle/'assets.bin').read_bytes(),b'A'*0x200000)
            self.assertEqual(commands[0][1],'verify_flash')
            self.assertEqual(commands[1][2],'0xe00000')
            self.assertEqual(commands[2][1],'verify_flash')
            self.assertEqual(commands[3][2],'0x20000')
            for command in commands:
                if command[1] in ('write_flash','erase_region'):
                    self.assertNotIn('0x9000',command)
                    self.assertNotIn('erase_flash',command)
            self.assertEqual(backup.stat().st_size,m.FLASH_SIZE)

    def test_tamper_and_preflight_failure_write_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            bundle,_=self.bundle(Path(d));calls=[]
            def fail(*args):calls.append(args);raise RuntimeError('wrong live device')
            with self.assertRaises(RuntimeError):m.install(bundle,'MOCK',fail)
            self.assertEqual(len(calls),1)
            self.assertFalse((bundle/'installed.json').exists())
            (bundle/'application.bin').write_bytes(b'wrong')
            with self.assertRaises(ValueError):m.install(bundle,'MOCK',lambda *args:calls.append(args))
            self.assertEqual(len(calls),1)

    def test_copy_verification_failure_prevents_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            bundle,_=self.bundle(Path(d));calls=[]
            def fail(*args):
                calls.append(args)
                if len(calls)==3:raise RuntimeError('asset copy verification failed')
            with self.assertRaises(RuntimeError):m.install(bundle,'MOCK',fail)
            self.assertEqual(len(calls),3)
            self.assertNotIn('0x20000',calls[-1])

if __name__=='__main__':unittest.main()
