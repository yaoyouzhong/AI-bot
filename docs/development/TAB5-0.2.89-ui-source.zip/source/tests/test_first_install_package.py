"""Host-only tests for credential-free first-install packages."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('package_first_install', Path(__file__).resolve().parents[1] / 'scripts/package-first-install.py')
package = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package)


def esp_image(application=False):
    payload = bytearray(256 if application else 32)
    if application:
        struct.pack_into('<I', payload, 0, 0xabcd5432)
        payload[16:25] = b'test-1.0\0'
        payload[48:59] = b'aibot_tab5\0'
    data = bytearray(24)
    data[0], data[1], data[12], data[23] = 0xe9, 1, 18, 1
    data += struct.pack('<II', 0x40000000, len(payload)) + payload
    checksum = 0xef
    for value in payload:
        checksum ^= value
    data += bytes(((len(data) | 15) + 1) - len(data))
    data[-1] = checksum
    return data + hashlib.sha256(data).digest()


class FirstInstallPackageTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='tab5-package-test-')
        self.root = Path(self.temp.name)
        self.original_root, package.ROOT = package.ROOT, self.root
        self.build = self.root / 'build'
        partition = bytearray()
        for name, values in package.PARTITIONS.items():
            partition += struct.pack('<HBBII16sI', 0x50aa, *values, name.encode(), 0)
        partition += b'\xeb\xeb' + b'\xff' * 14 + hashlib.md5(partition).digest()
        partition += b'\xff' * (3072 - len(partition))
        for (_, name, _, _), data in zip(package.FILES, [esp_image(), partition, b'\xff' * 8192, esp_image(True)]):
            path = self.build / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        (self.build / 'private-device-backup.bin').write_bytes(b'synthetic private data')
        self.output = self.root / 'install.zip'

    def tearDown(self):
        package.ROOT = self.original_root
        self.temp.cleanup()

    def test_only_reviewed_outputs_are_in_full_image(self):
        manifest = package.package(self.build, self.output)
        with zipfile.ZipFile(self.output) as archive:
            image = archive.read('factory.bin')
            self.assertEqual(json.loads(archive.read('manifest.json')), manifest)
            self.assertEqual(len(image), 16 * 1024 * 1024)
            self.assertEqual(manifest['version'], 'test-1.0')
            self.assertEqual(package.sha(image), manifest['imageSha256'])
            cursor = 0
            for segment in manifest['segments']:
                start, size = segment['offset'], segment['size']
                self.assertEqual(image[cursor:start], b'\xff' * (start - cursor))
                self.assertEqual(package.sha(image[start:start + size]), segment['sha256'])
                cursor = start + size
            self.assertEqual(image[cursor:], b'\xff' * (len(image) - cursor))
            self.assertNotIn('private-device-backup.bin', archive.namelist())
        self.assertTrue(self.output.with_suffix('.zip.sha256').read_text().startswith(package.sha(self.output.read_bytes())))

    def test_refuses_overwrite(self):
        self.output.write_bytes(b'keep existing file')
        with self.assertRaises(ValueError):
            package.package(self.build, self.output)
        self.assertEqual(self.output.read_bytes(), b'keep existing file')

    def test_corrupt_images_never_leave_zip(self):
        target = self.build / 'aibot_tab5.bin'
        data = bytearray(target.read_bytes())
        for offset in (12, 48, len(data) - 1):
            bad = data.copy()
            bad[offset] ^= 1
            target.write_bytes(bad)
            with self.assertRaises(ValueError):
                package.package(self.build, self.output)
            self.assertFalse(self.output.exists())

    def test_existing_ota_data_is_rejected(self):
        (self.build / 'ota_data_initial.bin').write_bytes(b'\x00' * 8192)
        with self.assertRaises(ValueError):
            package.package(self.build, self.output)

    def test_partition_checksum_and_layout(self):
        original = bytearray((self.build / 'partition_table/partition-table.bin').read_bytes())
        for address in (4, 194, 208, 224):
            data = original.copy()
            data[address] ^= 1
            with self.assertRaises(ValueError):
                package.validate_partitions(data)


if __name__ == '__main__':
    unittest.main()
