// Native fault-injection tests against the actual vendored function bodies.
// The runner extracts those functions; only the hardware/RTOS contracts are mocked.
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef int esp_err_t;
#define ESP_OK 0
#define ESP_FAIL -1
#define ESP_ERR_NO_MEM 257
#define ESP_ERR_INVALID_ARG 258
#define ESP_ERR_INVALID_STATE 259
#define ESP_LOGE(...) ((void)0)
#define ESP_LOGD(...) ((void)0)
#define TAG "test"
#define LEDC_TIMER_1_BIT 1
#define LEDC_TIMER_12_BIT 12
#define LEDC_LOW_SPEED_MODE 0
#define LEDC_AUTO_CLK 0
#define LEDC_USE_PLL_DIV_CLK 80
#define LEDC_TIMER_0 0
#define LEDC_TIMER_1 1
#define LEDC_CHANNEL_0 0
#define LCD_LEDC_CH 1
#define BSP_LCD_BACKLIGHT 22
#define LEDC_INTR_DISABLE 0
#define LEDC_SLEEP_MODE_KEEP_ALIVE 2
#define LEDC_SLEEP_MODE_NO_ALIVE_NO_PD 0
#define ESP_ERROR_CHECK(expr) assert((expr)==ESP_OK)
typedef struct {int duty_resolution,freq_hz,speed_mode;bool deconfigure;int clk_cfg,timer_num;} ledc_timer_config_t;
typedef struct {int gpio_num,speed_mode,channel,intr_type,timer_sel,duty,hpoint,sleep_mode;struct {unsigned output_invert:1;} flags;} ledc_channel_config_t;
static ledc_timer_config_t timers[2];
static ledc_channel_config_t channels[2];
static bool fail_timer;
static unsigned channel_writes;
static int source_clock;
static int ledc_timer_config(const ledc_timer_config_t *c) {
    if(fail_timer)return ESP_FAIL;
    // P4's global clock mux is shared: IDF rejects a different source while
    // another timer has acquired it. AUTO tries XTAL before PLL_F80M.
    int wanted=c->clk_cfg?c->clk_cfg:((uint64_t)c->freq_hz*(UINT64_C(1)<<c->duty_resolution)<=40000000?40:80);
    if(source_clock&&source_clock!=wanted&&timers[1-c->timer_num].freq_hz)return ESP_FAIL;
    source_clock=wanted;timers[c->timer_num]=*c;return ESP_OK;
}
static int ledc_channel_config(const ledc_channel_config_t *c) {channels[c->channel]=*c;channel_writes++;return ESP_OK;}

struct list_head {void *first;};
struct esp_video_buffer_info {unsigned size,align_size,caps,count,memory_type;};
struct esp_video_buffer {int id;};
struct v4l2_format {uint32_t type;struct {struct {uint32_t width,height,pixelformat;} pix;} fmt;};
struct v4l2_requestbuffers {uint32_t count,type,memory;};
#define V4L2_MEMORY_MMAP 1
#define V4L2_MEMORY_USERPTR 2
struct esp_video_stream {bool started;void *ready_sem;struct esp_video_buffer *buffer;struct esp_video_buffer_info buf_info;struct list_head queued_list,done_list;struct v4l2_format format;};
struct esp_video;
struct video_ops {int (*init)(struct esp_video *);int (*set_format)(struct esp_video *,const struct v4l2_format *);};
struct esp_video {const char *dev_name;unsigned reference,caps;int mutex,stream_lock;struct video_ops *ops;struct esp_video_stream *stream;struct esp_video *node;};
static struct {struct esp_video *first;} s_video_list;
static int s_video_lock, lock_depth, fail_init, init_calls, destroyed;
static struct esp_video_stream *observed_stream;
#define V4L2_CAP_VIDEO_M2M 0x100
#define portMAX_DELAY UINT_MAX
#define SLIST_FOREACH(v,h,n) for((v)=(h)->first;(v);(v)=(v)->n)
#define SLIST_INIT(h) ((h)->first=NULL)
#define portMUX_INITIALIZE(p) (*(p)=0)
#define portENTER_CRITICAL_SAFE(p) ((void)(p))
#define portEXIT_CRITICAL_SAFE(p) ((void)(p))
#define CHECK_VIDEO_OBJ(v) assert(v)
#define CHECK_PARAM(condition,err,...) do {if(!(condition))return (err);} while(0)
static void _lock_acquire(int *p){(void)p;}
static void _lock_release(int *p){(void)p;}
static void xSemaphoreTake(int m,unsigned t){(void)t;assert(m==123);lock_depth++;}
static void xSemaphoreGive(int m){assert(m==123&&lock_depth>0);lock_depth--;}
static void vSemaphoreDelete(void *p){assert(p);free(p);}
static void *xSemaphoreCreateCounting(unsigned count,unsigned initial){assert(count==2&&initial==0);return malloc(1);}
static struct esp_video_stream *esp_video_get_stream(struct esp_video *v,unsigned type){return type==1?v->stream:NULL;}
static void esp_video_buffer_destroy(struct esp_video_buffer *p){assert(!observed_stream->queued_list.first&&!observed_stream->done_list.first);free(p);destroyed++;}
static struct esp_video_buffer *esp_video_buffer_create(struct esp_video_buffer_info *i){assert(i->count==2);return calloc(1,sizeof(struct esp_video_buffer));}
static int initialize(struct esp_video *v){(void)v;init_calls++;return fail_init?ESP_ERR_NO_MEM:ESP_OK;}
static int set_format(struct esp_video *v,const struct v4l2_format *fmt){(void)v;assert(fmt->type==1&&fmt->fmt.pix.width==1280&&fmt->fmt.pix.height==720);return ESP_OK;}

#include "camera_driver_under_test.inc"

int main(void) {
    // Reproduce the hardware constraint missed by the earlier independent-
    // timer mock: AUTO backlight selects XTAL, camera then needs PLL_F80M.
    ledc_timer_config_t old_backlight={.freq_hz=5000,.duty_resolution=12,.timer_num=0};
    assert(ledc_timer_config(&old_backlight)==ESP_OK);
    assert(bsp_cam_osc_init()==ESP_FAIL);
    memset(timers,0,sizeof(timers));source_clock=0;
    // Opening camera must preserve the already running backlight timer/channel.
    assert(bsp_display_brightness_init()==ESP_OK);
    channels[1].duty=3071;
    for(int i=0;i<20;i++)assert(bsp_cam_osc_init()==ESP_OK);
    assert(timers[0].freq_hz==5000&&timers[0].duty_resolution==12);
    assert(channels[1].timer_sel==0&&channels[1].duty==3071);
    assert(timers[1].freq_hz==24000000&&channels[0].timer_sel==1);
    assert(source_clock==80&&timers[0].clk_cfg==LEDC_USE_PLL_DIV_CLK&&timers[1].clk_cfg==LEDC_USE_PLL_DIV_CLK);
    assert(channels[0].flags.output_invert==0);
    fail_timer=true;unsigned before=channel_writes;
    assert(bsp_cam_osc_init()==ESP_FAIL&&channel_writes==before);

    struct esp_video_stream stream={0};struct video_ops ops={.init=initialize,.set_format=set_format};
    struct esp_video device={.dev_name="camera",.mutex=123,.ops=&ops,.stream=&stream};
    s_video_list.first=&device;
    fail_init=true;
    // An allocation failure must return NULL, release the lock and roll back the
    // reference count. A subsequent open must actually initialize again.
    for(int i=0;i<20;i++)assert(esp_video_open("camera")==NULL&&device.reference==0&&lock_depth==0);
    fail_init=false;assert(esp_video_open("camera")==&device&&device.reference==1&&lock_depth==0);
    assert(init_calls==21);
    assert(esp_video_open("camera")==&device&&device.reference==2&&init_calls==21);

    // CSI's initial cached format has dimensions and pixels but type==0.
    // Query -> change pixels -> set -> query must keep the capture selector.
    stream.format.fmt.pix.width=1280;stream.format.fmt.pix.height=720;
    struct v4l2_format fmt={.type=1};
    assert(esp_video_get_format(&device,&fmt)==ESP_OK&&fmt.type==1);
    fmt.fmt.pix.pixelformat=565;
    assert(esp_video_set_format(&device,&fmt)==ESP_OK);
    assert(esp_video_get_format(&device,&fmt)==ESP_OK&&fmt.type==1&&fmt.fmt.pix.pixelformat==565);
    fmt.type=0;assert(esp_video_get_format(&device,&fmt)==ESP_ERR_INVALID_ARG);

    observed_stream=&stream;stream.buf_info=(struct esp_video_buffer_info){.size=1024,.align_size=64,.caps=1};
    assert(esp_video_setup_buffer(&device,1,1,2)==ESP_OK);
    for(int i=0;i<20;i++) {
        stream.queued_list.first=stream.buffer;stream.done_list.first=stream.buffer;
        assert(esp_video_setup_buffer(&device,1,1,2)==ESP_OK);
        assert(!stream.queued_list.first&&!stream.done_list.first&&stream.ready_sem);
    }
    assert(destroyed==20);
    stream.started=true;void *current=stream.buffer;
    assert(esp_video_setup_buffer(&device,1,1,2)==ESP_ERR_INVALID_STATE&&stream.buffer==current&&destroyed==20);
    // ISP's extra reference survives a preview close. Explicit release must
    // reclaim the entire stopped pool, with no replacement semaphore/buffers.
    struct v4l2_requestbuffers release={.count=0,.type=1,.memory=V4L2_MEMORY_MMAP};
    assert(esp_video_ioctl_reqbufs(&device,&release)==ESP_ERR_INVALID_STATE&&stream.buffer==current);
    stream.started=false;
    for(int i=0;i<20;i++) {
        stream.queued_list.first=stream.buffer;stream.done_list.first=stream.buffer;
        assert(esp_video_ioctl_reqbufs(&device,&release)==ESP_OK);
        assert(!stream.buffer&&!stream.ready_sem&&!stream.queued_list.first&&!stream.done_list.first);
        assert(device.reference==2&&stream.buf_info.count==0);
        assert(esp_video_ioctl_reqbufs(&device,&release)==ESP_OK); // idempotent
        assert(esp_video_setup_buffer(&device,1,1,2)==ESP_OK);
    }
    assert(esp_video_ioctl_reqbufs(&device,&release)==ESP_OK);
    puts("CAMERA_DRIVER_TEST_OK: shared clock, format roundtrip, allocation failure, warm reopen, streaming guard");
    return 0;
}
