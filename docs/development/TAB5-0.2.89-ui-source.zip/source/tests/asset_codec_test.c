#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
uint32_t asset_crc32(const uint8_t *, size_t);
bool asset_unpack(const uint8_t *, size_t, uint8_t *, size_t);
int main(void) {
    uint8_t encoded[] = {3, 0, 0x34, 0x12, 1, 0, 0xff, 0xff};
    uint8_t expected[] = {0x34, 0x12, 0x34, 0x12, 0x34, 0x12, 0xff, 0xff};
    uint8_t out[10] = {0};
    out[8] = 0x77;
    out[9] = 0x88;
    assert(asset_crc32((const uint8_t *)"123456789", 9) == 0xcbf43926);
    assert(asset_unpack(encoded, sizeof(encoded), out, 8));
    assert(!memcmp(out, expected, 8));
    assert(out[8] == 0x77 && out[9] == 0x88);
    assert(!asset_unpack(encoded, 7, out, 8));  // truncated pair
    assert(!asset_unpack(encoded, 8, out, 6));  // overflow
    assert(!asset_unpack(encoded, 8, out, 10)); // underfill
    assert(!asset_unpack(encoded, 8, out, 7));  // partial pixel
    encoded[0] = 0;
    assert(!asset_unpack(encoded, 8, out, 8));
    encoded[0] = 255;
    encoded[1] = 255;
    assert(!asset_unpack(encoded, 8, out, 8));
    puts("ASSET_CODEC_OK exact pixels, CRC, truncation, zero runs, bounds");
    return 0;
}
