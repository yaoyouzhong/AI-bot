using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Text.Json;
using AIBotBridge;
static class Program {
 [STAThread] static void Main(string[] args){ApplicationConfiguration.Initialize();Application.Run(new Check(args.Length>0?args[0]:"COM8"));}
}
sealed class Check:Form {
 readonly TextBox draft=new(){Multiline=true,Dock=DockStyle.Fill,Font=new Font("Microsoft YaHei UI",15),ImeMode=ImeMode.On};
 readonly Label status=new(){Dock=DockStyle.Top,Height=65,Text="先在输入框选择豆包输入法。开始后对大疆说一句话，再点结束；文字只留在本窗口。"};
 readonly Button start=new(){Text="开始录音",Dock=DockStyle.Bottom,Height=46};
 readonly Button finish=new(){Text="结束录音",Dock=DockStyle.Bottom,Height=46,Enabled=false};
 readonly System.Windows.Forms.Timer limit=new(){Interval=60000};
 readonly List<object> events=new();readonly Hook callback; nint hook;bool running;bool deviceAck;bool finishAck;string finishFailure="";
 readonly string port;readonly string report=Path.Combine(AppContext.BaseDirectory,"result.json");
 public Check(string port){this.port=port;Text="TAB5 大疆与豆包语音验证";ClientSize=new Size(670,340);Controls.Add(draft);Controls.Add(status);Controls.Add(finish);Controls.Add(start);callback=Observe;hook=SetWindowsHookEx(13,callback,GetModuleHandle(null),0);start.Click+=async(_,_)=>await Run();finish.Click+=async(_,_)=>await Finish();limit.Tick+=async(_,_)=>{limit.Stop();if(running)await Finish();};}
 bool Trigger(){
  using var serial=new SerialPort(port,460800){ReadTimeout=400,WriteTimeout=2000,DtrEnable=false,RtsEnable=false};
  serial.Open();serial.DiscardInBuffer();serial.Write("@AIBOT {\"version\":1,\"type\":\"tab5_hid_toggle\"}\n");
  bool ack=false;long deadline=Environment.TickCount64+2000;
  while(Environment.TickCount64<deadline&&!ack){
   try{ack=serial.ReadLine().Contains("tab5_hid_probe_start",StringComparison.Ordinal);}
   catch(TimeoutException){}
  }
  // Keep the CDC handle open until the device has begun its USB detach.
  if(ack)Thread.Sleep(450);
  return ack;
 }
 async Task Run(){
  start.Enabled=false;draft.Focus();await Task.Delay(1000);
  string ime=Tab5InputMethod.CurrentName();
  if(GetForegroundWindow()!=Handle||!draft.Focused||!Tab5InputMethod.IsDoubao(ime)){status.Text="请先在此输入框切换到豆包输入法，再重试。当前："+ime;start.Enabled=true;return;}
  events.Clear();deviceAck=false;finishAck=false;finishFailure="";running=true;status.Text="正在启动豆包，约 3 秒后对大疆说话。";
  try{
   deviceAck=Trigger();if(!deviceAck)throw new InvalidOperationException("未收到设备启动回执");
   await Task.Delay(4500);finish.Enabled=true;limit.Start();status.Text="请对大疆说一句话，然后点“结束录音”。";
  }catch(Exception e){status.Text="测试未开始："+e.Message;}
  finally{if(!finish.Enabled){running=false;SaveReport(ime);start.Enabled=true;}}
 }
 async Task Finish(){
  limit.Stop();finish.Enabled=false;draft.Focus();await Task.Delay(350);
  string ime=Tab5InputMethod.CurrentName();
  try{if(GetForegroundWindow()!=Handle||!draft.Focused)throw new InvalidOperationException("草稿窗口没有焦点");
   finishAck=Trigger();if(!finishAck)throw new InvalidOperationException("未收到设备结束回执");
   await Task.Delay(7000);status.Text=draft.TextLength>0?"豆包文字已进入草稿；请核对内容。":"草稿尚无文字，请反馈豆包浮窗状态。";
  }catch(Exception e){finishFailure=e.GetType().Name+": "+e.Message;status.Text="自动结束失败，请在豆包浮窗手动结束："+e.Message;}
  finally{running=false;SaveReport(ime);start.Enabled=true;}
 }
 void SaveReport(string ime)=>File.WriteAllText(report,JsonSerializer.Serialize(new{ime,deviceAck,finishAck,finishFailure,textLength=draft.TextLength,events}));
 nint Observe(int n,nint w,nint l){
  if(n==0&&running&&GetForegroundWindow()==Handle){var k=Marshal.PtrToStructure<Key>(l);if(k.vk is 0xA4 or 0xA5 or 0x12 or 0x20 or 0x1B)events.Add(new{vk=k.vk,flags=k.flags,message=(long)w,time=k.time});}
  return CallNextHookEx(hook,n,w,l);
 }
 protected override void OnFormClosed(FormClosedEventArgs e){limit.Stop();limit.Dispose();if(hook!=0)UnhookWindowsHookEx(hook);base.OnFormClosed(e);}
 delegate nint Hook(int n,nint w,nint l);
 [StructLayout(LayoutKind.Sequential)]struct Key{public uint vk,scan,flags,time;public nuint extra;}
 [DllImport("user32.dll")]static extern nint GetForegroundWindow();
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern nint GetModuleHandle(string? name);
 [DllImport("user32.dll",EntryPoint="SetWindowsHookExW")]static extern nint SetWindowsHookEx(int type,Hook cb,nint module,uint thread);
 [DllImport("user32.dll")]static extern bool UnhookWindowsHookEx(nint h);
 [DllImport("user32.dll")]static extern nint CallNextHookEx(nint h,int n,nint w,nint l);
}
