// Exercise the actual BLE access callback with fragmented transport packets.
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MALLOC_CAP_SPIRAM 1
#define MALLOC_CAP_8BIT 2
#define BLE_ATT_ERR_INSUFFICIENT_AUTHEN 5
#define BLE_ATT_ERR_INSUFFICIENT_RES 17
#define BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN 13
#define BLE_ATT_ERR_UNLIKELY 14
#define BLE_GATT_ACCESS_OP_READ_CHR 1
#define LINK_BLE 2
#define portMAX_DELAY 0
typedef struct {bool paired;char id[13];} device_config;
struct os_mbuf {const uint8_t *data;uint16_t len;};
struct ble_gatt_access_ctxt {int op;struct os_mbuf *om;};
#define OS_MBUF_PKTLEN(m) ((m)->len)
static bool allocation_fails,paired=true;
static unsigned allocations,received;
static uint8_t *packet;
static size_t used;
static char challenge[33];
static uint64_t acknowledged;
static int64_t last_write,test_clock=1000;
static int device_mutex;
static void *heap_caps_malloc(size_t size,int caps) {
    assert(caps==(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));allocations++;
    return allocation_fails?NULL:malloc(size);
}
static device_config device_get_config(void){return (device_config){.paired=paired,.id="test"};}
static void device_proof(const char *message,char *out){(void)message;memcpy(out,"proof",6);}
static void xSemaphoreTake(int mutex,int timeout){(void)mutex;(void)timeout;}
static void xSemaphoreGive(int mutex){(void)mutex;}
static void assets_ids(char *out){memcpy(out,"0,0,0",6);}
static int os_mbuf_append(struct os_mbuf *buf,const void *src,size_t size){(void)buf;(void)src;(void)size;return 0;}
static int64_t esp_timer_get_time(void){return test_clock*1000;}
static int ble_hs_mbuf_to_flat(const struct os_mbuf *m,void *out,uint16_t len,void *unused){(void)unused;assert(len==m->len);memcpy(out,m->data,len);return 0;}
static char *device_decrypt(const uint8_t *data,uint32_t size,const char *nonce) {
    (void)nonce;assert(size>=28);
    for(uint32_t i=0;i<size;i++)assert(data[i]==(uint8_t)i);
    char *clear=malloc(3);assert(clear);memcpy(clear,"{}",3);return clear;
}
static bool device_receive(const char *clear,int link,uint64_t *seq){assert(!strcmp(clear,"{}")&&link==LINK_BLE);*seq=++received;return true;}

#include "ble_reassembly_under_test.inc"

static int feed(const uint8_t *data,uint16_t size) {
    struct os_mbuf m={data,size};struct ble_gatt_access_ctxt ctx={.op=2,.om=&m};
    return access(0,0,&ctx,NULL);
}
static void frame(uint8_t *out,uint32_t size) {
    out[0]=(uint8_t)size;out[1]=(uint8_t)(size>>8);out[2]=(uint8_t)(size>>16);out[3]=(uint8_t)(size>>24);
    for(uint32_t i=0;i<size;i++)out[i+4]=(uint8_t)i;
}
int main(void) {
    uint8_t bytes[PACKET_CAPACITY+1];frame(bytes,TAB5_MAX_FRAME);
    allocation_fails=true;assert(!packet_init());
    assert(feed(bytes,4)==BLE_ATT_ERR_INSUFFICIENT_RES&&used==0);
    allocation_fails=false;assert(packet_init());unsigned count=allocations;
    assert(packet_init()&&allocations==count);
    // Maximum-size payloads, split headers, and multiple characteristic writes.
    for(int round=0;round<20;round++) {
        assert(feed(bytes,2)==0&&received==(unsigned)round);
        for(size_t offset=2;offset<PACKET_CAPACITY;) {
            uint16_t n=(uint16_t)(PACKET_CAPACITY-offset>247?247:PACKET_CAPACITY-offset);
            assert(feed(bytes+offset,n)==0);offset+=n;
        }
        assert(used==0&&received==(unsigned)round+1&&acknowledged==received);
    }
    assert(feed(bytes,PACKET_CAPACITY+1)==BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN&&used==0);
    // A timed-out partial packet must not poison the next frame.
    assert(feed(bytes,2)==0);test_clock+=6000;
    frame(bytes,28);assert(feed(bytes,32)==0&&received==21);
    paired=false;assert(feed(bytes,32)==BLE_ATT_ERR_INSUFFICIENT_AUTHEN&&received==21);
    free(packet);
    puts("BLE_REASSEMBLY_TEST_OK: PSRAM failure, max payload, fragmentation, timeout, authentication gate");
    return 0;
}
