# TAB5 协议 1

## 语音输入开发扩展（2026-09-23）

`POST /tab5/v1/voice` 仅面向已配对设备；body 使用同一 AES-256-GCM 包装，最大 16384 字节。HMAC 输入为 `POST|/tab5/v1/voice|deviceId|nonce|sha256(packet)`；绑定路径避免与文字任务接口交叉使用。成功鉴权后的状态和文字响应也加密，nonce 作为 AAD，不在公共 `/status` 返回语音草稿。

明文 JSON 公共字段：`session`、`issuedAt`（UTC 毫秒，允许 ±15 秒）、`op`。开始请求携带 `taskId`；后续请求携带 `voiceId`。操作为 `start`、`poll`、`audio`、`stop`、`cancel`、`tab5`。音频请求增加 `seq`（从 0 连续递增）及 `pcm`（Base64，16kHz/16bit/单声道，小端，至多 6400 字节）。不自动重试音频包；篡改、重复 nonce、乱序包、旧会话及超限长度会拒绝。

响应包含 `voiceId`、`taskId`、`source`（`dji` / `tab5`）、`state`（`recording` / `draining` / `recognizing` / `review` / `error` / `cancelled`）、`message`、`text`。`text` 至多 2000 UTF-8 字节，仅作为草稿。`stop` 排空音频后结束豆包识别，`cancel` 丢弃本次草稿。电脑 4 秒无请求停止收音，单次最多 60 秒；TAB5 离开任务页取消。

此接口不调用 `turn/start`，用户仍须点击发送。实际音频/豆包/真机验证边界见 [VOICE-INPUT.md](VOICE-INPUT.md)。

状态：首阶段实现，真机验收结果见 `ACCEPTANCE.md`。Windows 接入源码位于相邻 AI-bot 项目的 `Tab5*.cs`。原 ESP8266 的消息、接口和显示策略不变。

## 身份、传输与界面

- `deviceId`：P4 eFuse MAC 的 12 位小写十六进制，不依赖 COM 号或 BLE 随机地址。
- USB：460800，UTF-8，`@AIBOT ` + 单行 JSON + LF。每行最多 32768 字节，溢出丢弃到下一个 LF。
- `tab5_ping` -> `tab5_hello`（version、deviceId、firmware）。与原小屏 `ping/pong` 明确区分。
- 用户在电脑端选择真实 USB 设备并配对。`tab5_pair` 写入 deviceId、32 字节随机密钥（Base64）、电脑 LAN host/port。`tab5_paired` 确认。
- `tab5_wifi` 仅通过 USB 接收 SSID/password，写入 TAB5 NVS，确认 `tab5_wifi_saved`。电脑不持久化 Wi-Fi 密码。
- `tab5_host` 仅通过 USB 更新 RFC1918 IPv4 和端口；地址变化后可重新接 USB 同步。首次版本不宣称无线自动发现新电脑地址。
- Windows 配对文件使用当前用户 DPAPI。当前支持一台 TAB5 与一台原小屏共存。

## 业务帧

`tab5_status` 包含 version=1、deviceId、session（桥接启动随机标识）、sequence（每次公共快照递增）、data。
data 包含 time、epochUtc、utcOffsetSeconds、capturedAt、codex、claude、quotas、weather、stocks、systemMetrics、music。
缺失值保持 null，供应商 stale 标识保留；不携带原小屏 displayPolicy、账户凭据、对话正文。
两种设备共用 BridgeRuntime 的数据服务；TAB5 不额外请求供应商接口。
0.2.0-dev：股票最多 20 条，系统指标携带最近 16 个采样；USB、Wi-Fi、BLE 同源快照具有相同 session/sequence。
新增 `quotaDetails`（十个平台的统一额度、余额、重置时间和本机 Token）、`domesticActivity`、`followApp`、`calendar`（本地日期、星期、当前/次日农历）。这些字段与原小屏独立。
`quotas` 仅保留总览需要的百分比和 stale；平台详细数值统一放在 `quotaDetails`，不重复发送完整 domesticQuotas 和本机活动日志字典。

0.2.32-ui：`weather.hourly` 最多 24 项，包含 `time`（预报地点本地 ISO 时间）、`condition`、`temperature`、`rainProbability`（0–100，未知为 null）；`weather.daily` 最多 7 项，包含 `date`、`condition`、`low`、`high`、`rainProbability`、`precipitationMm`。降水量与概率分别展示，不能互相转换。`hourlyStale`/`dailyStale` 标记分项缓存；同一地区/供应商的小时请求失败时保留前一次小时数据，不清空已经成功获取的每日/实况数据。旧桥接缺少数组时，TAB5 显示“暂无预报”。公共 ESP8266 小屏帧保持原结构。

数据仍由公共电脑桥接按原 15 分钟周期统一获取。和风城市预报使用 `/v7/weather/24h` 与 `/v7/weather/7d`；Open-Meteo 备用接口请求 7 天并提取当前小时起的 24 小时。日期以供应商预报地点的时区为准，不按电脑所在地重新解释。官方字段：[和风小时预报](https://dev.qweather.com/docs/api/weather/weather-hourly-forecast-webapi-v7/)、[和风每日预报](https://dev.qweather.com/docs/api/weather/weather-daily-forecast-webapi-v7/)、[Open-Meteo](https://open-meteo.com/en/docs)。

USB 正确接收后返回 `tab5_ack`，包含 deviceId 和 sequence。重复帧可以确认，但不得延长有效心跳。
TAB5 原生 USB Serial/JTAG 在此 Windows 设备上需要 DTR=true、RTS=false；此设置仅用于 TAB5，原 ESP8266 串口配置不变。
每条链路独立记录最新序号与接收时间；自动选择 USB > Wi-Fi > BLE，8 秒无新状态失效。
仅 USB/仅 Wi-Fi/仅 BLE 模式不自动换到其他通道。切换保留 UI 页面，离线保留缓存并标记，时钟继续走时。

## Wi-Fi

`GET /tab5/v1/status HTTP/1.1`，与原 `/status` 并存。
请求头：X-AIBot-Device、X-AIBot-Nonce（随机 16 字节的小写 hex）、X-AIBot-Proof。
proof = hex(HMAC-SHA256(deviceKey, UTF8(`GET|deviceId|nonce`)))。
响应为 AES-256-GCM：随机 IV[12] + tag[16] + ciphertext，AAD 为 nonce 的 32 字节 ASCII。
密钥不经 HTTP 发送，状态负载加密；拒绝重定向，限制响应 32768 字节。
认证失败、未配对或电脑公共快照已超过 6 秒未更新均不返回状态。

## BLE

- Service：`7af50001-7f23-4a91-bc65-667a19320101`
- Info (read)：`7af50002-7f23-4a91-bc65-667a19320101`
- Input (write with response)：`7af50003-7f23-4a91-bc65-667a19320101`

每次连接创建随机 nonce。Info 返回 deviceId、nonce、ack 和 HMAC(key, ASCII(`nonce|ack`))，ack 初始为 0。
电脑只向通过配对密钥验证的设备发送数据；输入使用同一 AES-GCM 格式，AAD 为当前连接 nonce。
BLE 数据前加 uint32 little-endian 包长，再按 ATT MTU 分片写入（最少 20 字节）。最大包 32768 字节，片段间隔超过 5 秒丢弃未完成包。
完整帧解密并处理后，Info 的 ack 更新为序号。电脑读取并校验确认，不能把 GATT 写入成功直接当作业务接收成功。
USB 首次配对及应用层加密不依赖传统蓝牙串口，也不向 BLE 发送配对密钥。

## 图片资源（0.2.0-dev）

`data.resource` 为可选的一个图片分片，`data.assetIds` 为当前三个资源的标识，空值表示该槽位没有资源。
槽位 0/1 是 Claude/Codex 桌宠，最大尺寸 120×120、1–8 帧。槽位 2 是音乐封面；自 0.2.11-ui 起支持最大 336×336、单帧，与界面显示尺寸一致；仍接受旧桥接的 112×112 封面。公共桥接为 ESP8266 保留独立的 112×112 封面。

- 字段：`slot`、`id`、`width`、`height`、`frames`、`delays`、`total`、`offset`、`bytes`。
- RGB565 little-endian，所有帧顺序拼接。RLE16 编码：每组 uint16 little-endian 重复次数 + uint16 像素值；禁止零次和超出预期像素数。
- `id` 为压缩字节 CRC32 的八位小写十六进制；无线传输的真实性仍由外层 AES-GCM 保证。
- `bytes` 为 Base64，每片最多 1024 个压缩字节；`offset` 按 1024 对齐，末片可不足。压缩总长上限 524288。
- 只发送设备缺失或 ID 已变化的资源。待传分片每轮打乱次序，设备支持乱序和重复分片；收齐、CRC 与精确像素数均通过才替换旧资源。
- USB 可另发 `tab5_resource`（version、deviceId、resource），返回 `tab5_resource_ack`。每轮最多 16 片，给普通心跳留出时间；这类消息不写配对 NVS。
- 显示资源 ID 必须与 `assetIds` 一致；更换曲目时不会暂用旧封面。音乐封面只缓存 RAM，同一封面不重复传送。
- 桌宠持久化到独立 `assets` 分区（0xb00000、2 MiB）。每个角色两份 512 KiB 交替保存；校验资源和元数据，先写数据、最后提交头部。后台写入，不在接收回调中擦写闪存。启动时选取最新有效副本，缓存无效时重新同步。此区域部署前已只读验证全为擦除态，原应用和配对 NVS 地址不变。
- USB ACK 的 `assetIds` 是三个 ID 或 `-` 组成的逗号分隔字符串。Wi-Fi 使用 `X-AIBot-Assets` 和 `X-AIBot-Assets-Proof`；BLE Info 使用 `assetIds` 和 `assetProof`。资源报告 proof = hex(HMAC-SHA256(key, ASCII(`ASSETS|nonce|ids`)))。未通过认证的报告不会使桥接停止发送。
- 私有桌宠/封面不进入固件或发布包。设备 ACK 可报告 `assetsReady`、`assetsCached` 位图、`uiPage`、`uptimeMs`、`resetReason`。缓存命中后状态帧的 `resource=null`；桥接重启也不重新批量传送资源。

## 能力边界

### 0.2.1 显示补充

`calendar` 保留原有日期、星期、农历和次日字段，新增 `solarTermLabel`、`holidayLabel`、`nextSolarTermLabel`、`nextHolidayLabel`。TAB5 跨零点使用匹配日期的字段，超过已收到的次日后提示待更新。

电脑本地保存节气日期表（香港天文台 2026–2028）和中国大陆 2026 放假调休表，正常运行不访问日历网站。年度未覆盖时明确提示待更新。数据来源见 `UI-DESIGN.md`。

三款时钟布局和全部图表由 TAB5 绘制，不新增图片资源传输。表盘选择保存为独立 NVS `clock_style` 键，不改变原有 `ui` blob 格式。

首阶段是状态显示，没有远程执行电脑命令、语音对话、固件 OTA。新增能力使用独立消息及能力协商，不能把原小屏设置写入 TAB5。

## 额度显示扩展（0.2.2-dev）

- `quotaDetails[].creditExpiries`：逐卡到期时间数组，按设备时区格式化为 `yyyy-MM-dd HH:mm`；保留同日多张卡。`credits` 为可用张数，日期缺失不猜测。
- Codex `primary`/`primaryReset` 及总览 `primaryPercent` 仅向 PLUS 套餐映射，PRO 不展示 5 小时限制；原小屏协议未改。
- `quotaTrend`：`provider=codex`，`unit=weekly_percentage_points`，`timezone=Asia/Shanghai`，`days` 为近 7 个自然日的 `{date,label,used,partial}`。`used=null` 表示没有可比较采样；`partial=true` 表示当天未结束或有缺口/重置等，不当作完整全天消耗。`storageWarning` 提示桥接历史存储异常。
- 聚合复用公共桥接 QuotaHistory，每 30 秒刷新一次，不另建历史文件，不发送账户指纹。
- 表盘点击循环仍使用原 `clock_style` NVS 键，已有选择保留。

## 0.2.3-dev 补充

- `quotaDetails[].billingMode` 为 `payg` 或 `subscription`。按量付费显示 `balance`、`cost`、`currency`，`cost` 是数据源提供的账户累计消费，未知为 null；Coding Plan 使用周期额度。`planExpiry` 仅由明确的套餐到期字段填充，未知为 `--`，不得由 5 小时、周额度或套餐重置时间推算。旧消息缺失该字段时保持订阅布局。
- `epochMilliseconds` 为电脑状态采集时的 UTC 毫秒时间；旧固件可忽略，新固件缺失该值时回退 `epochUtc`。TAB5 用单调时钟持续走时，普通心跳的两秒内差异不重置相位，较大校时重新同步。
- 公共桥接每分钟记录额度，成功即保存，不受重置卡请求失败影响。同日同账户同周期断档差值保留并标记部分记录。按用户约定，五分钟内跨零点增量计入后一次采样的北京时间日期；跨天长断档不摊派。

## 0.2.4-dev 天气与本地设置

- `weather.pressureHpa`：可空气压数值；`pressureKind=station` 为和风站点气压，`sea_level` 为 Open-Meteo 海平面气压。缺失不是 0。
- `weather.airQualityIndex` 贯通实际采集值，`airQualityStandard` 标识 `cn-mee`、`us-epa` 或 `qaqi`，界面同时保留类别文字。
- `clock_style` 仍为独立字节，范围扩展到 0–4，原 2 对应的新布局为轨道圆盘。总览独立字节 `home_models` 三位分别对应 Codex/DeepSeek/智谱，默认 7，至少选一项。不改变旧 `ui` blob 或原小屏配置。
- 屏保只影响本机显示与背光，触摸恢复原页面/亮度，数据采集继续。

## 0.2.5-dev 电脑输入活动

TAB5 data.pcInput 包含 session、sequence、lastInputTickMs（Windows 开机单调毫秒时间戳，可为空）。桥接只读取 GetLastInputInfo 的活动时间，不采集按键内容、鼠标坐标。USB/Wi-Fi/BLE 使用同一状态帧。

设备首次见到会话建立基准；同会话仅接收递增序号，只有 lastInputTickMs 前进才重置无操作计时并退出屏保。重复或较旧序号、缺失值、未变化的心跳不唤醒。桥接重启重新建立基准。没有新桥接字段时仍保留触摸屏保与唤醒。

USB 诊断新增 saverActive（0/1）、pcWakeCount（本次开机电脑输入唤醒次数），便于分别核对数据通道和实际屏保行为。

## 0.2.6-dev 音乐时间线有效性

music.timelineAvailable=false 表示当前没有有效播放进度；durationSeconds 仍可携带本地匹配歌曲的总时长。TAB5 显示 --:-- / 总时长，隐藏比例进度且不自行累加播放位置。旧桥接缺少字段时沿用既有行为。旧 ESP8266 USB 帧在此状态下继续保持 0/0，避免将已知总时长误当作已知播放进度。

## Codex 文字任务入口（开发中）

状态帧可增加 `data.codexTasks={projects:[{id,name}],tasks:[{id,title,folder,updatedAt,projectId}],receipts:{taskId:statusText}}`。项目仅从 Codex 侧栏已保存的项目根目录读取；项目 ID 为保存项目 ID 的 SHA-256 前 16 位小写十六进制，最多 80 条会话，每项目最多 8 条；用户先选项目，再显示对应会话。Codex 管理的同名 worktree 会话归入其保存项目。旧桥接只有 `tasks` 时设备显示“最近任务”。资源帧达到上限时先延后资源分片，必要时减少会话数量并保留当前查看任务与各项目入口，继续遵守 32768 字节限制。

回复扩展：`responses:{taskId:text}` 当前只携带一份正文；`replyView:{taskId,turnId,page,pageCount}` 标识当前动态段；`repliesReady:{taskId:turnId}` 标记 TAB5 提交轮次的完成回复。`POST /tab5/v1/codex/read` 沿用任务加密鉴权，请求体 `{op:"read",session,taskId,message:"",issuedAt,page:-1}`，page=-1 表示最新段，非负整数从 0 开始。每段不超过 2200 UTF-8 字节；老固件省略 page 时读取最新段。返回 200 后正文随状态帧同步。读取不会发送或续写任务。设备每 3 秒最多一个只读请求，历史翻页不会重复发出完成提醒。

新增 `POST /tab5/v1/codex/turn`，请求体最多 8192 字节，使用原 AES-256-GCM 封包布局及 nonce AAD。解密 JSON 为 `{session,taskId,message,issuedAt}`；`issuedAt` 为来自电脑状态帧时钟的 Unix 毫秒时间。

请求头沿用 `X-AIBot-Device`、`X-AIBot-Nonce`、`X-AIBot-Proof`。Proof 是配对密钥对 `POST|deviceId|nonce|sha256(ciphertext_packet)` 的 HMAC-SHA256（小写 hex）。电脑校验当前桥接 session、消息时间（过去 90 秒至未来 10 秒）、nonce 重放与每秒最多 1 次提交。1024 项 nonce 窗口覆盖整个有效时间段。返回不包含原始输入的 JSON：202 已提交；400 参数/过期会话；401 未授权；404 任务不存在；409 重复/任务忙/状态未知；429 过快；503 Codex 不可用；504 提交结果不确定。

设备不自动重发任务。只在具有有效轮次 ID 的 202 后清空草稿；提交后的断线、超时或不完整回执返回 504，提示先在电脑查看。语音使用独立的 `/tab5/v1/voice` 扩展（见本文语音章节及 [双音源语音](VOICE-INPUT.md)）；尚无照片或通用电脑键鼠注入协议。具体完成边界见 [Codex 任务入口](CODEX-REMOTE.md)。

2026-09-26 恢复与运行中操作扩展：

| op | 路由 | 新增字段 | 成功含义 |
| --- | --- | --- | --- |
| send | turn | requestId（旧固件可省略） | 202，桌面已接收 |
| steer | turn | requestId、expectedTurn | 202，桌面已接收追加 |
| interrupt | turn | requestId、expectedTurn，message 可空 | 202，停止请求已接受；不清草稿 |
| draft-save | turn | requestId，message 为草稿 | 200，草稿已落盘 |
| draft-load | read | requestId | 200，draftView 随后下发 |
| receipt | read | 原 requestId | 202 已接收；504 仍未确认；404 没有记录不等于发送失败 |

所有操作保留 session、taskId、issuedAt、message 字段及原加密鉴权。草稿、读取、显式操作各自每秒一次限速；错误路由和非字符串 op 拒绝。固定请求编号与正文摘要绑定，跨重启只能核对同一请求，不重新派发。摘要包括 taskId、message、op、expectedTurn。

`codexTasks.control={taskId,turnId,running,waiting}` 用于运行中按钮；`draftView={taskId,requestId,text,pendingRequest,operation,expectedTurn}` 只含最近请求的一份草稿，设备核对会话、请求编号及本机编辑版本后再应用。空白且尚未加载的输入框不能被当成清空指令上传。

## OTA 扩展

用户在电脑桥接窗口明确选择本项目应用镜像后，已加密状态帧的 `data.ota` 为 `{sha256,size,version,offerId}`；未选择或撤销时为 `null`。`offerId` 是每次手动选择生成的 32 位小写十六进制编号，设备对每个编号只在用户确认后尝试一次；重新选择同一镜像可发起新一次尝试。TAB5 接受已鉴权状态帧并由用户确认后请求 `GET /tab5/v1/ota/{sha256}`。头 `X-AIBot-Device`、`X-AIBot-Nonce`、`X-AIBot-Proof` 中的 Proof 为配对密钥对 `GET|/tab5/v1/ota/{sha256}|deviceId|nonce` 的 HMAC-SHA256。只有与当前准备镜像的 SHA 一致且鉴权成功才返回完整应用二进制；镜像本身由设备计算 SHA-256 并与状态帧比对。首次双分区迁移和失败回滚见 [OTA.md](OTA.md)。
可选头 `X-AIBot-OTA-Flow: tcp-v2` 表示接收端具备 16 KiB 合并写入及 P4 SDIO 包池修复；仅在原有鉴权成功后，桥接以 16 KiB 有界异步写入并依赖 TCP 背压。无此头、`tcp-v1` 或未知值采用 2 KiB/64 ms 兼容传输。该头只选择流控方式，不承担鉴权；不能用新版目标镜像或旧接收端 USB 心跳替代能力声明。

`data.ota.notes` 为可选纯文本更新说明，最多 1024 UTF-8 字节。桥接从所选镜像同路径的 `<文件名>.bin.notes.json` 读取 `{version,sha256,notes}`，版本及 SHA 必须匹配镜像，错误时不提供该包；旧包无说明文件仍可选择。TAB5 0.2.30 起在升级页第一行显示新版本及可用状态，下方展示可滚动说明；字段缺失或超长时显示「暂无更新说明」。旧设备忽略新增字段，取消提供会清除版本和说明。

# 2026-09-26 语音就绪字段

`/tab5/v1/voice` 加密响应增加布尔 `ready`，默认为 `false`，只在 `state=recording` 且快捷键已确认、音频输入和虚拟输出就绪时为 `true`。TAB5 路径需至少一段 PCM 被接收；大疆路径需发生真实采集回调。停止、失败、取消均返回 `false`。

固件还检查本机首段音频请求成功、无停止命令、无采集错误，才显示就绪和启动计时。连接/准备期间不展示录音计时。该字段不声明豆包内部识别服务状态。需要配套桥接；旧桥接缺失字段时不会误发就绪提示。

语音响应现增加 `level`（0–100，-60 至 0 dBFS 显示刻度）与 `silent`（音频通路就绪后连续约 6 秒未检测到声音）。数据来自实际选择的大疆或 TAB5 输入，不保存录音；静音只提示，不自行结束。停止或未就绪时电平为 0。

## 照片附件

独立 `/tab5/v1/codex/image` 加密上传与 `images` 草稿/发送字段见 [PHOTO-ATTACHMENTS.md](PHOTO-ATTACHMENTS.md)。图片先暂存到电脑，用户明确点击发送后才作为真正的 `localImage` 与文字一起进入所选 Codex 会话。

# 0.2.21 Wi-Fi 备注扩展

USB `tab5_wifi` 可附加可选 `label`（最多 48 UTF-8 字节、无控制字符），缺省保留已有备注。USB `tab5_wifi_label` 携带 `version=1`、已配对 `deviceId`、真实 `ssid` 与 `label`，仅更新已保存网络的备注，成功回执为 `tab5_wifi_label_saved`；空备注表示清除。未知 SSID 不创建网络，不修改密码或当前连接。

备注命令与配网一样仅由 USB 配置路径接受。v2 保存格式位于独立 NVS 键 `wifi_profiles2`，兼容读取旧网络列表，配对结构与状态协议版本不变。

# 0.2.22 USB 网络管理扩展

电脑先验证配对设备身份，再发送 `version=1,type=tab5_wifi_list,deviceId`。返回同名类型、版本、设备 ID 和 `networks` 数组，最多 5 项，每项只包含 `ssid,label,connected,selected`，不返回密码或密钥。

删除命令为 `version=1,type=tab5_wifi_forget,deviceId,ssid`，按真实 SSID 定位。成功返回 `tab5_wifi_forgotten`；设备忙、网络不存在或持久化失败返回 `tab5_wifi_rejected`。删除在显示锁内检查录音、拍照、发送及升级状态，提交与设备端删除共用的网络存储方法。修改备注和密码继续复用 `tab5_wifi_label`、`tab5_wifi`。

以上命令仅由 USB 接收，不扩大无线配置权限。


## TAB5 0.2.26 回复内容标识

`codexTasks.replyView.hasText` 和加密读取回执内的 `replyView.hasText` 是可选布尔字段，表示当前分页有有效公开文字，false 表示等待/空内容占位。新版设备只在对应轮次的有效正文显示后清除未读，历史固定查看也适用；空占位继续重试。旧桥接缺少字段时设备兼容已知占位文字，旧设备忽略新增字段。读取轮询仍为每 3 秒，运行中的文字优先取桌面 IPC 公开消息。
# 0.2.65 三通道扩展（未部署）

状态增量、USB 二进制邮箱、Wi-Fi 二进制图片、USB 语音、BLE OTA、窗口协商与测速协议见 [TRANSPORT-INTEGRATED-065.md](TRANSPORT-INTEGRATED-065.md)。旧端按能力兼容，固定模式不可跨路。构建与协议回归不等于真机性能通过。

## 0.2.70 有界大数据传输

已认证的对应通道状态同时包含 `rpcBinary=1,rpcBulk=1` 时启用 `T5R2`：4 字节魔数、4 字节小端元数据长度、2..4096 字节 JSON、1..49152 字节原始数据。请求设置 `binaryReply:true,bulkReply:true`；T5R1 的 8192 字节上传、16384 字节回复边界不变。邮箱总长最多 65535 字节（请求含 nonce32/proof64），HTTP 加密请求最多 65439 字节；认证、时效、防重放、偏移与哈希检查不变。只允许照片与测速请求带原始数据，OTA/测速批量回复可增大；不确定失败不跨通道重试。

USB 二进制线缆片段仍为 16 KiB，逻辑大块拆成多个原有片段。USB hello/ack 的 `usbPacked=1` 允许压缩完整状态，展开仍限制 32768 字节，成功回复 `tab5_ack`，指标仍是原格式；拒绝分别回复 `tab5_ack_rejected`/`tab5_metrics_ack_rejected`。不保留分发器与接收器两棵完整 JSON 树。

BLE 通知与响应窗口仍最多 8 片、ATT 有效载荷最多 488 字节；电脑锁在一次读/授权/响应窗口后释放，窗口内顺序写，末片确认。独立蓝牙语音缓冲和时限保持。仅 USB 语音界面已开放既有后端能力；真实识别待验收。

0.2.71 修正桥接保持原整窗口收齐后授权下一窗口的顺序；提前授权实验真机失败，已撤回。大 RPC 接收期间状态刷新最多延后 3 秒，语音轮询独立；本地诊断记录通知数与时间，不记录载荷。固件仅在批量传输时请求 7.5 ms 连接间隔，实际取值由电脑协商并在 link 诊断回报，空闲恢复原间隔。

每方向三轮 256 KiB RAM 基准，协商新端每轮 6 个 RPC、旧端 32 个，按相同总有效字节比较。详见 [0.2.70 实现与验证](TRANSPORT-PERFORMANCE-070.md)；构建与模拟不是设备验收。

071c 本地诊断候选：仅设置进程环境 AIBOT_TAB5_BLE_THROUGHPUT=1 时，在已认证 BLE 连接内尝试 Windows 11 ThroughputOptimized；空闲 2 秒释放并恢复 Balanced，失败保留原通道行为。pcPreference 仅报告请求生命周期，不能作为吞吐验收结论。USB 启动核验通过后读取现有 tab5_crash_status 数值诊断，将 previousOtaMs=[总接收写入,读,写] 保存到本机诊断；读写并行，后两项不相加。未修改线上消息格式。

0.2.73 候选：撤回 071c 的 Windows 吞吐偏好实验，保留数值 OTA 核验诊断。新增 rpcMailboxWindow=32 表示 RPC 支持最多 32 片完整窗口；mailboxWindow=8 仍用于语音。新桥接在字段缺失时沿用旧窗口，旧桥接继续最多 8 片。命令 3 的 credit 仍有上限，语音端拒绝超过 8，RPC 端拒绝超过 32；每批完整接收后才授权下一批。mailboxStats=[已提交通知,分配失败,提交失败,全局空闲 mbuf 最低值]，最低值 65535 表示尚无通知。
073b 修正：.073 真机 32 片 RPC 测速发生通知提交失败；桥接将 rpcMailboxWindow 的实际协商上限限制为 8，即使固件声明 32。固件仍接受旧的 8 片请求。当前恢复方案等待真机复测，不将 32 片作为已验收能力。
0.2.74 候选新增 rpcNotifyWindow=32，设备在 host callout 按空闲 MSYS 容量分段提交授权通知；rpcMailboxWindow=8 仍限制电脑回写。通知和回写独立协商，新字段缺失时通知沿用最多 8。rpcPacing=[yield次数,终止次数,最近通知错误码]。单窗口最多 3 秒，断开/错误终止，不重发可能已部分发送的异常通知。等待真机验收。
# TAB5 0.2.75 显示诊断扩展

`displayDiag` 保留原 52 列，追加索引 52～55：完整普通页面快照数、完整预旋转页面快照数、分片重建被更新打断的累计次数、当前 PSRAM 空闲字节数。计数描述已发布的完整图片，可能是手势允许复用的旧内容；不能把它解释为所有页面都已更新至最新状态。桥接沿用字符串透传，不改变状态协议版本或控制命令。

0.2.77 诊断候选保留前 56 列，追加 `displayDiag[56..74]`：schema（1）、上次 RTC 记录有效位、CPU0/CPU1 ROM 原始复位值，然后依次为 UI、刷新、LCD 提交/等待、缓存、Flash 五组 `(stage, atUs32, detail)`。同样的 19 个数字通过 `tab5_crash_status` 的 `trace.previousRuntime` 返回。UI/缓存/Flash 的阶段 1 为进入、0 为完成；刷新 1/2/3/0 为开始/渲染开始/渲染完成/刷新完成；LCD 1/2/3/0 为提交开始/提交返回/等待开始/等待完成。detail 为页面编号，Flash 为 0。各时间为上次运行低 32 位微秒，约 71.6 分钟回绕；独立通道是尽力保存的进度线索，不是调用栈，提交返回也不等于屏幕已完成传输。桥接继续透传字符串，老固件可以缺少尾部字段。

TAB5 .078 accepts optional `music.artworkWidth` / `artworkHeight`, the original artwork dimensions supplied to the bridge. Valid dimensions (1..32768) with aspect ratio above 1.25 select a wider landscape presentation; missing/invalid dimensions retain the square layout. The resource remains a 336×336 RGB565 aspect-fit canvas, so these fields describe source aspect ratio rather than resource dimensions. Windows strips them from legacy ESP8266 USB frames; older TAB5 firmware ignores them. No protocol-version or resource-format change is required.

## Music artwork .080 candidate / 音乐封面 .080 候选

This extension keeps protocol version 1. On an authenticated firmware version at least
0.2.80, slot 2 may use resource encoding=jpeg, width 1..560, height 1..336, frames=1.
The ID is CRC32 of the packed JPEG, and 1024-byte aligned fragments still use total,
offset, bytes and delays. Other slots and older firmware keep RLE565.

A separate tab5_resources frame contains version, type, deviceId, session, sequence
and resources (1..8 chunk objects). A paired, established same-session snapshot is
required. Fragments do not replace snapshots, renew task freshness or trigger OTA.
Wi-Fi uses at most eight chunks, BLE four; USB remains its bounded dedicated stream.
BLE Info may expose firmware plus firmwareProof=HMAC(FIRMWARE|nonce|version).
The Windows bridge requires the verified proof before enabling this version's codec.

Windows optionally accepts POST /music/artwork on its loopback listener only, with
X-AIBot-Music-Key and an extension origin. This is a separate local browser pairing
key, never the TAB5 key. The companion sends current title/artist/artwork URLs and
optionally the current YouTube video ID; no browser history or cookies. Artwork is
matched exactly to the Windows title and artist. Downloads are bounded HTTPS images
from public hosts, without cookies or redirects; failures retain the last success.

协议版本仍为 1。JPEG 只用于 .080 及更新固件的音乐资源，原小屏和旧 TAB5
资源保持兼容。资源专用帧必须属于已建立的配对会话，不延长任务新鲜度。
本机浏览器接口使用独立授权，只有用户启用的网站会提供当前媒体信息；
不会保存特定视频规则或下载到固件包。候选及真机边界见 MUSIC-ARTWORK-080.md。

### .081 crash capture / 故障现场

`tab5_crash_status` retains its version-1 envelope. The optional `trace.stackGuard`
contains two `[rawStatus, triggerPc, minimumSp, maximumSp]` arrays. `taskName` and
`taskBounds` describe the current fixed task identifier and its saved bounds;
`irqStack` is `[depth, minimumSp, maximumSp]`. `interruptedContext` contains saved
PC/RA/SP candidates; `irqCauseCandidate` is the saved s1 register, not an asserted
interrupt cause or a backtrace. Older readers can ignore these additional fields.

Windows retrieves this trace after a panic boot under the existing USB transaction
gate and keeps eight records in RAM. `GET /diagnostics/tab5-crashes` is loopback-only
and rejects browser origins. No device pairing, snapshot freshness or resource codec
is changed by this capture. See CRASH-080.md for evidence and hardware limits.

新增字段只补充数字故障现场。原始任务位置属于候选线索，不能视为已展开调用栈。
桥接自动回收上次 panic；诊断版未被标记为崩溃修复。
