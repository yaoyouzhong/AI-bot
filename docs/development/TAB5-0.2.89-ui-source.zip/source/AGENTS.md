# TAB5 项目约定

- 本项目是 AI-bot 的独立 TAB5 客户端；公共电脑桥接继续维护在相邻 AI-bot 项目。
- USB、Wi-Fi、BLE 均为日常数据通道；自动模式优先 USB > Wi-Fi > BLE，以有效数据心跳判断可用性。
- 设备设置独立于原 ESP8266 小屏。保持原小屏协议和用户配置兼容。
- 官方 BSP 放在 firmware/components，保留许可和来源；.tools、.reference、build 不进入交付。
- 设备配对凭据及 Wi-Fi 密码不进入源码、日志或发布材料。
- 构建、模拟协议测试和真机验收分别记录；不以编译通过代替三通道真机通过。
- 发布沿用公共桥接与独立 TAB5 固件方案；推送、标签和公开 Release 需单独授权。
- 本地固件交付遵循相邻 `AI-bot/docs/TAB5-FIRMWARE-WORKFLOW.md`：用准备脚本生成固定 `AI-bot/artifacts/firmware/tab5/latest/aibot_tab5.bin`，保留历史包，并预览实际更新说明。
