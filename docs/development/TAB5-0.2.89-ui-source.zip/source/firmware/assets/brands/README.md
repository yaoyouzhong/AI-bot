# 服务标识来源

首页小图标仅用于识别当前连接的服务，保持原标识形状和颜色。

| 显示名称 | 来源 |
| --- | --- |
| Codex | OpenAI 官方仓库 `openai/openai-agents-python/docs/assets/logo.svg`，以 OpenAI 标识代表 Codex。品牌使用说明：https://openai.com/brand/ |
| DeepSeek | DeepSeek 官方网站 `https://www.deepseek.com/favicon.ico` |
| 智谱 | 智谱官方网站 `https://www.zhipuai.cn/favicon.png`，当前 Z.AI 图标 |

这些标识分别属于其权利人。公开分发固件前，应重新核对标识版本与使用条款。
