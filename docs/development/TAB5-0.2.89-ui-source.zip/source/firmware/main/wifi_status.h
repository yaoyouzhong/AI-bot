#pragma once
#include <stddef.h>
#include <stdbool.h>
extern volatile bool tab5_wifi_initialized;
void tab5_wifi_diagnostics(char *out,size_t size);
void tab5_wifi_reconnect(void);
void device_discovered_host(const char *host,int port);
