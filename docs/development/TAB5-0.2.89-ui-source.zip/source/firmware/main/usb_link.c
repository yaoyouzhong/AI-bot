#include "device.h"
#include "rpc_link.h"
#include "esp_heap_caps.h"
#include "transport_benchmark.h"
#include "wifi_performance.h"
#include "codex_remote.h"
#include "mbedtls/base64.h"
#include "assets.h"
#include "camera_preview.h"
#include "photo_attachment.h"
#include "display_diagnostics.h"
#include "crash_record.h"
extern volatile unsigned tab5_display_rotate_us,tab5_display_rotate_peak_us,tab5_display_flush_count,tab5_display_flush_errors;
extern volatile int tab5_ui_page,tab5_saver_active;
extern volatile int tab5_ui_data_age_ms,tab5_ui_task_selected,tab5_ui_session_ready,tab5_ui_voice_check,tab5_ui_voice_age_ms;
extern volatile unsigned tab5_pc_wakes,tab5_backlight_changes,tab5_lcd_underruns;
extern volatile int tab5_backlight_percent;
extern volatile int tab5_voice_http_stage,tab5_voice_http_status,tab5_voice_request_ms,tab5_voice_last_seq;
extern unsigned tab5_ui_age_ms(void);
#include "esp_system.h"
#include "esp_app_desc.h"
#include "esp_ota_ops.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "tinyusb.h"
#include "tinyusb_default_config.h"
#include "tinyusb_cdc_acm.h"
#include "soc/lp_system_struct.h"
#include "esp_timer.h"

enum {ITF_CDC,ITF_CDC_DATA,ITF_HID,ITF_COUNT};
bool tab5_usb_connected(void) {
    // TAB5 remains powered by its battery after unplugging. Without a VBUS
    // monitor the controller can retain its configuration while the bus is
    // suspended, so mounted alone is not evidence of a live USB connection.
    return tud_ready();
}
static const uint8_t hid_report[]={TUD_HID_REPORT_DESC_KEYBOARD()};
static const uint8_t usb_configuration[]={
    TUD_CONFIG_DESCRIPTOR(1,ITF_COUNT,0,TUD_CONFIG_DESC_LEN+TUD_CDC_DESC_LEN+TUD_HID_DESC_LEN,0,100),
    TUD_CDC_DESCRIPTOR(ITF_CDC,4,0x81,8,0x02,0x82,64),
    TUD_HID_DESCRIPTOR(ITF_HID,5,HID_ITF_PROTOCOL_KEYBOARD,sizeof(hid_report),0x83,16,10)
};
static const tusb_desc_device_t usb_device={
    .bLength=sizeof(tusb_desc_device_t),.bDescriptorType=TUSB_DESC_DEVICE,
    .bcdUSB=0x0200,.bDeviceClass=TUSB_CLASS_MISC,
    .bDeviceSubClass=MISC_SUBCLASS_COMMON,.bDeviceProtocol=MISC_PROTOCOL_IAD,
    .bMaxPacketSize0=64,.idVendor=0x303A,.idProduct=0x4005,
    .bcdDevice=0x0100,.iManufacturer=1,.iProduct=2,.iSerialNumber=3,.bNumConfigurations=1
};
static char usb_serial[32];
static const char *usb_strings[]={
    (const char[]){0x09,0x04},"TAB5 development","TAB5 Control",usb_serial,"TAB5 CDC","TAB5 Keyboard"
};
static void usb_prepare_restart(void) {
    // esp_restart() resets the CPUs, not every USB peripheral. Make the host
    // observe a real disconnect before the bootloader/new app takes over.
    // Keep the driver alive until reset; deleting it while CDC is polling
    // would race the normal USB task.
    tud_disconnect();
    vTaskDelay(pdMS_TO_TICKS(200));
}
uint8_t const *tud_hid_descriptor_report_cb(uint8_t instance) {
    (void)instance;return hid_report;
}
uint16_t tud_hid_get_report_cb(uint8_t instance,uint8_t report_id,hid_report_type_t type,uint8_t *buffer,uint16_t reqlen) {
    (void)instance;(void)report_id;(void)type;(void)buffer;(void)reqlen;return 0;
}
void tud_hid_set_report_cb(uint8_t instance,uint8_t report_id,hid_report_type_t type,uint8_t const *buffer,uint16_t bufsize) {
    (void)instance;(void)report_id;(void)type;(void)buffer;(void)bufsize;
}
static void usb_write(const char *data,size_t size) {
    size_t sent=0;int64_t deadline=esp_timer_get_time()+500000;
    while(sent<size&&tab5_usb_connected()&&esp_timer_get_time()<deadline) {
        size_t n=tinyusb_cdcacm_write_queue(TINYUSB_CDC_ACM_0,(const uint8_t*)data+sent,size-sent);
        sent+=n;
        tinyusb_cdcacm_write_flush(TINYUSB_CDC_ACM_0,pdMS_TO_TICKS(20));
        if(!n)vTaskDelay(pdMS_TO_TICKS(1));
    }
}
static void write_ota_diagnostic(void) {
    const esp_partition_t *running=esp_ota_get_running_partition();
    esp_ota_img_states_t state=ESP_OTA_IMG_UNDEFINED;
    esp_err_t status=running?esp_ota_get_state_partition(running,&state):ESP_ERR_NOT_FOUND;
    char hash[65],out[448];
    const esp_app_desc_t *description=esp_app_get_description();
    for(int i=0;i<32;i++)snprintf(hash+i*2,3,"%02x",description->app_elf_sha256[i]);
    extern volatile unsigned tab5_glyph_hits,tab5_glyph_misses,tab5_fast_fills,tab5_fast_masks;
    int n=snprintf(out,sizeof(out),"@AIBOT {\"type\":\"tab5_ota_diagnostic\",\"firmware\":\"%s\",\"partition\":\"%s\",\"address\":%lu,\"state\":%d,\"stateError\":%d,\"elfSha256\":\"%s\",\"glyphHits\":%u,\"glyphMisses\":%u,\"fastFills\":%u,\"fastMasks\":%u}\n",
        esp_app_get_description()->version,running?running->label:"none",running?(unsigned long)running->address:0,
        (int)state,(int)status,hash,tab5_glyph_hits,tab5_glyph_misses,tab5_fast_fills,tab5_fast_masks);
    if(n>0&&(size_t)n<sizeof(out))usb_write(out,n);
}
static void usb_rpc(cJSON *root) {
    device_config cfg=device_get_config();
    const char *id=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"deviceId"));
    if(!cfg.paired||!id||strcmp(id,cfg.id))return;
    // Heap allocation avoids overflowing the CDC task's 8 KiB stack.
    uint8_t *bytes=malloc(16393);unsigned char *encoded=malloc(22000);size_t n=0,written=0;
    if(!bytes||!encoded){free(bytes);free(encoded);return;}
    const char *payload=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"data"));
    bool ok;
    if(payload)ok=strlen(payload)<22000&&mbedtls_base64_decode(bytes,16393,&n,(uint8_t *)payload,strlen(payload))==0&&rpc_link_write(LINK_USB,bytes,n);
    else {
        cJSON *limit=cJSON_GetObjectItemCaseSensitive(root,"chunk");
        // Old bridges do not announce their read size; keep their 2 KiB frames.
        unsigned capacity=cJSON_IsNumber(limit)&&limit->valuedouble==16384?16392:2056;
        n=rpc_link_read(LINK_USB,bytes,capacity);ok=n>0;
    }
    cJSON *reply=cJSON_CreateObject();cJSON_AddStringToObject(reply,"type","tab5_rpc");
    cJSON_AddStringToObject(reply,"deviceId",cfg.id);cJSON_AddBoolToObject(reply,"ok",ok);
    cJSON *tag=cJSON_GetObjectItemCaseSensitive(root,"tag");if(cJSON_IsString(tag))cJSON_AddStringToObject(reply,"tag",tag->valuestring);
    if(!payload&&ok&&mbedtls_base64_encode(encoded,22000,&written,bytes,n)==0){encoded[written]=0;cJSON_AddStringToObject(reply,"data",(char *)encoded);}
    char *json=cJSON_PrintUnformatted(reply);
    if(json){usb_write("@AIBOT ",7);usb_write(json,strlen(json));usb_write("\n",1);free(json);}
    cJSON_Delete(reply);free(bytes);free(encoded);
}
#include "usb_binary.h"
static void usb_binary_reply(usb_binary *b,bool reading) {
    unsigned n=reading?rpc_link_read(LINK_USB,b->data,16392):0;
    bool ok=reading?n>=8:rpc_link_write(LINK_USB,b->data,b->want);
    uint8_t header[16];usb_binary_header(header,b->tag,n,ok);
    usb_write((char *)header,sizeof(header));if(n)usb_write((char *)b->data,n);
    b->used=b->want=0;
}
static void usb_binary_start(usb_binary *b,cJSON *root) {
    device_config cfg=device_get_config();unsigned count;uint32_t tag;
    if(!cfg.paired||!usb_binary_command(root,cfg.id,&tag,&count))return;
    if(!b->data)b->data=heap_caps_malloc(USB_BINARY_MAX,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!b->data){b->failed=true;uint8_t header[16];usb_binary_header(header,tag,0,false);usb_write((char *)header,16);return;}
    b->used=0;b->want=count;b->tag=tag;b->deadline=esp_timer_get_time()/1000+2500;
    if(!count)usb_binary_reply(b,true);
}
static void write_crash_diagnostic(void) {
    // Only the CDC task calls this; keep diagnostic output off its 8 KiB stack.
    static char trace[3072],out[3200];crash_record_json(trace,sizeof(trace));
    int n=snprintf(out,sizeof(out),"@AIBOT {\"type\":\"tab5_crash_diagnostic\",\"trace\":%s}\n",trace);
    if(n>0&&(size_t)n<sizeof(out))usb_write(out,n);
}
static void write_reply(const char *type,uint64_t seq) {
    device_config cfg=device_get_config();static char out[4096];int64_t now=esp_timer_get_time()/1000;
    xSemaphoreTake(device_mutex,portMAX_DELAY);link_kind active=link_state_active(&device_links,now);
    unsigned ready=assets_ready(),cached=assets_cached();char asset_ids[27];assets_ids(asset_ids);long long ages[3];for(int i=0;i<3;i++)ages[i]=device_links.received_ms[i]<0?-1:now-device_links.received_ms[i];xSemaphoreGive(device_mutex);
    char camera_diag[128],display_diag[1024],photo_diag[96],upload_diag[96];camera_preview_diagnostics(camera_diag,sizeof(camera_diag));
    codex_remote_upload_diagnostics(upload_diag,sizeof(upload_diag));
    display_diagnostics_format(display_diag,sizeof(display_diag));
    photo_diagnostics(photo_diag,sizeof(photo_diag));
    char camera_log[320];camera_preview_driver_error_hex(camera_log,sizeof(camera_log));
    int n=snprintf(out,sizeof(out),"@AIBOT {\"version\":1,\"rpcVersion\":1,\"rpcUsbChunk\":16384,\"rpcUsbBinary\":1,\"telemetryVersion\":1,\"usbPacked\":1,\"type\":\"%s\",\"deviceId\":\"%s\",\"firmware\":\"%s\",\"sequence\":%llu,\"active\":\"%s\",\"wifiConnected\":%s,\"bleReady\":%s,\"ageMs\":[%lld,%lld,%lld],\"bleConnected\":%s,\"bleConnectCount\":%u,\"bleDisconnectReason\":%d,\"assetsReady\":%u,\"assetsCached\":%u,\"assetIds\":\"%s\",\"uiPage\":%d,\"uptimeMs\":%lld,\"resetReason\":%d,\"saverActive\":%d,\"pcWakeCount\":%u,\"uiAgeMs\":%u,\"uiDataAgeMs\":%d,\"taskSelected\":%d,\"inputSessionReady\":%d,\"voiceCheck\":%d,\"voiceAgeMs\":%d,\"voiceStage\":%d,\"voiceHttp\":%d,\"voiceRequestMs\":%d,\"voiceSeq\":%d,\"backlightChanges\":%u,\"backlightPercent\":%d,\"lcdUnderruns\":%u,\"rotateUs\":%u,\"rotatePeakUs\":%u,\"flushCount\":%u,\"flushErrors\":%u,\"cameraDiag\":\"%s\",\"displayDiag\":\"%s\",\"photoDiag\":\"%s\",\"cameraLogHex\":\"%s\",\"photoUploadDiag\":\"%s\"}\n",type,cfg.id,esp_app_get_description()->version,(unsigned long long)seq,link_name(active),wifi_connected?"true":"false",ble_available?"true":"false",ages[0],ages[1],ages[2],ble_connected?"true":"false",ble_connect_count,ble_disconnect_reason,ready,cached,asset_ids,tab5_ui_page,now,esp_reset_reason(),tab5_saver_active,tab5_pc_wakes,tab5_ui_age_ms(),tab5_ui_data_age_ms,tab5_ui_task_selected,tab5_ui_session_ready,tab5_ui_voice_check,tab5_ui_voice_age_ms,tab5_voice_http_stage,tab5_voice_http_status,tab5_voice_request_ms,tab5_voice_last_seq,tab5_backlight_changes,tab5_backlight_percent,tab5_lcd_underruns,tab5_display_rotate_us,tab5_display_rotate_peak_us,tab5_display_flush_count,tab5_display_flush_errors,camera_diag,display_diag,photo_diag,camera_log,upload_diag);
    if(n<0||(size_t)n>=sizeof(out))return;
    usb_write(out,n);
}
// CDC task context only: TinyUSB callbacks must not acquire application locks.
static bool usb_link_watch(bool *was_ready) {
    bool ready=tab5_usb_connected();
    if(*was_ready&&!ready) {
        xSemaphoreTake(device_mutex,portMAX_DELAY);
        link_state_disconnect(&device_links,LINK_USB);
        xSemaphoreGive(device_mutex);
        rpc_link_reset(LINK_USB); // Cancel the old mailbox and wake its owner.
    }
    *was_ready=ready;
    return ready;
}
static void task(void *arg) {
    char *line=malloc(TAB5_MAX_FRAME+1);size_t used=0;bool overflow=false;uint8_t input[256];
    if(!line){vTaskDelete(NULL);return;}
    bool was_ready=false;usb_binary binary={0};
    while(true) {
        if(!usb_link_watch(&was_ready)) {
            // A partial JSON frame must not span unplug/suspend and reconnect.
            used=0;overflow=false;binary.used=binary.want=0;binary.failed=false;size_t discarded=0;
            tinyusb_cdcacm_read(TINYUSB_CDC_ACM_0,input,sizeof(input),&discarded);
            vTaskDelay(pdMS_TO_TICKS(10));continue;
        }
        size_t received=0;
        if(usb_binary_expire(&binary,esp_timer_get_time()/1000)){used=0;overflow=true;rpc_link_reset(LINK_USB);}
        tinyusb_cdcacm_read(TINYUSB_CDC_ACM_0,input,sizeof(input),&received);
        int count=(int)received;
        if(count==0)vTaskDelay(pdMS_TO_TICKS(1));
        for(int i=0;i<count;i++) {
            if(binary.failed)continue; // framing is recovered only by a CDC reconnect
            if(binary.want){if(usb_binary_feed(&binary,input[i]))usb_binary_reply(&binary,false);continue;}
            if(input[i]=='\n') {
                line[used]=0;
                if(!overflow&&used>7&&!strncmp(line,"@AIBOT ",7)) {
                    cJSON *root=cJSON_Parse(line+7);cJSON *type=cJSON_GetObjectItemCaseSensitive(root,"type");
                    if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_ping")) write_reply("tab5_hello",0);
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_rpc")) usb_rpc(root);
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_rpc_binary")) usb_binary_start(&binary,root);
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_benchmark")) {
                        device_config cfg=device_get_config();const char *id=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"deviceId"));
                        cJSON *v=cJSON_GetObjectItemCaseSensitive(root,"version");const char *action=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"action"));
                        if(cfg.paired&&id&&!strcmp(cfg.id,id)&&cJSON_IsNumber(v)&&v->valuedouble==1&&action) {
                            if(!strcmp(action,"start"))transport_benchmark_start();else if(!strcmp(action,"cancel"))transport_benchmark_cancel();
                            char *value=heap_caps_malloc(3600,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);if(!value){cJSON_Delete(root);used=0;continue;}transport_benchmark_diagnostics(value,3600);
                            char power[48];wifi_performance_diagnostics(power,sizeof(power));
                            cJSON *reply=cJSON_CreateObject();cJSON_AddStringToObject(reply,"type","tab5_benchmark");cJSON_AddStringToObject(reply,"deviceId",cfg.id);cJSON_AddStringToObject(reply,"result",value);cJSON_AddStringToObject(reply,"wifiPower",power);free(value);
                            char *wire=cJSON_PrintUnformatted(reply);if(wire){usb_write("@AIBOT ",7);usb_write(wire,strlen(wire));usb_write("\n",1);free(wire);}cJSON_Delete(reply);
                        }
                    }
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_ota_status")) write_ota_diagnostic();
                    else if(cJSON_IsString(type)&&(!strcmp(type->valuestring,"tab5_wifi_list")||!strcmp(type->valuestring,"tab5_wifi_forget"))) {
                        device_config cfg=device_get_config();
                        const char *id=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"deviceId"));
                        cJSON *version=cJSON_GetObjectItemCaseSensitive(root,"version");
                        if(cfg.paired&&id&&!strcmp(id,cfg.id)&&cJSON_IsNumber(version)&&version->valueint==1) {
                            if(!strcmp(type->valuestring,"tab5_wifi_forget")) {
                                const char *ssid=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"ssid"));
                                write_reply(ssid&&tab5_ui_wifi_forget(ssid)?"tab5_wifi_forgotten":"tab5_wifi_rejected",0);
                            } else {
                                cJSON *response=cJSON_CreateObject(),*networks=device_wifi_public_list();
                                if(response&&networks) {
                                    cJSON_AddNumberToObject(response,"version",1);
                                    cJSON_AddStringToObject(response,"type","tab5_wifi_list");
                                    cJSON_AddStringToObject(response,"deviceId",cfg.id);
                                    cJSON_AddItemToObject(response,"networks",networks);networks=NULL;
                                    char *json=cJSON_PrintUnformatted(response);
                                    if(json){usb_write("@AIBOT ",7);usb_write(json,strlen(json));usb_write("\n",1);free(json);}
                                }
                                cJSON_Delete(networks);cJSON_Delete(response);
                            }
                        }
                    }
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_crash_status")) write_crash_diagnostic();
                    else if(cJSON_IsString(type)&&(!strcmp(type->valuestring,"tab5_metrics")||!strcmp(type->valuestring,"tab5_status")||!strcmp(type->valuestring,"tab5_packed"))) {
                        bool metrics=!strcmp(type->valuestring,"tab5_metrics");
                        // Dispatch no longer retains a second full catalog tree.
                        // Packed USB frames are full status only; metrics stay raw.
                        cJSON_Delete(root);root=NULL;uint64_t seq=0;
                        bool ok=device_receive(line+7,LINK_USB,&seq);
                        if(ok&&!metrics)write_reply("tab5_ack",seq);
                        else {char ack[128];int n=snprintf(ack,sizeof(ack),"@AIBOT {\"type\":\"%s%s\",\"sequence\":%llu}\n",metrics?"tab5_metrics_ack":"tab5_ack",ok?"":"_rejected",(unsigned long long)seq);usb_write(ack,n);}
                    }
#ifdef TAB5_USB_HID
                    else if(cJSON_IsString(type)&&!strcmp(type->valuestring,"tab5_hid_status")) {
                        extern unsigned tab5_hid_magic,tab5_hid_stage,tab5_hid_error;
                        extern unsigned tab5_hid_previous_stage(void);
                        device_config current=device_get_config();
                        char status[200];int n=snprintf(status,sizeof(status),"@AIBOT {\"type\":\"hid_status\",\"deviceId\":\"%s\",\"valid\":%s,\"stage\":%u,\"previousStage\":%u,\"error\":%u}\n",current.id,tab5_hid_magic==0x48494435?"true":"false",tab5_hid_stage,tab5_hid_previous_stage(),tab5_hid_error);
                        usb_write(status,n);
                    }
#endif
#ifdef TAB5_USB_HID
                    else if(cJSON_IsString(type)&&(!strcmp(type->valuestring,"tab5_hid_toggle")
#ifdef TAB5_HID_PROBE
                        ||!strcmp(type->valuestring,"tab5_hid_probe")||!strcmp(type->valuestring,"tab5_hid_enumerate")||!strcmp(type->valuestring,"tab5_hid_keycheck")
#endif
                        )) {
                        int key_mode=1;bool auto_escape=false;
#ifndef TAB5_HID_PROBE
                        const char *shortcut=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(root,"shortcut"));
                        if(shortcut&&!strcmp(shortcut,"RightAltSpace"))key_mode=3;
                        else if(shortcut&&!strcmp(shortcut,"CtrlAltSpace"))key_mode=4;
                        else if(shortcut&&strcmp(shortcut,"LeftAltSpace")){cJSON_Delete(root);used=0;continue;}
#endif
#ifdef TAB5_HID_PROBE
                        key_mode=!strcmp(type->valuestring,"tab5_hid_enumerate")?0:!strcmp(type->valuestring,"tab5_hid_keycheck")?2:1;
                        auto_escape=!strcmp(type->valuestring,"tab5_hid_probe");
#endif
                        if(!device_get_config().paired){cJSON_Delete(root);used=0;continue;}
                        write_reply("tab5_hid_probe_start",0);
                        // The normal composite device does not re-enumerate;
                        // its acknowledgement needs no old diagnostic pause.
                        if(auto_escape)vTaskDelay(pdMS_TO_TICKS(300));
                        extern void tab5_hid_probe(int,bool);tab5_hid_probe(key_mode,auto_escape);
                    }
#endif
                    else if(root) {const char *reply=NULL;if(device_command(root,&reply)&&reply)write_reply(reply,0);}
                    cJSON_Delete(root);
                }
                used=0;overflow=false;
            } else if(!overflow&&used<TAB5_MAX_FRAME) line[used++]=(char)input[i];else overflow=true;
        }
    }
}
void usb_start(void) {
    device_config cfg=device_get_config();
    snprintf(usb_serial,sizeof(usb_serial),"TAB5-%s",cfg.id);
    // USB-C is wired to PHY0. IDF 5.4.2 phy_select(0) falls through to
    // PHY1, so route this volatile mux explicitly before TinyUSB starts.
    LP_SYS.usb_ctrl.sw_hw_usb_phy_sel=1;
    LP_SYS.usb_ctrl.sw_usb_phy_sel=1;
    tinyusb_config_t usb=TINYUSB_DEFAULT_CONFIG();
    // Keep USB control transfers responsive while audio capture and CDC frames
    // are active on the other tasks. A missed descriptor request drops COM/HID.
    usb.task=TINYUSB_TASK_CUSTOM(8192,8,1);
    usb.port=TINYUSB_PORT_FULL_SPEED_0;
    usb.descriptor.device=&usb_device;
    usb.descriptor.string=usb_strings;
    usb.descriptor.string_count=sizeof(usb_strings)/sizeof(usb_strings[0]);
    usb.descriptor.full_speed_config=usb_configuration;
    esp_err_t err=tinyusb_driver_install(&usb);
    if(err!=ESP_OK) {
        printf("TAB5_USB_COMPOSITE_INIT error=%d\n",err);
        return; // Wi-Fi, BLE, and the display still start for diagnosis.
    }
    tinyusb_config_cdcacm_t cdc={.cdc_port=TINYUSB_CDC_ACM_0};
    err=tinyusb_cdcacm_init(&cdc);
    if(err!=ESP_OK) {
        printf("TAB5_USB_CDC_INIT error=%d\n",err);
        tinyusb_driver_uninstall();
        return;
    }
    esp_err_t shutdown_result=esp_register_shutdown_handler(usb_prepare_restart);
    if(shutdown_result!=ESP_OK)printf("TAB5_USB_SHUTDOWN_INIT error=%d\n",shutdown_result);
    if(xTaskCreate(task,"tab5_usb",8192,NULL,6,NULL)!=pdPASS)
        printf("TAB5_USB_TASK_INIT error=out_of_memory\n");
}





