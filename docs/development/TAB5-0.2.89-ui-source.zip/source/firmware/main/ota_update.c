#include "ota_update.h"
#include "device.h"
#include "freertos/queue.h"
#include "freertos/idf_additions.h"
#include "rpc_link.h"
#include "wifi_performance.h"
#include "crash_record.h"
#include "esp_http_client.h"
#include "esp_ota_ops.h"
#include "esp_app_desc.h"
#include "esp_partition.h"
#include "esp_system.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "bsp/m5stack_tab5.h"
#include "mbedtls/sha256.h"
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char sha[65], version[32], offer_id[33], notes[1025]; int size; } ota_offer;
static atomic_bool busy;
static atomic_bool completed, completion_presented;
static atomic_int progress_percent;
static ota_offer pending_offer;
static char last_offer[33], message[96]="未开始";
static char target_version[32];
bool ota_update_busy(void){return atomic_load(&busy);}
bool ota_update_completed(void){return atomic_load(&completed);}
int ota_update_progress(void){return atomic_load(&progress_percent);}
void ota_update_completion_presented(void) {
    if(atomic_load(&completed))atomic_store(&completion_presented,true);
}
bool ota_update_available(void) {
    xSemaphoreTake(device_mutex,portMAX_DELAY);bool available=pending_offer.size>0;xSemaphoreGive(device_mutex);
    return available&&!ota_update_busy();
}

static void report(const char *value) {
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    snprintf(message,sizeof(message),"%s",value);
    xSemaphoreGive(device_mutex);
}
void ota_update_status(char *out,size_t size) {
    if(!out||!size)return;
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    snprintf(out,size,"%s",message);
    xSemaphoreGive(device_mutex);
}
void ota_update_target_version(char *out,size_t size) {
    if(!out||!size)return;
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    snprintf(out,size,"%s",target_version);
    xSemaphoreGive(device_mutex);
}
void ota_update_offer_details(char *version,size_t version_size,char *notes,size_t notes_size) {
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    if(version&&version_size)snprintf(version,version_size,"%s",pending_offer.size?pending_offer.version:"");
    if(notes&&notes_size)snprintf(notes,notes_size,"%s",pending_offer.size?pending_offer.notes:"");
    xSemaphoreGive(device_mutex);
}
static bool valid_hex(const char *value,size_t length) {
    if(!value||strlen(value)!=length)return false;
    for(size_t i=0;i<length;i++)if(!((value[i]>='0'&&value[i]<='9')||(value[i]>='a'&&value[i]<='f')))return false;
    return true;
}
static bool same_running_image(const esp_partition_t *running,const ota_offer *offer) {
    // Different embedded versions cannot have identical image hashes.
    if(strcmp(esp_app_get_description()->version,offer->version))return false;
    if(offer->size>(int)running->size)return false;
    mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);mbedtls_sha256_starts(&sha,0);
    uint8_t chunk[1024];int at=0;
    while(at<offer->size) {
        int n=offer->size-at;if(n>(int)sizeof(chunk))n=sizeof(chunk);
        if(esp_partition_read(running,at,chunk,n)!=ESP_OK){mbedtls_sha256_free(&sha);return false;}
        mbedtls_sha256_update(&sha,chunk,n);at+=n;
        if(at%65536==0)vTaskDelay(1);
    }
    uint8_t digest[32];mbedtls_sha256_finish(&sha,digest);mbedtls_sha256_free(&sha);
    char hex[65];for(int i=0;i<32;i++)sprintf(hex+i*2,"%02x",digest[i]);
    return !strcmp(hex,offer->sha);
}
// Two owned PSRAM blocks overlap network/USB reception with flash writing.
// The producer alone touches the transport. A block is never recycled until
// esp_ota_write returns, and all exits join the producer before closing I/O.
typedef struct {int slot,count,offset;} ota_block;
typedef struct {
    uint8_t *data[2];QueueHandle_t free_blocks,ready_blocks;SemaphoreHandle_t done;
    atomic_bool stop;bool started;
    esp_http_client_handle_t client;link_kind transport;const ota_offer *offer;
    int64_t read_us;
} ota_reader;
static bool ota_queue(QueueHandle_t queue,void *value,bool send,ota_reader *reader) {
    while(!atomic_load(&reader->stop)) {
        if((send?xQueueSend(queue,value,pdMS_TO_TICKS(20)):xQueueReceive(queue,value,pdMS_TO_TICKS(20)))==pdTRUE)return true;
    }
    return false;
}
static void ota_receive(void *arg) {
    ota_reader *reader=arg;int offset=0;
    while(offset<reader->offer->size&&!atomic_load(&reader->stop)) {
        int slot;if(!ota_queue(reader->free_blocks,&slot,false,reader))break;
        int want=reader->offer->size-offset;if(want>65536)want=65536;
        int filled=0;int64_t began=esp_timer_get_time();
        while(filled<want&&!atomic_load(&reader->stop)) {
            int got=reader->transport==LINK_WIFI?esp_http_client_read(reader->client,(char*)reader->data[slot]+filled,want-filled):
                rpc_ota_read(reader->transport,reader->offer->sha,reader->offer->offer_id,offset+filled,reader->data[slot]+filled,want-filled);
            if(got<=0||got>want-filled)break;
            filled+=got;
            char progress[96];snprintf(progress,sizeof(progress),"已接收 %d / %d KB",(offset+filled+1023)/1024,(reader->offer->size+1023)/1024);
            report(progress);atomic_store(&progress_percent,(int)((int64_t)(offset+filled)*99/reader->offer->size));
        }
        reader->read_us+=esp_timer_get_time()-began;
        ota_block block={slot,filled==want?filled:-1,offset};
        if(!ota_queue(reader->ready_blocks,&block,true,reader)||filled!=want)break;
        offset+=filled;vTaskDelay(pdMS_TO_TICKS(1));
    }
    xSemaphoreGive(reader->done);vTaskDeleteWithCaps(NULL);
}
static ota_reader *ota_reader_create(void) {
    ota_reader *r=calloc(1,sizeof(*r));if(!r)return NULL;
    for(int i=0;i<2;i++)r->data[i]=heap_caps_malloc(65536,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    r->free_blocks=xQueueCreate(2,sizeof(int));r->ready_blocks=xQueueCreate(2,sizeof(ota_block));r->done=xSemaphoreCreateBinary();
    if(!r->data[0]||!r->data[1]||!r->free_blocks||!r->ready_blocks||!r->done) {
        for(int i=0;i<2;i++)free(r->data[i]);
        if(r->free_blocks)vQueueDelete(r->free_blocks);
        if(r->ready_blocks)vQueueDelete(r->ready_blocks);
        if(r->done)vSemaphoreDelete(r->done);
        free(r);return NULL;
    }
    for(int i=0;i<2;i++)xQueueSend(r->free_blocks,&i,0);
    return r;
}
static void ota_reader_join(ota_reader *r) {
    if(!r||!r->started)return;
    atomic_store(&r->stop,true);xSemaphoreTake(r->done,portMAX_DELAY);r->started=false;
}
static void ota_reader_free(ota_reader *r) {
    if(!r)return;
    ota_reader_join(r);
    free(r->data[0]);free(r->data[1]);vQueueDelete(r->free_blocks);vQueueDelete(r->ready_blocks);vSemaphoreDelete(r->done);free(r);
}
static void install(void *arg) {
    ota_offer *offer=arg;
    ota_trace_begin(offer->size);
    device_config cfg=device_get_config();
    const esp_partition_t *next=esp_ota_get_next_update_partition(NULL);
    const esp_partition_t *running=esp_ota_get_running_partition();
    esp_ota_handle_t handle=0;
    esp_http_client_handle_t client=NULL;
    bool opened=false,writing=false,already_current=false;
    link_kind transport=rpc_ota_link_select();
    bool wifi_bulk=transport==LINK_WIFI;
    if(wifi_bulk)wifi_performance_bulk(true);
    int received=0;esp_err_t error=ESP_OK;
    uint8_t *chunk=NULL,*flash_buffer=NULL;ota_reader *reader=NULL;
    // 64 KiB aligned writes let the SDK erase a flash block instead of sixteen
    // 4 KiB sectors. Keep the final partial block bounded and verify as before.
    int64_t transfer_started=0,read_us=0,write_us=0;
    char failure[96]="固件更新失败，请检查连接后重新发起";
    if(transport==LINK_NONE) {
        snprintf(failure,sizeof(failure),"所选连接尚未就绪，请连接电脑");goto finish;
    }
    if(!cfg.paired||transport==LINK_NONE||(transport==LINK_WIFI&&(!cfg.host[0]||cfg.port<=0))||!next||!running||
        next->address==running->address||offer->size>(int)next->size) {
        snprintf(failure,sizeof(failure),"当前分区或配对状态不支持升级");goto finish;
    }
    if(same_running_image(running,offer)){already_current=true;report("当前已是这份固件");goto finish;}
    // Keep network/SDIO internal RAM available; flash driver handles PSRAM input.
    reader=ota_reader_create();
    if(!reader){snprintf(failure,sizeof(failure),"升级缓冲不足，请稍后重试");goto finish;}
    // IDF 5.4's SPI1 driver copies external RAM input through a 32-byte stack
    // buffer, acquiring/releasing the flash bus for every piece. An internal
    // staging block uses the driver's normal 8 KiB writes instead. Retain at
    // least 96 KiB for SDIO/USB and use the existing path under memory pressure.
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>=160*1024)
        flash_buffer=heap_caps_malloc(65536,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    printf("TAB5_OTA_FLASH_BUFFER bytes=%u internalFree=%u\n",flash_buffer?65536u:0u,
        (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT));
    if(transport==LINK_WIFI) {
    char nonce[33],proof[65],proof_input[155],url[190];device_nonce(nonce);
    snprintf(proof_input,sizeof(proof_input),"GET|/tab5/v1/ota/%s|%s|%s",offer->sha,cfg.id,nonce);
    device_proof(proof_input,proof);
    snprintf(url,sizeof(url),"http://%s:%d/tab5/v1/ota/%s",cfg.host,cfg.port,offer->sha);
    esp_http_client_config_t options={.url=url,.timeout_ms=10000,.disable_auto_redirect=true,.buffer_size=4096};
    ota_trace_update(OTA_TRACE_CONNECT,0,0);
    client=esp_http_client_init(&options);if(!client)goto finish;
    esp_http_client_set_header(client,"X-AIBot-Device",cfg.id);
    esp_http_client_set_header(client,"X-AIBot-Nonce",nonce);
    esp_http_client_set_header(client,"X-AIBot-Proof",proof);
    esp_http_client_set_header(client,"X-AIBot-OTA-Flow","tcp-v2");
    if(esp_http_client_open(client,0)!=ESP_OK)goto finish;
    opened=true;
    int64_t length=esp_http_client_fetch_headers(client);
    if(esp_http_client_get_status_code(client)!=200||length!=offer->size) {
        snprintf(failure,sizeof(failure),"电脑未提供匹配的固件，请重新选择");goto finish;
    }
    }
    // Erase only the sectors about to be written. Avoid a multi-megabyte erase
    // before download progress starts; SDK flash locking remains unchanged.
    ota_trace_update(OTA_TRACE_BEGIN,0,0);
    error=esp_ota_begin(next,OTA_WITH_SEQUENTIAL_WRITES,&handle);
    if(error!=ESP_OK) {
        if(handle)esp_ota_abort(handle);
        snprintf(failure,sizeof(failure),"无法写入备用固件分区");goto finish;
    }
    writing=true;
    mbedtls_sha256_context sha;mbedtls_sha256_init(&sha);mbedtls_sha256_starts(&sha,0);
    report("等待接收固件 · 0 KB");
    transfer_started=esp_timer_get_time();
    reader->client=client;reader->transport=transport;reader->offer=offer;
    // Reception does not write flash; keep its stack out of scarce internal RAM.
    if(xTaskCreateWithCaps(ota_receive,"tab5_ota_rx",8192,reader,4,NULL,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)!=pdPASS) {
        error=ESP_ERR_NO_MEM;
        printf("TAB5_OTA_RX_START_FAILED internalLargest=%u psramLargest=%u\n",
            (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),
            (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
        mbedtls_sha256_free(&sha);snprintf(failure,sizeof(failure),"无法启动固件接收，请重试");goto finish;
    }
    reader->started=true;
    while(received<offer->size) {
        ota_trace_update(OTA_TRACE_READ,received,0);
        ota_block block;
        if(!ota_queue(reader->ready_blocks,&block,false,reader)||block.count<=0||block.offset!=received){error=ESP_FAIL;break;}
        chunk=reader->data[block.slot];int filled=block.count;
        mbedtls_sha256_update(&sha,chunk,filled);
        ota_trace_update(OTA_TRACE_WRITE,received,0);
        int64_t began=esp_timer_get_time();
        if(flash_buffer)memcpy(flash_buffer,chunk,filled);
        error=esp_ota_write(handle,flash_buffer?flash_buffer:chunk,filled);write_us+=esp_timer_get_time()-began;
        if(error!=ESP_OK)break;
        received+=filled;xQueueSend(reader->free_blocks,&block.slot,0);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    ota_reader_join(reader);read_us=reader->read_us;
    ota_trace_timing((unsigned)((esp_timer_get_time()-transfer_started)/1000),(unsigned)(read_us/1000),(unsigned)(write_us/1000));
    ota_trace_update(OTA_TRACE_VERIFY,received,error);
    printf("TAB5_OTA_TIMING bytes=%d elapsedMs=%lld readMs=%lld writeMs=%lld\n",received,
        (long long)((esp_timer_get_time()-transfer_started)/1000),(long long)(read_us/1000),(long long)(write_us/1000));
    if(received==offer->size)report("正在校验固件");
    uint8_t digest[32];mbedtls_sha256_finish(&sha,digest);mbedtls_sha256_free(&sha);
    if(received!=offer->size){snprintf(failure,sizeof(failure),"固件下载中断，原版本保持可用");goto finish;}
    char actual[65];for(int i=0;i<32;i++)sprintf(actual+i*2,"%02x",digest[i]);
    if(strcmp(actual,offer->sha)){snprintf(failure,sizeof(failure),"固件校验失败，原版本保持可用");goto finish;}
    ota_trace_update(OTA_TRACE_IMAGE,received,0);
    error=esp_ota_end(handle);
    if(error!=ESP_OK){writing=false;snprintf(failure,sizeof(failure),"固件格式校验失败，原版本保持可用");goto finish;}
    writing=false;
    esp_app_desc_t description;
    error=esp_ota_get_partition_description(next,&description);
    if(error!=ESP_OK||strcmp(description.project_name,"aibot_tab5")||strcmp(description.version,offer->version)) {
        snprintf(failure,sizeof(failure),"固件身份或启动检查失败，原版本保持可用");goto finish;
    }
    ota_trace_update(OTA_TRACE_BOOT,received,0);
    error=esp_ota_set_boot_partition(next);
    if(error!=ESP_OK){snprintf(failure,sizeof(failure),"启动分区设置失败，原版本保持可用");goto finish;}
    ota_trace_update(OTA_TRACE_DONE,received,0);
    if(client){esp_http_client_close(client);esp_http_client_cleanup(client);client=NULL;opened=false;}
    ota_reader_free(reader);reader=NULL;
    free(flash_buffer);flash_buffer=NULL;
    if(wifi_bulk)wifi_performance_bulk(false);
    free(offer);
    report("3 秒后自动重启");
    atomic_store(&progress_percent,100);
    atomic_store(&completed,true);
    // Start the readable dwell only after the UI renders the success state.
    // Never render LVGL from this worker's small stack or race its display lock.
    for(unsigned waited=0;waited<5000&&!atomic_load(&completion_presented);waited+=50)
        vTaskDelay(pdMS_TO_TICKS(50));
    if(!atomic_load(&completion_presented)) {
        report("升级完成，请手动重启 TAB5");vTaskDelete(NULL);return;
    }
    vTaskDelay(pdMS_TO_TICKS(3000));
    report("正在重启…");vTaskDelay(pdMS_TO_TICKS(500));
    // Hide the panel while CPU reset stops DSI scanout. The new app lights it
    // only after its first rendered frame; saved brightness is not changed.
    esp_err_t backlight=bsp_display_backlight_off();
    if(backlight!=ESP_OK)printf("TAB5_OTA_BACKLIGHT error=%d\n",backlight);
    vTaskDelay(pdMS_TO_TICKS(50));esp_restart();
    return;
finish:
    ota_reader_join(reader);
    ota_trace_update(already_current?OTA_TRACE_DONE:OTA_TRACE_FAILED,received,error);
    if(writing)esp_ota_abort(handle);
    if(client){if(opened)esp_http_client_close(client);esp_http_client_cleanup(client);}
    ota_reader_free(reader);reader=NULL;
    free(flash_buffer);
    if(wifi_bulk)wifi_performance_bulk(false);
    if(!already_current)report(failure);
    free(offer);atomic_store(&busy,false);vTaskDelete(NULL);
}
void ota_update_consider(const char *authenticated_frame) {
    cJSON *root=cJSON_Parse(authenticated_frame);
    if(!root)return;
    cJSON *data=cJSON_GetObjectItemCaseSensitive(root,"data");
    cJSON *ota=cJSON_GetObjectItemCaseSensitive(data,"ota");
    if(!cJSON_IsObject(ota)) {
        if(!atomic_load(&busy)) {
            xSemaphoreTake(device_mutex,portMAX_DELAY);
            if(pending_offer.size)snprintf(message,sizeof(message),"电脑已停止提供固件");
            last_offer[0]=0;pending_offer.size=0;xSemaphoreGive(device_mutex);
        }
        cJSON_Delete(root);return;
    }
    cJSON *sha=cJSON_GetObjectItemCaseSensitive(ota,"sha256");
    cJSON *size=cJSON_GetObjectItemCaseSensitive(ota,"size");
    cJSON *version=cJSON_GetObjectItemCaseSensitive(ota,"version");
    cJSON *offer_id=cJSON_GetObjectItemCaseSensitive(ota,"offerId");
    cJSON *notes=cJSON_GetObjectItemCaseSensitive(ota,"notes");
    if(!cJSON_IsString(sha)||!valid_hex(sha->valuestring,64)||!cJSON_IsNumber(size)||
        size->valuedouble<1024||size->valuedouble>0x6e0000||size->valuedouble!=(double)size->valueint||
        !cJSON_IsString(version)||!version->valuestring||
        strlen(version->valuestring)==0||strlen(version->valuestring)>=32||
        !cJSON_IsString(offer_id)||!valid_hex(offer_id->valuestring,32)) {cJSON_Delete(root);return;}
    if(atomic_load(&busy)){cJSON_Delete(root);return;}
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    // Offers survive on the PC after the device reboots into the new image.
    // Suppress the installed version before enabling the upgrade button.
    const esp_app_desc_t *running=esp_app_get_description();
    if(!strcmp(running->version,version->valuestring)) {
        pending_offer.size=0;
        snprintf(message,sizeof(message),"已是最新版本");
        xSemaphoreGive(device_mutex);cJSON_Delete(root);return;
    }
    bool seen=!strcmp(last_offer,offer_id->valuestring);
    if(!seen) {
        snprintf(pending_offer.sha,sizeof(pending_offer.sha),"%s",sha->valuestring);
        snprintf(pending_offer.version,sizeof(pending_offer.version),"%s",version->valuestring);
        snprintf(pending_offer.offer_id,sizeof(pending_offer.offer_id),"%s",offer_id->valuestring);
        pending_offer.size=size->valueint;
        snprintf(pending_offer.notes,sizeof(pending_offer.notes),"%s",
            cJSON_IsString(notes)&&notes->valuestring&&strlen(notes->valuestring)<sizeof(pending_offer.notes)?notes->valuestring:"");
        snprintf(message,sizeof(message),"新固件 %s · 在此确认后升级",pending_offer.version);
    }
    xSemaphoreGive(device_mutex);
    cJSON_Delete(root);
}
// Called by the UI only after persisting the draft and checking active work.
bool ota_update_request(void) {
    extern bool transport_benchmark_busy(void);
    if(transport_benchmark_busy())return false;
    if(atomic_exchange(&busy,true))return false;
    atomic_store(&completed,false);atomic_store(&completion_presented,false);
    atomic_store(&progress_percent,0);
    ota_offer *offer=calloc(1,sizeof(*offer));
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    bool available=pending_offer.size>0;
    if(offer&&available){*offer=pending_offer;pending_offer.size=0;snprintf(last_offer,sizeof(last_offer),"%s",offer->offer_id);snprintf(target_version,sizeof(target_version),"%s",offer->version);}
    xSemaphoreGive(device_mutex);
    if(!offer||!available){free(offer);atomic_store(&busy,false);return false;}
    report("正在准备固件更新");
    if(!offer||xTaskCreate(install,"tab5_ota",8192,offer,4,NULL)!=pdPASS){
        free(offer);report("无法启动更新任务");
        xSemaphoreTake(device_mutex,portMAX_DELAY);last_offer[0]=0;xSemaphoreGive(device_mutex);
        atomic_store(&busy,false);return false;
    }
    return true;
}
