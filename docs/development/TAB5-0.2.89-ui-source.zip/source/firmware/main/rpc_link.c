#include "rpc_link.h"
#include "device.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "esp_random.h"
#include "esp_http_client.h"
#include "mbedtls/gcm.h"
#include "mbedtls/sha256.h"
#include "mbedtls/base64.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "rpc_mailbox.inc"
#include "rpc_binary.h"
static rpc_profile profiles[3];
static void profile_memory(rpc_profile *p) {
    unsigned internal=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    unsigned psram=heap_caps_get_free_size(MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    unsigned largest=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    if(internal<p->min_internal)p->min_internal=internal;
    if(psram<p->min_psram)p->min_psram=psram;
    if(largest<p->min_largest)p->min_largest=largest;
}
void rpc_profile_reset(link_kind link){if(link<0||link>2)return;profiles[link]=(rpc_profile){.min_internal=UINT32_MAX,.min_psram=UINT32_MAX,.min_largest=UINT32_MAX};}
rpc_profile rpc_profile_get(link_kind link){return link>=0&&link<3?profiles[link]:(rpc_profile){0};}
static SemaphoreHandle_t rpc_lock;
static rpc_mailbox boxes[2];
static SemaphoreHandle_t rpc_done[2];
static SemaphoreHandle_t completion(link_kind link){return link==LINK_USB?rpc_done[0]:link==LINK_BLE?rpc_done[1]:NULL;}
static rpc_mailbox *box(link_kind link){return link==LINK_USB?&boxes[0]:link==LINK_BLE?&boxes[1]:NULL;}
void rpc_link_init(void) {
    if(rpc_lock)return;
    rpc_lock=xSemaphoreCreateMutex();
    for(int i=0;i<2;i++) {
        boxes[i].out=heap_caps_malloc(RPC_REQUEST_MAX,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
        boxes[i].in=heap_caps_malloc(RPC_RESPONSE_MAX,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    }
}
void rpc_link_reset(link_kind link) {
    rpc_mailbox *m=box(link);if(!rpc_lock||!m)return;
    xSemaphoreTake(rpc_lock,portMAX_DELAY);m->generation++;m->active=0;m->peer_seen=0;m->confirmed_ms=0;m->confirmed_session[0]=0;m->complete=false;
    if(completion(link))xSemaphoreGive(completion(link));
    xSemaphoreGive(rpc_lock);
}
size_t rpc_link_read(link_kind link,uint8_t *out,size_t capacity) {
    rpc_mailbox *m=box(link);if(!rpc_lock||!m||!m->out||!m->in||!device_get_config().paired)return 0;
    xSemaphoreTake(rpc_lock,portMAX_DELAY);m->peer_seen=esp_timer_get_time()/1000;
    size_t n=rpc_read(m,out,capacity);xSemaphoreGive(rpc_lock);return n;
}
bool rpc_link_write(link_kind link,const uint8_t *data,size_t size) {
    rpc_mailbox *m=box(link);if(!rpc_lock||!m||!m->in||!device_get_config().paired)return false;
    xSemaphoreTake(rpc_lock,portMAX_DELAY);bool ok=rpc_write(m,data,size);
    if(ok){
        m->peer_seen=esp_timer_get_time()/1000;
        if(m->complete&&completion(link))xSemaphoreGive(completion(link));
    }
    xSemaphoreGive(rpc_lock);return ok;
}
static link_kind select_link(bool read_only) {
    int64_t now=esp_timer_get_time()/1000;link_state links;
    xSemaphoreTake(device_mutex,portMAX_DELAY);links=device_links;xSemaphoreGive(device_mutex);
    for(int i=0;i<3;i++) {
        if(i==LINK_USB&&!tab5_usb_connected())continue;
        if((links.mode!=-1&&links.mode!=i)||links.received_ms[i]<0||now<links.received_ms[i])continue;
        bool fresh=now-links.received_ms[i]<8000;
        if(i==LINK_WIFI){if(fresh&&wifi_connected)return LINK_WIFI;continue;}
        if(!rpc_lock)continue;
        xSemaphoreTake(rpc_lock,portMAX_DELAY);rpc_mailbox *m=box(i);
        if(read_only)fresh=link_state_read_fresh(&links,i,now,m->confirmed_ms,m->confirmed_session);
        bool ready=fresh&&m->out&&m->in&&m->peer_seen&&now>=m->peer_seen&&now-m->peer_seen<8000;xSemaphoreGive(rpc_lock);
        if(ready)return i;
    }
    return LINK_NONE;
}
link_kind rpc_link_select(void){return select_link(false);}
link_kind rpc_read_link_select(void){return select_link(true);}
// Wi-Fi streaming is faster than the current USB mailbox protocol. Do not
// change daily mode or switch transports halfway through an installation.
link_kind rpc_ota_link_select(void) {
    int64_t now=esp_timer_get_time()/1000;link_state links;bool usb_ready=false,ble_ready=false;
    xSemaphoreTake(device_mutex,portMAX_DELAY);links=device_links;xSemaphoreGive(device_mutex);
    if(rpc_lock) {
        xSemaphoreTake(rpc_lock,portMAX_DELAY);rpc_mailbox *m=box(LINK_USB);
        usb_ready=tab5_usb_connected()&&m->out&&m->in&&m->peer_seen&&now>=m->peer_seen&&now-m->peer_seen<8000;
        m=box(LINK_BLE);ble_ready=ble_connected&&m->out&&m->in&&m->peer_seen&&now>=m->peer_seen&&now-m->peer_seen<8000;
        xSemaphoreGive(rpc_lock);
    }
    return link_state_ota_bulk(&links,now,wifi_connected,usb_ready,ble_ready);
}
bool rpc_link_ready(void){return rpc_link_select()!=LINK_NONE;}
link_kind rpc_image_link_select(const char *session) {
    int64_t now=esp_timer_get_time()/1000;link_state links;bool ready[2]={false,false};
    xSemaphoreTake(device_mutex,portMAX_DELAY);links=device_links;xSemaphoreGive(device_mutex);
    if(rpc_lock) {
        xSemaphoreTake(rpc_lock,portMAX_DELAY);
        for(int i=0;i<2;i++){rpc_mailbox *m=&boxes[i];ready[i]=m->out&&m->in&&m->peer_seen&&now>=m->peer_seen&&now-m->peer_seen<8000;}
        xSemaphoreGive(rpc_lock);
    }
    return link_state_image(&links,now,session,wifi_connected,ready[0]&&tab5_usb_connected(),ready[1]);
}
bool rpc_read_link_ready(void){return rpc_read_link_select()!=LINK_NONE;}
static uint8_t *exchange(link_kind link,const char *nonce,const char *proof,const uint8_t *data,size_t size,size_t *reply_size,uint32_t generation) {
    *reply_size=0;rpc_mailbox *m=box(link);
    if(!rpc_lock||!m||!m->out||!m->in||size+96>RPC_REQUEST_MAX)return NULL;
    xSemaphoreTake(rpc_lock,portMAX_DELAY);
    if(m->active||m->generation!=generation||(link==LINK_USB&&!tab5_usb_connected())){xSemaphoreGive(rpc_lock);return NULL;}
    // Own each wakeup until detachment; reconnect cannot steal it. IDF's
    // FreeRTOS allocator keeps the object in internal RAM, even when the
    // calling task uses a PSRAM stack (which cannot host this control object).
    SemaphoreHandle_t done=xSemaphoreCreateBinary();
    rpc_done[link==LINK_USB?0:1]=done;
    memcpy(m->out,nonce,32);memcpy(m->out+32,proof,64);memcpy(m->out+96,data,size);
    m->size=size+96;m->offset=m->offered=m->received=m->expected=0;m->complete=false;
    if(!++m->serial)++m->serial;
    uint32_t serial=m->active=m->serial;xSemaphoreGive(rpc_lock);
    uint8_t *reply=NULL;int64_t deadline=esp_timer_get_time()/1000+75000;
    while(esp_timer_get_time()/1000<deadline) {
        xSemaphoreTake(rpc_lock,portMAX_DELAY);
        if(m->active!=serial){xSemaphoreGive(rpc_lock);break;}
        if(m->complete) {
            reply=heap_caps_malloc(m->expected,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
            if(reply){memcpy(reply,m->in,m->expected);*reply_size=m->expected;}
            xSemaphoreGive(rpc_lock);break;
        }
        xSemaphoreGive(rpc_lock);
        // Complete/reset wake the owning request immediately. Keep the original
        // bounded deadline and a low-memory fallback, never poll faster in a loop.
        int64_t remaining=deadline-esp_timer_get_time()/1000;
        if(remaining<=0)break;
        if(done){if(xSemaphoreTake(done,pdMS_TO_TICKS(remaining))!=pdTRUE)break;}
        else vTaskDelay(pdMS_TO_TICKS(10));
    }
    xSemaphoreTake(rpc_lock,portMAX_DELAY);
    if(m->active==serial)m->active=0;
    if(completion(link)==done)rpc_done[link==LINK_USB?0:1]=NULL;
    xSemaphoreGive(rpc_lock);
    if(done)vSemaphoreDelete(done);
    return reply;
}
static uint8_t *http_exchange(esp_http_client_handle_t client,const device_config *cfg,const char *nonce,const char *proof,const uint8_t *packet,size_t size,size_t *reply_size) {
    *reply_size=0;
    esp_http_client_set_header(client,"X-AIBot-Device",cfg->id);esp_http_client_set_header(client,"X-AIBot-Nonce",nonce);esp_http_client_set_header(client,"X-AIBot-Proof",proof);
    if(esp_http_client_open(client,size)!=ESP_OK){esp_http_client_close(client);return NULL;}
    size_t sent=0;
    while(sent<size){int n=esp_http_client_write(client,(char *)packet+sent,size-sent);if(n<=0){esp_http_client_close(client);return NULL;}sent+=n;}
    int64_t length=esp_http_client_fetch_headers(client);
    if(esp_http_client_get_status_code(client)!=200||length<28||length>RPC_RESPONSE_MAX){esp_http_client_close(client);return NULL;}
    uint8_t *reply=heap_caps_malloc(length,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);if(!reply){esp_http_client_close(client);return NULL;}
    size_t used=0;
    while(used<(size_t)length){int n=esp_http_client_read(client,(char *)reply+used,length-used);if(n<=0){free(reply);esp_http_client_close(client);return NULL;}used+=n;}
    *reply_size=used;return reply;
}
static cJSON *rpc_call_impl(link_kind link,cJSON *request,int *status,char nonce[33],esp_http_client_handle_t http,
    const uint8_t *upload,size_t upload_size,uint8_t *download,size_t capacity,size_t *received) {
    if(received)*received=0;
    if((upload&&(!upload_size||upload_size>RPC_BULK_DATA||cJSON_HasObjectItem(request,"data")))||(download&&!received)){*status=0;return NULL;}
    *status=0;device_config cfg=device_get_config();if(!cfg.paired)return NULL;
    if(link!=LINK_USB&&link!=LINK_BLE&&!(link==LINK_WIFI&&http&&wifi_connected))return NULL;
    const char *kind=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(request,"kind"));
    // RAM benchmark owns these counters; normal user traffic is excluded.
    rpc_profile *profile=kind&&!strcmp(kind,"benchmark")?&profiles[link]:NULL;
    int64_t profile_start=esp_timer_get_time();
    if(profile)profile_memory(profile);
    if(!rpc_lock||(link==LINK_USB&&!tab5_usb_connected()))return NULL;
    xSemaphoreTake(rpc_lock,portMAX_DELAY);uint32_t generation=box(link)?box(link)->generation:0;xSemaphoreGive(rpc_lock);
    // Use the paired bridge's latest clock/session, including during a long
    // image upload. Never extend an old request's authorization window.
    char session[40];double epoch=0;int64_t age,received_at;bool binary=false,bulk=false;
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    snprintf(session,sizeof(session),"%s",device_links.session[link]);
    cJSON *cap=cJSON_GetObjectItemCaseSensitive(device_snapshots[link],"rpcBinary");binary=cJSON_IsNumber(cap)&&cap->valuedouble==1;
    cap=cJSON_GetObjectItemCaseSensitive(device_snapshots[link],"rpcBulk");bulk=binary&&cJSON_IsNumber(cap)&&cap->valuedouble==1;
    cJSON *clock=cJSON_GetObjectItemCaseSensitive(device_snapshots[link],"epochMilliseconds");
    if(cJSON_IsNumber(clock))epoch=clock->valuedouble;
    received_at=device_links.received_ms[link];
    age=esp_timer_get_time()/1000-received_at;
    xSemaphoreGive(device_mutex);
    if(!session[0]||epoch<=0||received_at<0||age<0||age>90000)return NULL;
    if(upload_size>(bulk?RPC_BULK_DATA:8192))return NULL;
    cJSON *old_session=cJSON_GetObjectItemCaseSensitive(request,"session");
    if(cJSON_IsString(old_session)&&strcmp(old_session->valuestring,session))return NULL;
    cJSON_DeleteItemFromObjectCaseSensitive(request,"session");cJSON_AddStringToObject(request,"session",session);
    cJSON_DeleteItemFromObjectCaseSensitive(request,"issuedAt");cJSON_AddNumberToObject(request,"issuedAt",epoch+age);
    cJSON_DeleteItemFromObjectCaseSensitive(request,"binaryReply");
    if(binary)cJSON_AddBoolToObject(request,"binaryReply",true);
    cJSON_DeleteItemFromObjectCaseSensitive(request,"bulkReply");
    if(bulk)cJSON_AddBoolToObject(request,"bulkReply",true);
    device_nonce(nonce);size_t n=0;char *clear=NULL;
    if(upload&&binary) {clear=(char*)rpc_binary_pack_bulk(request,upload,upload_size,&n,bulk);if(!clear)return NULL;}
    else {
        if(upload) {
            size_t encoded_size=4*((upload_size+2)/3)+1,written=0;
            unsigned char *encoded=malloc(encoded_size);if(!encoded)return NULL;
            int result=mbedtls_base64_encode(encoded,encoded_size,&written,upload,upload_size);
            if(result){free(encoded);return NULL;}encoded[written]=0;
            cJSON *added=cJSON_AddStringToObject(request,"data",(char*)encoded);free(encoded);if(!added)return NULL;
        }
        clear=binary?(char*)rpc_binary_encode(request,&n):NULL;
        if(!clear){clear=cJSON_PrintUnformatted(request);if(clear)n=strlen(clear);}
        if(upload)cJSON_DeleteItemFromObjectCaseSensitive(request,"data");
        if(!clear)return NULL;
    }
    uint8_t *packet=n+124<=RPC_REQUEST_MAX?heap_caps_malloc(n+28,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT):NULL;
    if(!packet){free(clear);return NULL;}
    esp_fill_random(packet,12);mbedtls_gcm_context ctx;mbedtls_gcm_init(&ctx);
    int err=mbedtls_gcm_setkey(&ctx,MBEDTLS_CIPHER_ID_AES,cfg.key,256);
    if(!err)err=mbedtls_gcm_crypt_and_tag(&ctx,MBEDTLS_GCM_ENCRYPT,n,packet,12,(uint8_t *)nonce,32,(uint8_t *)clear,packet+28,16,packet+12);
    mbedtls_gcm_free(&ctx);free(clear);
    if(err){free(packet);return NULL;}
    uint8_t hash[32];char hex[65],auth[180],proof[65];mbedtls_sha256(packet,n+28,hash,0);
    for(int i=0;i<32;i++)sprintf(hex+i*2,"%02x",hash[i]);
    snprintf(auth,sizeof(auth),"POST|/tab5/v1/rpc|%s|%s|%s",cfg.id,nonce,hex);device_proof(auth,proof);
    int64_t exchange_start=esp_timer_get_time();
    if(profile){profile->encode_us+=exchange_start-profile_start;profile->wire_tx+=n+28;profile_memory(profile);}
    size_t reply_size=0;uint8_t *reply=http?http_exchange(http,&cfg,nonce,proof,packet,n+28,&reply_size):exchange(link,nonce,proof,packet,n+28,&reply_size,generation);
    int64_t decode_start=esp_timer_get_time();
    if(profile){profile->exchange_us+=decode_start-exchange_start;profile->wire_rx+=reply_size;profile_memory(profile);}
    free(packet);
    char *plain=reply?device_decrypt_bounded(reply,reply_size,nonce,bulk?RPC_RESPONSE_MAX:TAB5_MAX_FRAME):NULL;free(reply);
    cJSON *root=plain?rpc_binary_unpack(plain,reply_size-28,download,capacity,received):NULL;free(plain);
    cJSON *code=cJSON_GetObjectItemCaseSensitive(root,"status"),*body=cJSON_GetObjectItemCaseSensitive(root,"body");
    cJSON *result=NULL;if(cJSON_IsNumber(code)&&cJSON_IsObject(body)){*status=code->valueint;result=cJSON_Duplicate(body,true);}
    if(result&&*status==200&&link!=LINK_WIFI) {
        xSemaphoreTake(rpc_lock,portMAX_DELAY);rpc_mailbox *m=box(link);
        // Disconnect resets peer_seen; do not revive a mailbox after its reset.
        if(m->peer_seen&&m->generation==generation){m->confirmed_ms=esp_timer_get_time()/1000;snprintf(m->confirmed_session,sizeof(m->confirmed_session),"%s",session);}
        xSemaphoreGive(rpc_lock);
    }
    if(profile){profile_memory(profile);profile->decode_us+=esp_timer_get_time()-decode_start;profile->calls++;}
    cJSON_Delete(root);return result;
}
cJSON *rpc_call(link_kind link,cJSON *request,int *status,char nonce[33]) {return rpc_call_impl(link,request,status,nonce,NULL,NULL,0,NULL,0,NULL);}
cJSON *rpc_http_call(void *client,cJSON *request,int *status,char nonce[33]) {return rpc_call_impl(LINK_WIFI,request,status,nonce,client,NULL,0,NULL,0,NULL);}
cJSON *rpc_data_call(link_kind link,void *http,cJSON *request,int *status,char nonce[33],
    const uint8_t *upload,size_t upload_size,uint8_t *download,size_t capacity,size_t *received) {
    return rpc_call_impl(link,request,status,nonce,http,upload,upload_size,download,capacity,received);
}
int rpc_ota_read(link_kind link,const char *sha,const char *offer,int offset,uint8_t *out,int count) {
    static int maximum[3]={16384,0,8192};
    static bool rejected_bulk[3];
    if(link!=LINK_USB&&link!=LINK_BLE)return -1;
    int limit=!rejected_bulk[link]&&rpc_data_limit(link)>8192?(int)RPC_BULK_DATA:maximum[link];
    if(count>limit)count=limit;
    cJSON *request=cJSON_CreateObject();cJSON_AddStringToObject(request,"kind","ota");
    cJSON_AddStringToObject(request,"sha256",sha);cJSON_AddStringToObject(request,"offerId",offer);
    cJSON_AddNumberToObject(request,"offset",offset);cJSON_AddNumberToObject(request,"count",count);
    int status;size_t size=0;char nonce[33];cJSON *reply=rpc_data_call(link,NULL,request,&status,nonce,NULL,0,out,count,&size);cJSON_Delete(request);
    cJSON *error=cJSON_GetObjectItemCaseSensitive(reply,"error");
    if(count>8192&&status==400&&cJSON_IsString(error)&&!strcmp(error->valuestring,"invalid_range")) {
        // An older paired bridge still accepts the original bounded range.
        maximum[link]=8192;rejected_bulk[link]=true;cJSON_Delete(reply);return rpc_ota_read(link,sha,offer,offset,out,8192);
    }
    cJSON *at=cJSON_GetObjectItemCaseSensitive(reply,"offset");
    bool ok=status==200&&cJSON_IsNumber(at)&&at->valuedouble==offset&&size==(size_t)count;
    cJSON_Delete(reply);return ok?(int)size:-1;
}

size_t rpc_data_limit(link_kind link) {
    if(link<0||link>2)return 8192;
    xSemaphoreTake(device_mutex,portMAX_DELAY);
    cJSON *cap=cJSON_GetObjectItemCaseSensitive(device_snapshots[link],"rpcBulk");
    cJSON *binary=cJSON_GetObjectItemCaseSensitive(device_snapshots[link],"rpcBinary");
    bool bulk=cJSON_IsNumber(cap)&&cap->valuedouble==1&&cJSON_IsNumber(binary)&&binary->valuedouble==1;
    xSemaphoreGive(device_mutex);return bulk?RPC_BULK_DATA:8192;
}
