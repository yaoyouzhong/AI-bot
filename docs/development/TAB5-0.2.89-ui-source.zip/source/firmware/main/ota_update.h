#pragma once
#include <stdbool.h>
#include <stddef.h>

// Call only for a status frame already accepted by device_receive().
void ota_update_consider(const char *authenticated_frame);
void ota_update_status(char *out, size_t size);
void ota_update_target_version(char *out, size_t size);
void ota_update_offer_details(char *version,size_t version_size,char *notes,size_t notes_size);
int ota_update_progress(void);
bool ota_update_available(void);
bool ota_update_busy(void);
bool ota_update_completed(void);
// UI acknowledges after the completion screen has been rendered.
void ota_update_completion_presented(void);
bool ota_update_request(void);
