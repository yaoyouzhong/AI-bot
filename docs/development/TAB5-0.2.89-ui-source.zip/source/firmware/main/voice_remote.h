#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    bool busy;
    bool ready;
    bool silent;
    int level;
    unsigned generation;
    char task_id[37], source[8], phase[20], message[160], text[2001];
} voice_remote_state;
bool voice_remote_start(const char *task_id, const char *session, int64_t epoch_ms);
bool voice_remote_init(void);
void voice_remote_command(int command); /* 1 stop, 2 cancel, 3 use TAB5 */
void voice_remote_get(voice_remote_state *out);
void voice_remote_notify_reply(void); /* Short local chime, deferred while capturing. */
bool voice_remote_preview_sound(void); /* Worker-owned playback; refuses while recording or muted. */
int voice_remote_queue_depth(void);
int voice_remote_mic_error(void);
