#pragma once
#include <stdbool.h>
#include <stddef.h>
bool transport_benchmark_start(void);
bool transport_benchmark_busy(void);
void transport_benchmark_cancel(void);
void transport_benchmark_diagnostics(char *out,size_t size);
