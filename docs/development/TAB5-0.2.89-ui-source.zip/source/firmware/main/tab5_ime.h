#pragma once
#include "lvgl.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define TAB5_PINYIN_MAX 32
#define TAB5_PINYIN_CANDIDATES 48
typedef struct { const char *text; uint8_t consumed; uint32_t weight; } tab5_pinyin_candidate;
size_t tab5_pinyin_lookup(const char *raw, tab5_pinyin_candidate *out, size_t capacity);

/* One composer on the TAB5. Pending spelling is kept out of the message body. */
lv_obj_t *tab5_ime_create(lv_obj_t *parent, lv_obj_t *keyboard, lv_obj_t *textarea, const lv_font_t *font);
void tab5_ime_show(bool show);
void tab5_ime_finish(void); /* Preserve unselected spelling as literal text. */
const char *tab5_ime_pending(void);
