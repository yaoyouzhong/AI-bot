#pragma once
#include "link_state.h"
#include "cJSON.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
// Bounded, authenticated application RPC over CDC or GATT. A request stays on
// its selected transport; uncertain sends are never retried on another link.
void rpc_link_init(void);
void rpc_link_reset(link_kind link);
size_t rpc_link_read(link_kind link,uint8_t *out,size_t capacity);
bool rpc_link_write(link_kind link,const uint8_t *data,size_t size);
link_kind rpc_link_select(void);
link_kind rpc_read_link_select(void);
link_kind rpc_ota_link_select(void);
// Auto mode prefers bulk bandwidth; explicit single-channel modes are binding.
link_kind rpc_image_link_select(const char *session);
bool rpc_link_ready(void);
bool rpc_read_link_ready(void);
// The paired bridge advertises this capability inside encrypted state.
size_t rpc_data_limit(link_kind link);
cJSON *rpc_call(link_kind link,cJSON *request,int *status,char nonce[33]);
cJSON *rpc_http_call(void *client,cJSON *request,int *status,char nonce[33]);
cJSON *rpc_data_call(link_kind link,void *http,cJSON *request,int *status,char nonce[33],
    const uint8_t *upload,size_t upload_size,uint8_t *download,size_t capacity,size_t *received);
int rpc_ota_read(link_kind link,const char *sha,const char *offer,int offset,uint8_t *out,int count);
typedef struct {
    uint64_t encode_us,exchange_us,decode_us;
    unsigned calls,wire_tx,wire_rx,min_internal,min_psram,min_largest;
} rpc_profile;
void rpc_profile_reset(link_kind link);
rpc_profile rpc_profile_get(link_kind link);
