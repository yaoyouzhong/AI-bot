#pragma once
#include "lvgl.h"
#include "camera_frame.h"
#include <stdbool.h>

typedef enum {
    CAMERA_PREVIEW_OFF,
    CAMERA_PREVIEW_STARTING,
    CAMERA_PREVIEW_LIVE,
    CAMERA_PREVIEW_CAPTURED,
    CAMERA_PREVIEW_ERROR,
    CAMERA_PREVIEW_CAPTURING
} camera_preview_state;

bool camera_preview_start(lv_obj_t *canvas);
bool camera_preview_capture(void);
void camera_preview_stop(void);
camera_preview_state camera_preview_get_state(void);
// Lease the immutable captured frame until release; blocks retake while JPEG reads it.
const uint8_t *camera_preview_acquire(void);
void camera_preview_release(const uint8_t *pixels);
bool camera_preview_busy(void);
const char *camera_preview_error(void);
void camera_preview_init_diagnostics(void);
void camera_preview_diagnostics(char *out, unsigned size);
void camera_preview_driver_error_hex(char *out,unsigned size);
