#pragma once
#include "lvgl.h"
#include <stdbool.h>
#include <stdint.h>

// Registration and begin/end run under the LVGL mutex. One camera task owns
// frame() until end(); controls are immutable cached snapshots for that session.
void camera_viewport_set_controls(lv_obj_t *shutter, lv_obj_t *close);
// 1: acquired, 0: safe LVGL fallback, -1: display fault (end still required).
int camera_viewport_begin(lv_obj_t *canvas);
bool camera_viewport_frame(const uint16_t *source, bool (*keep)(void *), void *ctx);
bool camera_viewport_end(void);
void camera_viewport_diagnostics(unsigned *presented, unsigned *compose_us,
                                 unsigned *present_us, unsigned *mode);
