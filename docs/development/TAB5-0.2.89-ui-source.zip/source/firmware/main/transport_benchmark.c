#include "transport_benchmark.h"
#include "device.h"
#include "rpc_link.h"
#include "wifi_performance.h"
#include "codex_remote.h"
#include "voice_remote.h"
#include "ota_update.h"
#include "esp_http_client.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "freertos/idf_additions.h"
#include "mbedtls/base64.h"
#include "mbedtls/sha256.h"
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static atomic_bool active,stopping;
static char diagnostic[3600]="idle";
bool transport_benchmark_busy(void){return atomic_load(&active);}
static void report(const char *value) {xSemaphoreTake(device_mutex,portMAX_DELAY);snprintf(diagnostic,sizeof(diagnostic),"%s",value);xSemaphoreGive(device_mutex);}
void transport_benchmark_diagnostics(char *out,size_t size) {xSemaphoreTake(device_mutex,portMAX_DELAY);snprintf(out,size,"%s",diagnostic);xSemaphoreGive(device_mutex);}
void transport_benchmark_cancel(void){atomic_store(&stopping,true);}
static void run(void *arg) {
    (void)arg;size_t result_size=0;bool failed=false;device_config cfg=device_get_config();
    char *results=heap_caps_calloc(1,3300,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    char *progress=heap_caps_malloc(3600,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    uint8_t *bytes=heap_caps_malloc(49152,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!bytes||!results||!progress){report("failed:memory");goto done;}
    for(int channel=0;channel<3&&!atomic_load(&stopping);channel++) {
        link_state links;xSemaphoreTake(device_mutex,portMAX_DELAY);links=device_links;xSemaphoreGive(device_mutex);
        int64_t now=esp_timer_get_time()/1000;
        if((links.mode!=-1&&links.mode!=channel)||links.received_ms[channel]<0||now<links.received_ms[channel]||now-links.received_ms[channel]>=8000)continue;
        esp_http_client_handle_t http=NULL;
        if(channel==LINK_WIFI)wifi_performance_bulk(true);
        if(channel==LINK_WIFI) {
            char url[96];snprintf(url,sizeof(url),"http://%s:%d/tab5/v1/rpc",cfg.host,cfg.port);
            esp_http_client_config_t options={.url=url,.method=HTTP_METHOD_POST,.timeout_ms=12000,.disable_auto_redirect=true,.buffer_size=4096};
            http=esp_http_client_init(&options);if(!http){wifi_performance_bulk(false);failed=true;break;}
        }
        size_t chunk=rpc_data_limit(channel);
        int64_t channel_deadline=now+300000;
        for(int repeat=0;repeat<3&&!atomic_load(&stopping);repeat++)for(int direction=0;direction<2&&!atomic_load(&stopping);direction++) {
            rpc_profile_reset(channel);
            unsigned transferred=0;int error=0;int64_t began=esp_timer_get_time()/1000;
            for(unsigned offset=0;offset<262144&&!atomic_load(&stopping);offset+=(unsigned)chunk) {
                size_t count=262144-offset<chunk?262144-offset:chunk;
                if(esp_timer_get_time()/1000>=channel_deadline){error=-2;break;}
                xSemaphoreTake(device_mutex,portMAX_DELAY);int mode=device_links.mode;bool same=!strcmp(device_links.session[channel],links.session[channel]);xSemaphoreGive(device_mutex);
                if(!same||(mode!=-1&&mode!=channel)){error=-3;break;}
                for(unsigned i=0;i<count;i++)bytes[i]=(uint8_t)((offset+i)*31+17);
                uint8_t hash[32];char expected_hash[65];mbedtls_sha256(bytes,count,hash,0);
                for(int i=0;i<32;i++)snprintf(expected_hash+i*2,3,"%02x",hash[i]);
                cJSON *request=cJSON_CreateObject();cJSON_AddStringToObject(request,"kind","benchmark");
                cJSON_AddStringToObject(request,"session",links.session[channel]);
                cJSON_AddNumberToObject(request,"offset",offset);cJSON_AddNumberToObject(request,"count",count);
                int status=0;size_t received=0;char nonce[33];
                cJSON *reply=rpc_data_call(channel,http,request,&status,nonce,direction==0?bytes:NULL,direction==0?count:0,
                    direction==1?bytes:NULL,chunk,&received);cJSON_Delete(request);
                cJSON *sha=cJSON_GetObjectItemCaseSensitive(reply,"sha256"),*at=cJSON_GetObjectItemCaseSensitive(reply,"offset");
                bool ok=status==200&&cJSON_IsString(sha)&&!strcmp(sha->valuestring,expected_hash)&&cJSON_IsNumber(at)&&at->valuedouble==offset;
                if(ok&&direction==1){ok=received==count;for(unsigned i=0;ok&&i<received;i++)if(bytes[i]!=(uint8_t)((offset+i)*31+17))ok=false;}
                cJSON_Delete(reply);if(!ok){error=status?status:-1;break;}transferred+=(unsigned)count;
                snprintf(progress,3600,"running;%s%s,%s,%d,%u/262144",results,link_name(channel),direction?"down":"up",repeat+1,transferred);report(progress);
            }
            unsigned ms=(unsigned)(esp_timer_get_time()/1000-began);
            rpc_profile profile=rpc_profile_get(channel);
            int n=snprintf(results+result_size,3300-result_size,"%s,%s,%d,%u,%u,%d,%u,%u,%u,%u,%u,%u,%u,%u,%u;",link_name(channel),direction?"down":"up",repeat+1,transferred,ms,error,profile.calls,(unsigned)(profile.encode_us/1000),(unsigned)(profile.exchange_us/1000),(unsigned)(profile.decode_us/1000),profile.wire_tx,profile.wire_rx,profile.min_internal,profile.min_psram,profile.min_largest);
            if(n>0&&(size_t)n<3300-result_size)result_size+=n;
            if(error){failed=true;goto channel_done;}
        }
channel_done:
        if(http)esp_http_client_cleanup(http);
        if(channel==LINK_WIFI)wifi_performance_bulk(false);
    }
    {snprintf(progress,3600,"%s;%s",atomic_load(&stopping)?"cancelled":failed?"failed":result_size?"complete":"unavailable",results);report(progress);}
done:
    free(results);free(progress);free(bytes);atomic_store(&active,false);vTaskDeleteWithCaps(NULL);
}
bool transport_benchmark_start(void) {
    if(atomic_exchange(&active,true))return false;
    voice_remote_state voice;voice_remote_get(&voice);
    if(codex_remote_busy()||voice.busy||ota_update_busy()){atomic_store(&active,false);report("failed:busy");return false;}
    atomic_store(&stopping,false);report("running;starting");
    if(xTaskCreateWithCaps(run,"tab5_benchmark",8192,NULL,3,NULL,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)!=pdPASS){atomic_store(&active,false);report("failed:task_memory");return false;}
    return true;
}
