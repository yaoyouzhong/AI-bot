// Internal LVGL view helpers. Included by ui.c after its data and widget
// helpers.
#define INK 0xEFF4F2
#define MUTED 0xB9C5C9
#define BLUE 0xB9DCEB
#define CORAL 0xC5BCCF
#define GREEN 0xA8D6BB
#define AMBER 0xE9C48C
#define RED 0xF0ABA4
#define SURFACE 0x2B3539
#define TRACK 0x495C65
#define NET_UP 0xE9C48C
#define NET_DOWN 0x65D99A
typedef struct {
    lv_obj_t *arc, *number, *caption;
} visual_meter;
static visual_meter system_meter[2];
static lv_obj_t *model_state[2], *model_dot[2];
static lv_obj_t *weather_temp, *weather_range;
static lv_obj_t *weather_condition,*weather_low,*weather_high,*weather_aqi_title,*weather_aqi_category,*weather_pressure_kind;
static lv_obj_t *weather_facts[4], *weather_humidity, *weather_icon;
static lv_obj_t *network_rates[2], *chart_scale, *network_ticks[5];
static lv_obj_t *music_artist, *music_album, *music_state, *music_time, *pet_dot[2], *pet_hint[2];
static lv_obj_t *clock_hands[3];
static lv_obj_t *clock_face,*clock_marks[60],*clock_numbers[12],*clock_rings[2],*clock_cap,*clock_name;
static int clock_style;
static bool clock_style_error;
static void tint(lv_obj_t *o, uint32_t color) { ui_text_color(o, lv_color_hex(color), 0); }
static lv_obj_t *muted(lv_obj_t *p, const char *s, int x, int y, int w) {
    lv_obj_t *o = label(p, s, x, y, w, false);
    tint(o, MUTED);
    return o;
}
static lv_obj_t *shape(lv_obj_t *p, int x, int y, int w, int h, uint32_t color, int radius) {
    lv_obj_t *o = lv_obj_create(p);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    ui_bg_color(o, lv_color_hex(color), 0);
    ui_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(o, radius, 0);
    lv_obj_remove_flag(o, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    return o;
}
static lv_obj_t *vbar(lv_obj_t *p, int x, int y, int w, uint32_t color) {
    lv_obj_t *o = lv_bar_create(p);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, 10);
    ui_bg_color(o, lv_color_hex(TRACK), LV_PART_MAIN);
    ui_bg_opa(o, LV_OPA_COVER, LV_PART_MAIN);
    ui_bg_color(o, lv_color_hex(color), LV_PART_INDICATOR);
    lv_bar_set_value(o, 0, LV_ANIM_OFF);
    return o;
}
static int percentage(cJSON *o, const char *key) {
    double n = num(o, key);
    return n < 0 ? 0 : n > 100 ? 100 : (int)n;
}
static visual_meter meter(lv_obj_t *p, const char *title, int x, int y, uint32_t color) {
    visual_meter m;
    muted(p, title, x, y, 270);
    m.arc = lv_arc_create(p);
    // LVGL anchors a non-square arc's circle to its shorter side, not its
    // bounding-box center. Keep the arc square so text and circle share a center.
    lv_obj_set_pos(m.arc, x + 42, y + 32);
    lv_obj_set_size(m.arc, 170, 170);
    lv_obj_set_style_pad_all(m.arc,0,0);
    lv_arc_set_rotation(m.arc, 135);
    lv_arc_set_bg_angles(m.arc, 0, 270);
    lv_arc_set_range(m.arc, 0, 100);
    lv_arc_set_value(m.arc, 0);
    lv_obj_remove_style(m.arc, NULL, LV_PART_KNOB);
    lv_obj_remove_flag(m.arc, LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_arc_width(m.arc, 12, LV_PART_MAIN);
    lv_obj_set_style_arc_width(m.arc, 12, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(m.arc, lv_color_hex(TRACK), LV_PART_MAIN);
    lv_obj_set_style_arc_color(m.arc, lv_color_hex(color), LV_PART_INDICATOR);
    m.number = label(p, "--", x + 27, y + 96, 200, true);
    lv_obj_set_style_text_align(m.number, LV_TEXT_ALIGN_CENTER, 0);
    lv_label_set_long_mode(m.number,LV_LABEL_LONG_CLIP);
    lv_obj_align_to(m.number,m.arc,LV_ALIGN_CENTER,0,0);
    m.caption = muted(p, "等待数据", x, y + 211, 330);
    return m;
}
static void meter_update(visual_meter *m, cJSON *o, const char *key, uint32_t normal) {
    char b[32];
    bool known = cJSON_IsNumber(item(o, key));
    double sample=num(o,key);
    int n=sample<0?0:sample>100?100:(int)(sample+0.5);
    if(known)snprintf(b,sizeof(b),"%d%%",n);else snprintf(b,sizeof(b),"--");
    ui_text(m->number, b);
    lv_obj_align_to(m->number,m->arc,LV_ALIGN_CENTER,0,0);
    lv_arc_set_value(m->arc, n);
    lv_obj_set_style_arc_opa(m->arc, known ? LV_OPA_COVER : LV_OPA_TRANSP, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(m->arc, lv_color_hex(n >= 90 ? RED : n >= 75 ? AMBER : normal), LV_PART_INDICATOR);
}
static uint32_t activity_color(cJSON *o) {
    if (yes(o, "needsInput"))
        return AMBER;
    if (yes(o, "completionActive"))
        return GREEN;
    return !strcmp(text(o, "state"), "working") ? GREEN : !strcmp(text(o, "state"), "idle") ? BLUE : MUTED;
}
static lv_obj_t *home_weather_icon;
static int weather_icon_type;
static void weather_icon_rect(lv_layer_t *layer,const lv_area_t *box,int scale,
                              int x,int y,int w,int h,uint32_t color,int radius) {
    lv_area_t a={box->x1+x*scale/256,box->y1+y*scale/256,0,0};
    a.x2=a.x1+(w*scale/256>0?w*scale/256:1)-1;
    a.y2=a.y1+(h*scale/256>0?h*scale/256:1)-1;
    lv_draw_rect_dsc_t d;lv_draw_rect_dsc_init(&d);
    d.bg_color=lv_color_hex(color);d.bg_opa=LV_OPA_COVER;
    d.radius=radius==LV_RADIUS_CIRCLE?radius:radius*scale/256;
    lv_draw_rect(layer,&d,&a);
}
static void weather_icon_draw_type(lv_event_t *e,int weather_icon_type) {
    lv_obj_t *o=lv_event_get_target(e);
    lv_layer_t *layer=lv_event_get_layer(e);
    lv_area_t box;lv_obj_get_coords(o,&box);
    int scale=lv_area_get_width(&box)*256/210;
    if(weather_icon_type==0) {
        weather_icon_rect(layer,&box,scale,72,84,28,5,MUTED,2);
        weather_icon_rect(layer,&box,scale,110,84,28,5,MUTED,2);
        return;
    }
    if(weather_icon_type<=2) {
        weather_icon_rect(layer,&box,scale,75,38,78,78,AMBER,LV_RADIUS_CIRCLE);
        for(int i=0;i<8;i++){
            int angle=i*45;
            int x=111+lv_trigo_cos(angle)*65/32768;
            int y=74+lv_trigo_sin(angle)*65/32768;
            weather_icon_rect(layer,&box,scale,x,y,7,7,AMBER,LV_RADIUS_CIRCLE);
        }
    }
    if(weather_icon_type>=2) {
        weather_icon_rect(layer,&box,scale,48,60,73,73,0xC3D7ED,LV_RADIUS_CIRCLE);
        weather_icon_rect(layer,&box,scale,96,70,65,65,0xC3D7ED,LV_RADIUS_CIRCLE);
        weather_icon_rect(layer,&box,scale,25,86,151,51,0xC3D7ED,25);
    }
    if(weather_icon_type==3)for(int i=0;i<4;i++)
        weather_icon_rect(layer,&box,scale,48+i*32,148,6,22,BLUE,3);
    if(weather_icon_type==4)for(int i=0;i<4;i++)
        weather_icon_rect(layer,&box,scale,48+i*32,151,9,9,INK,LV_RADIUS_CIRCLE);
}
static void weather_icon_draw(lv_event_t *e) {
    intptr_t type=(intptr_t)lv_obj_get_user_data(lv_event_get_target(e));
    weather_icon_draw_type(e,type?(int)type-1:weather_icon_type);
}
static lv_obj_t *weather_icon_create_set(lv_obj_t *p,int x,int y,int scale) {
    lv_obj_t *o=lv_obj_create(p);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o,x,y);lv_obj_set_size(o,210*scale/256,180*scale/256);
    lv_obj_remove_flag(o,LV_OBJ_FLAG_SCROLLABLE|LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(o,weather_icon_draw,LV_EVENT_DRAW_MAIN,NULL);
    return o;
}
static void weather_icon_create(lv_obj_t *p){weather_icon=weather_icon_create_set(p,307,106,256);}
static void weather_icon_update(const char *condition) {
    int type = 0;
    if (strstr(condition, "雪"))
        type = 4;
    else if (strstr(condition, "雨") || strstr(condition, "雷"))
        type = 3;
    else if (strstr(condition, "云") || strstr(condition, "阴") || strstr(condition, "雾") || strstr(condition, "霾"))
        type = 2;
    else if (strstr(condition, "晴"))
        type = 1;
    if(type!=weather_icon_type){weather_icon_type=type;lv_obj_invalidate(weather_icon);lv_obj_invalidate(home_weather_icon);}
}
static void analog_create(lv_obj_t *p) {
    lv_obj_t *face = shape(p, 76, 65, 354, 354, SURFACE, LV_RADIUS_CIRCLE);
    clock_face = face;
    ui_border_color(face, lv_color_hex(TRACK), 0);
    lv_obj_set_style_border_width(face, 2, 0);
    for(int i=0;i<2;i++) {
        int margin=i?59:15;
        clock_rings[i]=shape(face,margin,margin,354-margin*2,354-margin*2,TRACK,LV_RADIUS_CIRCLE);
        ui_bg_opa(clock_rings[i],LV_OPA_TRANSP,0);
        lv_obj_set_style_border_width(clock_rings[i],1,0);
        ui_border_color(clock_rings[i],lv_color_hex(TRACK),0);
    }
    for (int i = 0; i < 60; i++) {
        int r = i % 5 ? 155 : 152, size = i % 5 ? 3 : 8;
        clock_marks[i]=shape(face, 177 + lv_trigo_sin(i * 6) * r / 32768 - size / 2, 177 - lv_trigo_cos(i * 6) * r / 32768 - size / 2,
              size, size, i % 5 ? TRACK : MUTED, LV_RADIUS_CIRCLE);
    }
    for(int i=0;i<12;i++) {
        clock_numbers[i]=label(face,"",0,0,42,false);
        ui_text_fmt(clock_numbers[i],"%d",i?i:12);
        ui_text_font(clock_numbers[i],&lv_font_montserrat_24,0);
        lv_obj_set_style_text_align(clock_numbers[i],LV_TEXT_ALIGN_CENTER,0);
        lv_obj_set_pos(clock_numbers[i],156+lv_trigo_sin(i*30)*119/32768,163-lv_trigo_cos(i*30)*119/32768);
    }
    for (int i = 0; i < 3; i++) {
        int lengths[] = {83, 121, 137};
        int width = i == 0 ? 8 : i == 1 ? 5 : 2;
        clock_hands[i] =
            shape(face, 177 - width / 2, 177 - lengths[i], width, lengths[i], i == 2 ? BLUE : INK, width / 2);
        lv_obj_set_style_transform_pivot_x(clock_hands[i], width / 2, 0);
        lv_obj_set_style_transform_pivot_y(clock_hands[i], lengths[i], 0);
    }
    clock_cap=shape(face, 170, 170, 14, 14, BLUE, LV_RADIUS_CIRCLE);
    clock_name=muted(p,"经典",544,64,620);
}
static void analog_style(void) {
    bool cream=clock_style==3,square=clock_style==4,orbit=clock_style==2;
    uint32_t face=cream?0xF1E9D8:square?0x23252C:orbit?0x0B2430:SURFACE;
    uint32_t ink=cream?0x26323B:INK,accent=cream?0xD8543D:square?CORAL:orbit?GREEN:BLUE;
    ui_bg_color(clock_face,lv_color_hex(face),0);
    lv_obj_set_style_radius(clock_face,square?32:LV_RADIUS_CIRCLE,0);
    lv_obj_set_style_border_width(clock_face,square?3:2,0);
    ui_border_color(clock_face,lv_color_hex(cream?0xD6C5A7:orbit?0x347582:TRACK),0);
    for(int i=0;i<2;i++) {
        if(orbit || (square&&i==0))lv_obj_remove_flag(clock_rings[i],LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(clock_rings[i],LV_OBJ_FLAG_HIDDEN);
        lv_obj_set_style_radius(clock_rings[i],square?23:LV_RADIUS_CIRCLE,0);
    }
    for(int i=0;i<60;i++) {
        bool major=i%5==0;
        int w=major?(cream?4:square?6:8):2,h=major?(cream?15:square?20:orbit?8:8):2;
        lv_obj_set_size(clock_marks[i],w,h);
        lv_obj_set_pos(clock_marks[i],177+lv_trigo_sin(i*6)*151/32768-w/2,177-lv_trigo_cos(i*6)*151/32768-h/2);
        lv_obj_set_style_transform_pivot_x(clock_marks[i],w/2,0);
        lv_obj_set_style_transform_pivot_y(clock_marks[i],h/2,0);
        lv_obj_set_style_transform_rotation(clock_marks[i],(cream||square)?i*60:0,0);
        ui_bg_color(clock_marks[i],lv_color_hex(major?ink:cream?0xAA9B87:TRACK),0);
        if(square&&!major)lv_obj_add_flag(clock_marks[i],LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(clock_marks[i],LV_OBJ_FLAG_HIDDEN);
    }
    for(int i=0;i<12;i++) {
        bool show=cream||(orbit&&i%3==0);
        if(show)lv_obj_remove_flag(clock_numbers[i],LV_OBJ_FLAG_HIDDEN);else lv_obj_add_flag(clock_numbers[i],LV_OBJ_FLAG_HIDDEN);
        tint(clock_numbers[i],ink);
    }
    for(int i=0;i<3;i++) {
        int widths[]={square?11:8,square?7:5,2},lengths[]={83,121,137};
        lv_obj_set_size(clock_hands[i],widths[i],lengths[i]);
        lv_obj_set_pos(clock_hands[i],177-widths[i]/2,177-lengths[i]);
        lv_obj_set_style_transform_pivot_x(clock_hands[i],widths[i]/2,0);
        lv_obj_set_style_transform_pivot_y(clock_hands[i],lengths[i],0);
        ui_bg_color(clock_hands[i],lv_color_hex(i==2?accent:ink),0);
    }
    ui_bg_color(clock_cap,lv_color_hex(accent),0);
}
static void clock_layout(void) {
    if (clock_style != 1)
        lv_obj_remove_flag(clock_face, LV_OBJ_FLAG_HIDDEN);
    else
        lv_obj_add_flag(clock_face, LV_OBJ_FLAG_HIDDEN);
    const char *styles[]={"经典圆盘","纯数字","轨道圆盘","奶油刻度","方形表盘"};
    ui_text(clock_name,styles[clock_style]);analog_style();
    int scale = 256;
    ui_text_font(clock_big,clock_style==1?&tab5_digits_96:&tab5_digits_72,0);
    lv_obj_set_style_transform_scale(clock_big, scale, 0);
    lv_obj_update_layout(clock_big);
    lv_obj_set_pos(clock_big, clock_style != 1 ? 540 : (1220 - lv_obj_get_width(clock_big) * scale / 256) / 2, 114);
    lv_obj_set_pos(date_label, clock_style != 1 ? 544 : 60, clock_style != 1 ? 260 : 340);
    lv_obj_set_width(date_label, clock_style != 1 ? 650 : 1100);
    lv_obj_set_style_text_align(date_label, clock_style != 1 ? LV_TEXT_ALIGN_LEFT : LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_pos(clock_name,clock_style==1?60:544,64);lv_obj_set_width(clock_name,clock_style==1?1100:620);
    lv_obj_set_style_text_align(clock_name,clock_style==1?LV_TEXT_ALIGN_CENTER:LV_TEXT_ALIGN_LEFT,0);
}
static void clock_style_clicked(lv_event_t *e) {
    (void)e;
    clock_style = (clock_style + 1) % UI_CLOCK_STYLES;
    clock_layout();
    clock_style_error = !ui_clock_style_save(clock_style);
    // A deliberate face tap should stay on the clock, including when entered as a screensaver.
    saver_leave();
    if(prefs.selected!=7) {
        prefs.selected=7;
        lv_dropdown_set_selected(display_mode,8);
        save();
    }
    last_change = esp_timer_get_time() / 1000;
}
static void clock_touch_target(lv_obj_t *parent) {
    for(uint32_t i=0;i<lv_obj_get_child_count(parent);i++) {
        lv_obj_t *child=lv_obj_get_child(parent,i);
        lv_obj_remove_flag(child,LV_OBJ_FLAG_CLICKABLE);
        clock_touch_target(child);
    }
}
static void analog_update(struct tm *t,int milliseconds) {
    int angles[] = {(t->tm_hour % 12)*300+t->tm_min*5,t->tm_min*60+t->tm_sec,t->tm_sec*60+milliseconds*60/1000};
    for (int i = 0; i < 3; i++) {
        lv_obj_set_style_transform_rotation(clock_hands[i], angles[i], 0);
    }
}
