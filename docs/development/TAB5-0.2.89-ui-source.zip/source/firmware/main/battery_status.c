#include "battery_status.h"
#include "battery_estimate.h"
#include "bsp/m5stack_tab5.h"
#include "driver/i2c_master.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static portMUX_TYPE guard=portMUX_INITIALIZER_UNLOCKED;
static battery_status latest;
static int64_t sampled_at;
static i2c_master_dev_handle_t monitor;

static bool read_register(uint8_t reg,uint16_t *out) {
    uint8_t data[2];
    if(i2c_master_transmit_receive(monitor,&reg,1,data,2,30)!=ESP_OK)return false;
    *out=((uint16_t)data[0]<<8)|data[1];return true;
}
static void sample_task(void *unused) {
    (void)unused;
    uint16_t configuration;
    // Preserve reserved bits; 16 samples, 1.1 ms bus/shunt, continuous mode.
    if(read_register(0,&configuration)) {
        uint16_t value=(configuration&0x7000)|0x0527;
        uint8_t data[3]={0,(uint8_t)(value>>8),(uint8_t)value};
        if(i2c_master_transmit(monitor,data,3,30)!=ESP_OK){vTaskDelete(NULL);return;}
    } else {vTaskDelete(NULL);return;}
    int filtered_mv=0;int64_t previous_at=0;
    battery_estimate estimate={0};
    for(;;) {
        vTaskDelay(pdMS_TO_TICKS(2000));
        uint16_t bus,shunt;
        if(read_register(2,&bus)&&read_register(1,&shunt)) {
            int mv=(int)bus*5/4;
            // 2.5 uV/LSB / 5 mOhm = 0.5 mA/LSB; charge is negative
            // on the TAB5 shunt. Reading shunt directly needs no calibration write.
            int ma=-(int16_t)shunt/2;
            bool valid=mv>=5000&&mv<=9000;
            int percent=0;int64_t now=esp_timer_get_time();
            if(valid) {
                filtered_mv=filtered_mv?(filtered_mv*3+mv)/4:mv;
                unsigned elapsed=previous_at?(unsigned)((now-previous_at)/1000):0;
                percent=battery_estimate_sample(&estimate,filtered_mv,ma,elapsed);
                previous_at=now;
            }else {filtered_mv=0;previous_at=0;estimate=(battery_estimate){0};}
            battery_status next={valid,valid&&estimate.charging,percent,mv,ma};
            portENTER_CRITICAL(&guard);latest=next;sampled_at=esp_timer_get_time();portEXIT_CRITICAL(&guard);
        }
    }
}
void battery_status_start(void) {
    i2c_device_config_t config={.dev_addr_length=I2C_ADDR_BIT_LEN_7,.device_address=0x41,.scl_speed_hz=400000};
    if(i2c_master_bus_add_device(bsp_i2c_get_handle(),&config,&monitor)!=ESP_OK)return;
    if(xTaskCreate(sample_task,"battery",3072,NULL,1,NULL)!=pdPASS){i2c_master_bus_rm_device(monitor);monitor=NULL;}
}
battery_status battery_status_get(void) {
    portENTER_CRITICAL(&guard);battery_status result=latest;int64_t at=sampled_at;portEXIT_CRITICAL(&guard);
    if(!at||esp_timer_get_time()-at>10000000)result.valid=false;
    return result;
}
