#pragma once
#include "cJSON.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#define USB_BINARY_MAX 16393
typedef struct {uint8_t *data;unsigned used,want;uint32_t tag;int64_t deadline;bool failed;} usb_binary;
static bool usb_binary_expire(usb_binary *b,int64_t now) {
    if(!b->want||now<b->deadline)return false;
    b->want=b->used=0;b->failed=true;return true;
}
static bool usb_binary_feed(usb_binary *b,uint8_t value) {
    if(b->failed||!b->data||!b->want||b->want>USB_BINARY_MAX||b->used>=b->want)return false;
    b->data[b->used++]=value;return b->used==b->want;
}
static void usb_binary_header(uint8_t out[16],uint32_t tag,unsigned size,bool ok) {
    memcpy(out,"AIB2",4);
    for(unsigned i=0;i<4;i++){out[4+i]=tag>>(i*8);out[8+i]=size>>(i*8);out[12+i]=(unsigned)ok>>(i*8);}
}
static bool usb_binary_command(cJSON *root,const char *device,uint32_t *tag,unsigned *count) {
    cJSON *v=cJSON_GetObjectItemCaseSensitive(root,"version"),*id=cJSON_GetObjectItemCaseSensitive(root,"deviceId");
    cJSON *t=cJSON_GetObjectItemCaseSensitive(root,"tag"),*n=cJSON_GetObjectItemCaseSensitive(root,"count");
    if(!cJSON_IsNumber(v)||v->valuedouble!=1||!cJSON_IsString(id)||strcmp(id->valuestring,device)||
       !cJSON_IsNumber(t)||t->valuedouble<0||t->valuedouble>UINT32_MAX||t->valuedouble!=(uint32_t)t->valuedouble||
       !cJSON_IsNumber(n)||n->valuedouble<0||n->valuedouble>USB_BINARY_MAX||n->valuedouble!=(unsigned)n->valuedouble)return false;
    *tag=(uint32_t)t->valuedouble;*count=(unsigned)n->valuedouble;return true;
}
