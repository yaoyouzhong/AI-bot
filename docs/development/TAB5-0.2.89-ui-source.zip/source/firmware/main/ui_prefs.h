#pragma once
#include <stdbool.h>
#include <stdint.h>
#define UI_CLOCK_STYLES 5
typedef struct {
    uint32_t version;
    int selected, interval, saver_minutes;
    bool cycle, alerts;
    uint8_t enabled[8], order[8];
} ui_preferences;
ui_preferences ui_preferences_load(void);
bool ui_preferences_save(const ui_preferences *prefs);
int ui_clock_style_load(void);
bool ui_clock_style_save(int style);
unsigned ui_home_models_load(void);
bool ui_home_models_save(unsigned mask);
typedef struct {uint32_t version;char task[37],request[37],operation[16],turn[37],text[2001];char images[3][37];} ui_codex_checkpoint;
bool ui_codex_checkpoint_load(ui_codex_checkpoint *value);
bool ui_codex_checkpoint_save(const ui_codex_checkpoint *value);
typedef struct {char task[37],turn[64];int page,y;bool follow;unsigned stamp;} ui_reading_bookmark;
bool ui_reading_load(ui_reading_bookmark values[32]);
bool ui_reading_save(const ui_reading_bookmark values[32]);
