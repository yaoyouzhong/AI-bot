#include "ui_prefs.h"
#include "nvs.h"
#include <string.h>
#include <stddef.h>
bool ui_codex_checkpoint_load(ui_codex_checkpoint *value) {
    nvs_handle_t h;if(nvs_open("aibot_tab5",NVS_READONLY,&h)!=ESP_OK)return false;
    memset(value,0,sizeof(*value));size_t length=sizeof(*value);esp_err_t r=nvs_get_blob(h,"codex_draft",value,&length);nvs_close(h);
    // The previous structure ended after text, rounded to uint32 alignment.
    size_t legacy=(offsetof(ui_codex_checkpoint,images)+3)&~(size_t)3;
    if(r==ESP_OK&&length==legacy)memset(value->images,0,sizeof(value->images));
    return r==ESP_OK&&(length==sizeof(*value)||length==legacy)&&value->version==1&&value->task[36]==0&&
        value->images[0][36]==0&&value->images[1][36]==0&&value->images[2][36]==0&&
        value->request[36]==0&&value->operation[15]==0&&value->turn[36]==0&&value->text[2000]==0;
}
bool ui_codex_checkpoint_save(const ui_codex_checkpoint *value) {
    if(!value||value->version!=1)return false;
    nvs_handle_t h;if(nvs_open("aibot_tab5",NVS_READWRITE,&h)!=ESP_OK)return false;
    esp_err_t r=nvs_set_blob(h,"codex_draft",value,sizeof(*value));if(r==ESP_OK)r=nvs_commit(h);nvs_close(h);return r==ESP_OK;
}
unsigned ui_home_models_load(void) {
    uint8_t mask=7;nvs_handle_t h;
    if(nvs_open("aibot_tab5",NVS_READONLY,&h)==ESP_OK) {nvs_get_u8(h,"home_models",&mask);nvs_close(h);}
    return mask>0&&mask<8?mask:7;
}
bool ui_home_models_save(unsigned mask) {
    if(!mask||mask>7)return false;
    nvs_handle_t h;if(nvs_open("aibot_tab5",NVS_READWRITE,&h)!=ESP_OK)return false;
    esp_err_t r=nvs_set_u8(h,"home_models",mask);if(r==ESP_OK)r=nvs_commit(h);nvs_close(h);return r==ESP_OK;
}
int ui_clock_style_load(void) {
    nvs_handle_t h;
    uint8_t style = 0;
    if (nvs_open("aibot_tab5", NVS_READONLY, &h) == ESP_OK) {
        nvs_get_u8(h, "clock_style", &style);
        nvs_close(h);
    }
    return style < UI_CLOCK_STYLES ? style : 0;
}
bool ui_clock_style_save(int style) {
    if (style < 0 || style >= UI_CLOCK_STYLES)
        return false;
    nvs_handle_t h;
    if (nvs_open("aibot_tab5", NVS_READWRITE, &h) != ESP_OK)
        return false;
    esp_err_t result = nvs_set_u8(h, "clock_style", (uint8_t)style);
    if (result == ESP_OK)
        result = nvs_commit(h);
    nvs_close(h);
    return result == ESP_OK;
}
ui_preferences ui_preferences_load(void) {
    ui_preferences p = {.version = 1,
                        .selected = -1,
                        .interval = 15,
                        .saver_minutes = 5,
                        .cycle = true,
                        .alerts = true,
                        .enabled = {1, 1, 1, 1, 1, 1, 1, 0},
                        .order = {0, 1, 2, 3, 4, 5, 6, 7}};
    nvs_handle_t h;
    if (nvs_open("aibot_tab5", NVS_READONLY, &h) != ESP_OK)
        return p;
    ui_preferences candidate;
    size_t length = sizeof(candidate);
    if (nvs_get_blob(h, "ui", &candidate, &length) == ESP_OK && length == sizeof(candidate) && candidate.version == 1 &&
        candidate.selected >= -1 && candidate.selected < 8 && candidate.interval >= 10 && candidate.interval <= 60 &&
        candidate.saver_minutes >= 0 && candidate.saver_minutes <= 60) {
        unsigned seen = 0;
        for (int i = 0; i < 8; i++)
            if (candidate.order[i] < 8)
                seen |= 1u << candidate.order[i];
        if (seen == 255)
            p = candidate;
    }
    nvs_close(h);
    return p;
}
bool ui_preferences_save(const ui_preferences *p) {
    nvs_handle_t h;
    if (nvs_open("aibot_tab5", NVS_READWRITE, &h) != ESP_OK)
        return false;
    esp_err_t r = nvs_set_blob(h, "ui", p, sizeof(*p));
    if (r == ESP_OK)
        r = nvs_commit(h);
    nvs_close(h);
    return r == ESP_OK;
}
