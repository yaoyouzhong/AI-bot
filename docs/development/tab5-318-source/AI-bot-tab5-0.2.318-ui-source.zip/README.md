# TAB5 0.2.318-ui complete project source

This self-contained project snapshot integrates all changes since the published
.313 source, including .314 draft recovery and the accepted 72px controls build.
No older patch overlay is required. Keep the pinned SDK/submodules, dependency
lock, managed-overrides, supplied-art and SDK patches included in this archive.
Read THIRD_PARTY_NOTICES.md and supplied-art/NOTICE.md; authorized companion art
remains outside MIT. Host tools, caches, BIN/ELF and private state are excluded.

Run python verify.py, copy source/ into a clean project, prepare ESP-IDF 5.4.2 at
f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0 with recursive submodules (NimBLE
0225775e49669cd4f070400908f73718bddce83b), apply sdk/esp-idf.patch and
sdk/nimble.patch, resolve dependencies.lock and copy managed-overrides/ into
firmware/managed_components/. Keep the exact firmware/sdkconfig.
Then verify.py --resolved-project <project> --sdk <sdk> verifies resolved inputs.
Build with scripts/build.ps1 -LocalArt -LocalVersion 0.2.318-ui or equivalent
native ESP-IDF arguments. This archive does not perform a rebuild or device flash
and makes no independent bit-identical rebuild claim.

Runtime changes are bound to repository commit 6cc8528608c7e7ceb88fe59aadc171e07a24b33f;
the complete standalone project is represented by the file manifests, not by a
claim that its root was itself a Git checkout. Accepted image SHA-256: fad7d04c5585f222951aa7ac13deb01e8664a2069679d32547fa9f058563e2be.
