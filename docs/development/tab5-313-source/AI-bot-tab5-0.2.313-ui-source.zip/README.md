# TAB5 0.2.313-ui complete project source

This archive contains the full project, exact configuration, tests, generated
companion inputs, dependency metadata, six managed overrides, and SDK patches
covering nine files. It follows the existing .283 source-archive policy: obtain
unchanged dependencies using dependencies.lock and the pinned SDK/submodules,
instead of committing their full installed trees or host toolchains.

Read SOURCE-MANIFEST.json, THIRD_PARTY_NOTICES.md and supplied-art/NOTICE.md.
Codex/Clawd artwork is covered by the recorded owner redistribution authorization
and remains outside MIT. Historical source/README.md is retained verbatim.
The native build was a standalone snapshot: sourceCommit is honestly null.
This source synchronization does not publish or flash a firmware release.

Verify: python verify.py (Python 3.11+). Copy source/ to a clean work directory.
Prepare ESP-IDF 5.4.2 commit f5c3654a1c2d2a01f7f67def7a0dc48e691f63c0
with recursive submodules (NimBLE 0225775e49669cd4f070400908f73718bddce83b).
Apply sdk/esp-idf.patch at the SDK root and sdk/nimble.patch at the NimBLE root.
Keep firmware/sdkconfig; do not reset it with set-target. Configure with
TAB5_LOCAL_ART=ON and TAB5_LOCAL_VERSION=0.2.313-ui; resolve dependencies.lock,
then copy managed-overrides/* into firmware/managed_components/.
Run python verify.py --resolved-project <work-directory> --sdk <sdk-directory>.
Windows builds through scripts/build.ps1 -LocalArt -LocalVersion 0.2.313-ui,
retaining its CPU/priority limits; see scripts/IdfEnvironment.ps1 for tool setup.
Other platforms use the equivalent configured ESP-IDF build.

The archive preserves the accepted project bytes and checks all resolved inputs.
SDK comparison against pinned upstream Git objects found exactly the nine known
modifications; other differences are Windows CRLF line endings. No independent
whole-firmware byte-identical rebuild is claimed. BIN/ELF, credentials, runtime
state, unmodified SDK/dependency trees and installed host tools are not included.

The native .313 acceptance and image hashes come from the Mac handoff.
This archive reconstructs the 25-file delta exactly, without rebuilding or flashing.
