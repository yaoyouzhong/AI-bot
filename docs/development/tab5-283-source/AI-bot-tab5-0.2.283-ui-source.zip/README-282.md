# TAB5 0.2.282-ui — full source snapshot

This archive preserves the public .281 complete source, SDK patch and dependency records, with the three .282 diagnostics UI/test files from the actual local build. `CHANGES-282.json` records the .281 and .282 source hashes; `health-layout-282.patch` is the review patch. Source bytes matched the recorded build tree; a byte-identical independent binary rebuild has not been claimed.

Application SHA-256: `158425cf823886d4ce33fcf718217cc4408d57a9c09b801bf00176f7e6e6265c`
ELF SHA-256: `9836b5616380ab4aba54cb891a4b21bb25c963bd9ab1c3b949fce15f04400cb8`

本包在已公开的 .281 完整源码基础上，替换为实际构建 .282 的三个诊断相关源码／测试文件，保留依赖和 SDK 补丁记录。源码与构建目录逐项核对；未宣称独立逐位重建了相同二进制。

The original .281 README is retained as `README-281.md`. Licenses and third-party notices retain their original terms.

## Rebuild / 重建

Use the pinned ESP-IDF and managed component records in this archive. Preserve the included `source/firmware/sdkconfig` and the .281 resolved dependency overrides; do not use `set-target` to reset it. Resolve the locked dependencies and apply the archived SDK/managed patches. Reconfigure with `idf.py -D TAB5_LOCAL_ART=ON -D TAB5_LOCAL_VERSION=0.2.282-ui reconfigure` in `source/firmware`, then build with the same version configuration. On Windows, the project provides `source/scripts/build.ps1 -LocalArt -LocalVersion 0.2.282-ui`. Compare the generated application SHA-256 with the value above; reproducibility is not assumed.

使用归档中固定的 SDK、锁定依赖和补丁，保留 `sdkconfig`，明确指定 `TAB5_LOCAL_ART=ON` 和 `TAB5_LOCAL_VERSION=0.2.282-ui`；Windows 可用上述项目构建脚本。重建后单独核对镜像哈希。
