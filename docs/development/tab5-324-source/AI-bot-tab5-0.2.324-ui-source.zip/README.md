TAB5 0.2.324-ui R16 corresponding-source archive.

The complete source tree is under source/. It retains the released .323 baseline material, with the exact .324 build inputs from the local TAB5 engineering tree and tested firmware overlay. Use the pinned SDK and NimBLE versions and included patches. The tested application digest is recorded in SOURCE-MANIFEST.json. Independent byte-for-byte rebuilding was not performed.
