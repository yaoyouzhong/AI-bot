#pragma once
#include <stdbool.h>

// Timing counters and sanitized RTOS task names only; no application payload.
// Values are observational snapshots, not a lock-consistent
// trace. Microsecond timestamps wrap after ~71 minutes; compare unsigned deltas.
enum { TAB5_COPY_WINDOW_CAPACITY=96, TAB5_BEFORE_CAPACITY=176 };
void tab5_lcd_render_boundary(bool ending);
void tab5_lcd_rotate_boundary(bool ending);
void tab5_lcd_submit_boundary(bool ending);
void display_diagnostics_format(char *out,unsigned size,char *copy_window,unsigned window_size,char *before,unsigned before_size);
