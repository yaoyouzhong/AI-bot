static bool batch_number(cJSON *body,const char *name,unsigned expected) {
    cJSON *value=cJSON_GetObjectItemCaseSensitive(body,name);
    return cJSON_IsNumber(value)&&value->valuedouble==expected;
}
static unsigned batch_size(cJSON *body,const char *name,unsigned maximum) {
    cJSON *value=cJSON_GetObjectItemCaseSensitive(body,name);
    return cJSON_IsNumber(value)&&value->valuedouble==value->valueint&&value->valueint>0&&
        (unsigned)value->valueint<=maximum?(unsigned)value->valueint:0;
}
static void batch_sha(const uint8_t *data,size_t size,char out[65]) {
    uint8_t hash[32];mbedtls_sha256(data,size,hash,0);
    for(unsigned i=0;i<32;i++)sprintf(out+i*2,"%02x",hash[i]);
}
static int batch_base(int category,const char *target,unsigned works,const char *images,cJSON *sources,char previous[65],uint8_t **hashes) {
    if(!sd_storage_lock())return -1;
    gallery_catalog active={0};
    if(gallery_catalog_load(SD_STORAGE_MOUNT,category,"",&active)&&strcmp(active.revision,target)&&
       active.works==works&&active.next==works) {
        *hashes=heap_caps_malloc(works*32u,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
        if(*hashes&&gallery_guide_batch_summary(SD_STORAGE_MOUNT,category,active.revision,images,*hashes,works))
            memcpy(previous,active.revision,65);
        else {free(*hashes);*hashes=NULL;}
    }
    if(!previous[0]) {
        cJSON *source;
        cJSON_ArrayForEach(source,sources) {
            const char *candidate=cJSON_GetStringValue(source);
            if(candidate&&strcmp(candidate,target)&&gallery_catalog_completed(SD_STORAGE_MOUNT,category,candidate,works)){
                memcpy(previous,candidate,65);break;
            }
        }
    }
    bool usable=previous[0]&&gallery_guide_delta_can_link(SD_STORAGE_MOUNT,category,previous);
    sd_storage_unlock(gallery_store_media_error());
    if(!usable){free(*hashes);*hashes=NULL;}
    return usable?1:0;
}
static bool batch_link_preempted(link_kind transport) {
    return transport==LINK_USB&&rpc_library_link_select()==LINK_WIFI;
}
static bool batch_upload_summary(link_kind transport,void *http,cJSON *request,const uint8_t *hashes,unsigned works,char sha[65]) {
    unsigned total=works*32u;
    batch_sha(hashes,total,sha);
    cJSON_ReplaceItemInObjectCaseSensitive(request,"op",cJSON_CreateString("guideSummary"));
    cJSON_AddStringToObject(request,"sha256",sha);
    unsigned limit=rpc_data_limit(transport);
    for(unsigned at=0;at<total;) {
        if(download_cancelled(transport,true)||batch_link_preempted(transport))return false;
        unsigned count=total-at;if(count>limit)count=limit;
        cJSON_DeleteItemFromObjectCaseSensitive(request,"offset");cJSON_AddNumberToObject(request,"offset",at);
        int status=0;char nonce[33];
        cJSON *reply=rpc_data_call(transport,http,request,&status,nonce,hashes+at,count,NULL,0,NULL);
        bool ok=status==200&&batch_number(reply,"offset",at)&&batch_number(reply,"count",count);
        cJSON_Delete(reply);
        if(!ok)return false;
        at+=count;
    }
    cJSON_DeleteItemFromObjectCaseSensitive(request,"sha256");
    cJSON_AddStringToObject(request,"summarySha",sha);
    return true;
}
static bool batch_receive(link_kind transport,void *http,cJSON *request,uint8_t *data,unsigned bytes) {
    cJSON_ReplaceItemInObjectCaseSensitive(request,"op",cJSON_CreateString("guideBatchRead"));
    bool stream=transport==LINK_WIFI&&rpc_gallery_stream_ready();
    unsigned limit=stream?bytes:rpc_data_limit(transport);
    for(unsigned at=0;at<bytes;) {
        if(download_cancelled(transport,true)||batch_link_preempted(transport))return false;
        unsigned count=bytes-at;if(count>limit)count=limit;
        cJSON_DeleteItemFromObjectCaseSensitive(request,"offset");cJSON_AddNumberToObject(request,"offset",at);
        cJSON_DeleteItemFromObjectCaseSensitive(request,"count");cJSON_AddNumberToObject(request,"count",count);
        int status=0;size_t got=0;char nonce[33];
        cJSON *reply;
        if(stream)reply=rpc_gallery_stream_call(http,request,&status,nonce,data+at,count,&got,NULL,NULL);
        else if(transport==LINK_USB) {
            // Return to the scheduler after one failed USB range so it can
            // select the now-ready Wi-Fi link before issuing another request.
            reply=rpc_data_call(transport,http,request,&status,nonce,NULL,0,data+at,count,&got);
        }else reply=gallery_call(transport,true,http,request,&status,data+at,count,&got);
        bool ok=status==200&&got==count&&batch_number(reply,"offset",at);
        cJSON_Delete(reply);
        if(!ok)return false;
        at+=count;
    }
    return true;
}
static __attribute__((noinline)) int sync_guide_batch(int category,const char *revision,unsigned works,cJSON *catalog,link_kind transport,void *http,cJSON *request) {
    const char *images=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(catalog,"imageRevision"));
    if(!images||strlen(images)!=64)return 0;
    int64_t began=esp_timer_get_time();
    char previous[65]={0};uint8_t *hashes=NULL;
    int base=batch_base(category,revision,works,images,cJSON_GetObjectItemCaseSensitive(catalog,"deltaSources"),previous,&hashes);
    if(base<=0)return base;
    if(batch_link_preempted(transport)){free(hashes);return -1;}
    atomic_store(&library_saving,true);
    cJSON_AddStringToObject(request,"from",previous);
    cJSON_AddStringToObject(request,"revision",revision);
    cJSON_AddStringToObject(request,"imageRevision",images);
    char sha[65];
    bool ready=!hashes||batch_upload_summary(transport,http,request,hashes,works,sha);
    free(hashes);
    if(!ready)return -1;
    cJSON_ReplaceItemInObjectCaseSensitive(request,"op",cJSON_CreateString("guideBatch"));
    int status=0;
    cJSON *plan=gallery_call(transport,true,http,request,&status,NULL,0,NULL);
    unsigned bytes=batch_size(plan,"bytes",1048576),decoded=batch_size(plan,"decoded",3u*1024u*1024u);
    unsigned changed=batch_size(plan,"changed",works);
    const char *digest=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(plan,"sha"));
    const char *from=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(plan,"from"));
    const char *to=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(plan,"revision"));
    bool ok=status==200&&bytes&&decoded&&digest&&strlen(digest)==64&&from&&!strcmp(from,previous)&&
        to&&!strcmp(to,revision)&&batch_number(plan,"works",works)&&batch_number(plan,"changed",changed);
    if(ok)cJSON_AddStringToObject(request,"sha256",digest);
    uint8_t *packed=ok?heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT):NULL;
    int64_t receiving=esp_timer_get_time();
    ok=packed&&batch_receive(transport,http,request,packed,bytes);
    unsigned rx_ms=(esp_timer_get_time()-receiving)/1000;
    if(ok){batch_sha(packed,bytes,sha);ok=!strcmp(sha,digest);}
    cJSON_Delete(plan);
    uint8_t *plain=ok?heap_caps_malloc(decoded,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT):NULL;
    tinfl_decompressor *inflater=plain?heap_caps_malloc(sizeof(*inflater),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT):NULL;
    ok=inflater!=NULL;
    if(ok){
        size_t in=bytes,out=decoded;tinfl_init(inflater);
        ok=tinfl_decompress(inflater,packed,&in,plain,plain,&out,TINFL_FLAG_PARSE_ZLIB_HEADER|TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF)
            ==TINFL_STATUS_DONE&&in==bytes&&out==decoded&&decoded>=140&&!memcmp(plain+12,previous,64)&&!memcmp(plain+76,images,64);
    }
    free(inflater);free(packed);
    unsigned write_ms=0;
    if(ok&&!download_cancelled(transport,true)&&sd_storage_lock()){
        int64_t writing=esp_timer_get_time();
        ok=gallery_guide_batch_save(SD_STORAGE_MOUNT,category,revision,plain,decoded,works,changed)&&
            gallery_guide_delta_link(SD_STORAGE_MOUNT,category,revision,previous);
        write_ms=(esp_timer_get_time()-writing)/1000;
        sd_storage_unlock(gallery_store_media_error());
    }else ok=false;
    free(plain);
    if(ok){
        atomic_store(&guide_batch_bytes[category],bytes);atomic_store(&guide_batch_rx_ms[category],rx_ms);
        atomic_store(&guide_batch_write_ms[category],write_ms);
        atomic_store(&guide_batch_total_ms[category],(unsigned)((esp_timer_get_time()-began)/1000));
    }
    return ok?1:status==409?0:-1;
}
