#include "screen_preview.h"
#include "display_diagnostics.h"
#include "scanout_history.h"
#include "display_bandwidth.h"
#include "photo_display_probe.h"
#include "draw_orthogonal.h"
#include "crash_record.h"
#include "esp_attr.h"
#include "soc/mipi_dsi_bridge_struct.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

volatile unsigned tab5_lcd_underruns;
extern volatile int tab5_ui_page;
extern volatile int tab5_saver_active;
static volatile unsigned underrun_sequence, underrun_us, underrun_location, underrun_stages;
static volatile uint32_t frame_count, frame_previous_us, frame_peak_us;
static volatile unsigned copy_active,copy_started,copy_finished,copy_pixels,copy_count;
static volatile unsigned copy_dma_burst=16;
void tab5_lcd_cpu_copy_enable(void){copy_dma_burst=0;}
static volatile unsigned copy_sequence,copy_begin_frame,copy_begin_latch,copy_end_frame,copy_end_latch;
static volatile unsigned underrun_copy_valid,underrun_read_frame;
static volatile unsigned underrun_begin_frame,underrun_begin_latch,underrun_end_frame,underrun_end_latch;
static volatile unsigned underrun_copy_active,underrun_copy_start_age,underrun_copy_end_age,underrun_copy_pixels;
static tab5_history copy_history,ui_history;
static unsigned history_sequence,history_fault_count,history_used;
static tab5_history_event history_fault[TAB5_HISTORY_MAX_EVENTS];

// A sticky DSI flag is sampled, never cleared here. A frame callback
// crossing a boundary makes that boundary ambiguous rather than "clear".
static inline __attribute__((always_inline)) unsigned copy_latch_sample(volatile unsigned *frame) {
    unsigned before=frame_count;
    unsigned latched=MIPI_DSI_BRIDGE.int_raw.underrun_int_raw;
    *frame=before;
    return before==frame_count?latched:2u;
}

static inline __attribute__((always_inline)) void ui_mark(unsigned kind) {
    unsigned frame,latch=copy_latch_sample(&frame);
    tab5_history_mark(&ui_history,kind,frame,latch,(unsigned)esp_timer_get_time());
}
void tab5_lcd_render_boundary(bool ending) { ui_mark(ending?TAB5_HISTORY_RENDER_END:TAB5_HISTORY_RENDER_BEGIN); }
void tab5_lcd_rotate_boundary(bool ending) { ui_mark(ending?TAB5_HISTORY_ROTATE_END:TAB5_HISTORY_ROTATE_BEGIN); }
void tab5_lcd_submit_boundary(bool ending) { ui_mark(ending?TAB5_HISTORY_SUBMIT_END:TAB5_HISTORY_SUBMIT_BEGIN); }

void IRAM_ATTR tab5_lcd_copy_begin(unsigned pixels) {
    copy_sequence++;
    __asm__ volatile("fence rw,rw" ::: "memory");
    copy_begin_latch=copy_latch_sample(&copy_begin_frame);
    copy_end_frame=0;copy_end_latch=2;
    copy_started=(unsigned)esp_timer_get_time();copy_pixels=pixels;copy_count++;copy_active=1;
    tab5_history_mark(&copy_history,TAB5_HISTORY_COPY_BEGIN,copy_begin_frame,copy_begin_latch,copy_started);
    __asm__ volatile("fence rw,rw" ::: "memory");
    copy_sequence++;
}
void IRAM_ATTR tab5_lcd_copy_end(void) {
    copy_sequence++;
    __asm__ volatile("fence rw,rw" ::: "memory");
    copy_end_latch=copy_latch_sample(&copy_end_frame);
    copy_finished=(unsigned)esp_timer_get_time();copy_active=0;
    tab5_history_mark(&copy_history,TAB5_HISTORY_COPY_END,copy_end_frame,copy_end_latch,copy_finished);
    __asm__ volatile("fence rw,rw" ::: "memory");
    copy_sequence++;
}

void IRAM_ATTR tab5_lcd_underrun(void) {
    underrun_sequence++;
    __asm__ volatile("fence rw,rw" ::: "memory");
    underrun_us=(unsigned)esp_timer_get_time();
    underrun_location=((unsigned)tab5_ui_page&255u)|((unsigned)(tab5_saver_active!=0)<<8);
    underrun_stages=crash_record_runtime_display_stages();
    // The LCD callback can interrupt either copy hook. Never spin in the ISR.
    unsigned seq=copy_sequence;
    __asm__ volatile("fence rw,rw" ::: "memory");
    underrun_read_frame=frame_count;
    underrun_copy_active=copy_active;
    underrun_copy_start_age=underrun_us-copy_started;
    underrun_copy_end_age=underrun_us-copy_finished;
    underrun_copy_pixels=copy_pixels;
    underrun_begin_frame=copy_begin_frame;underrun_begin_latch=copy_begin_latch;
    underrun_end_frame=copy_end_frame;underrun_end_latch=copy_end_latch;
    __asm__ volatile("fence rw,rw" ::: "memory");
    underrun_copy_valid=seq&&!(seq&1u)&&seq==copy_sequence;
    tab5_lcd_underruns++;
    __asm__ volatile("fence rw,rw" ::: "memory");
    underrun_sequence++;
}

// Called only on a fault, after the DMA is already rearmed. Copy at most
// four copy marks and eight LVGL marks; do not wait, allocate or log.
void IRAM_ATTR tab5_lcd_capture_before(void) {
    tab5_history_event snapshot[TAB5_HISTORY_MAX_EVENTS];
    unsigned used=tab5_history_collect(&copy_history,underrun_us,underrun_read_frame,snapshot,4);
    used+=tab5_history_collect(&ui_history,underrun_us,underrun_read_frame,snapshot+used,8);
    unsigned seq=__atomic_load_n(&history_sequence,__ATOMIC_RELAXED);
    __atomic_store_n(&history_sequence,seq+1,__ATOMIC_RELAXED);
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    __atomic_store_n(&history_used,used,__ATOMIC_RELAXED);
    __atomic_store_n(&history_fault_count,tab5_lcd_underruns,__ATOMIC_RELAXED);
    for(unsigned i=0;i<used;i++) {
        __atomic_store_n(&history_fault[i].tag,snapshot[i].tag,__ATOMIC_RELAXED);
        __atomic_store_n(&history_fault[i].frame_age,snapshot[i].frame_age,__ATOMIC_RELAXED);
        __atomic_store_n(&history_fault[i].age_us,snapshot[i].age_us,__ATOMIC_RELAXED);
    }
    __atomic_store_n(&history_sequence,seq+2,__ATOMIC_RELEASE);
}

static volatile uint32_t frame_gap_count, frame_gap_at_us;
static volatile uint32_t flash_count, flash_start_us, flash_peak_us, flash_end_us;
static volatile uint32_t watchdog_count, watchdog_at_us;
static char watchdog_task[2][configMAX_TASK_NAME_LEN];
extern volatile unsigned tab5_display_wait_us, tab5_display_wait_peak_us;
extern volatile unsigned tab5_lvgl_handler_us, tab5_lvgl_handler_peak_us;
extern volatile unsigned tab5_display_render_us, tab5_display_frame_flush_us, tab5_display_frame_rotate_us;
extern volatile unsigned tab5_draw_image_us, tab5_draw_fill_us, tab5_draw_label_us, tab5_draw_blend_us;
extern volatile unsigned tab5_full_image_frames;
extern volatile unsigned tab5_ppa_fills,tab5_ppa_errors,tab5_ppa_ready;
extern volatile unsigned tab5_rotate_choice,tab5_rotate_baseline_us,tab5_rotate_candidate_us;
extern volatile unsigned tab5_ui_internal_buffer_bytes,tab5_ui_internal_free;
extern volatile unsigned tab5_cache_hits,tab5_cache_builds,tab5_cache_bytes;
extern volatile unsigned tab5_native_cache_hits,tab5_native_cache_bytes;
extern volatile unsigned tab5_cache_snapshot_count,tab5_native_snapshot_count,tab5_cache_restart_count;
extern volatile unsigned tab5_display_large_frames,tab5_display_large_us,tab5_display_large_peak_us;
extern volatile unsigned tab5_display_large_total_ms,tab5_display_large_pixels,tab5_display_large_period_us;
extern volatile unsigned tab5_copy_choice,tab5_copy_baseline_us,tab5_copy_candidate_us;
extern volatile unsigned tab5_display_large_flush_us,tab5_display_large_rotate_us;
extern volatile unsigned tab5_display_large_copy_us,tab5_display_large_wait_us,tab5_display_large_yield_us;
extern volatile unsigned tab5_display_large_parts,tab5_display_large_native_parts;
extern volatile unsigned tab5_gallery_reader_clicks,tab5_gallery_reader_guide_us,tab5_gallery_reader_layout_us,tab5_gallery_reader_paint_us;

// IDF's non-panic watchdog prints from an ISR every 5 seconds if a core is
// starved. Record whether those warnings coincide with the observed flashes;
// do not feed, disable, reconfigure, or suppress the watchdog.
void esp_task_wdt_isr_user_handler(void) {
    watchdog_count++;
    watchdog_at_us = (uint32_t)esp_timer_get_time();
    for (unsigned core = 0; core < 2; ++core) {
        const char *name = pcTaskGetName(xTaskGetCurrentTaskHandleForCore(core));
        unsigned i = 0;
        for (; name[i] && i + 1 < sizeof(watchdog_task[core]); ++i) {
            char c = name[i];
            watchdog_task[core][i] = ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                                     (c >= '0' && c <= '9') || c == '_') ? c : '_';
        }
        watchdog_task[core][i] = 0;
    }
}

// Called from the DPI DMA ISR before its normal rearm. No allocation, logging,
// RTOS calls, or flash-resident data may be used here or in the flash hooks.
void IRAM_ATTR tab5_lcd_frame_tick(void) {
    uint32_t now = (uint32_t)esp_timer_get_time();
    if (frame_count) {
        uint32_t gap = now - frame_previous_us;
        if (gap > frame_peak_us) frame_peak_us = gap;
        if (gap > 50000) { frame_gap_count++; frame_gap_at_us = now; }
    }
    frame_previous_us = now;
    frame_count++;
    photo_display_probe_frame(now);
}

void IRAM_ATTR tab5_flash_guard_begin(void) {
    crash_record_checkpoint(RUNTIME_FLASH,1,0);
    flash_start_us = (uint32_t)esp_timer_get_time();
    flash_count++;
}

void IRAM_ATTR tab5_flash_guard_end(void) {
    uint32_t now = (uint32_t)esp_timer_get_time();
    uint32_t duration = now - flash_start_us;
    if (duration > flash_peak_us) flash_peak_us = duration;
    flash_end_us = now;
    crash_record_checkpoint(RUNTIME_FLASH,0,0);
}

static void format_before(char *out,unsigned size,unsigned count) {
    unsigned seq=__atomic_load_n(&history_sequence,__ATOMIC_ACQUIRE);
    if(!seq||(seq&1u)||__atomic_load_n(&history_fault_count,__ATOMIC_RELAXED)!=count)return;
    unsigned used=__atomic_load_n(&history_used,__ATOMIC_RELAXED);
    if(!used||used>TAB5_HISTORY_MAX_EVENTS)return;
    int n=snprintf(out,size,";before,1,%u",count);
    if(n<=0||(unsigned)n>=size){out[0]=0;return;}
    unsigned offset=(unsigned)n;
    for(unsigned i=0;i<used;i++) {
        n=snprintf(out+offset,size-offset,",%u,%u,%u",
            __atomic_load_n(&history_fault[i].tag,__ATOMIC_RELAXED),
            __atomic_load_n(&history_fault[i].frame_age,__ATOMIC_RELAXED),
            __atomic_load_n(&history_fault[i].age_us,__ATOMIC_RELAXED));
        if(n<=0||(unsigned)n>=size-offset){out[0]=0;return;}
        offset+=(unsigned)n;
    }
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    if(seq!=__atomic_load_n(&history_sequence,__ATOMIC_ACQUIRE))out[0]=0;
}

void display_diagnostics_format(char *out,unsigned size,char *copy_window,unsigned window_size,char *before,unsigned before_size) {
    if(copy_window&&window_size)copy_window[0]=0;
    if(before&&before_size)before[0]=0;
    snprintf(out, size, "%u,%u,%u,%u,%u,%u,%u,%u,%u,%s,%s,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u", (unsigned)frame_count,
             (unsigned)frame_peak_us, (unsigned)frame_gap_count, (unsigned)frame_gap_at_us,
             (unsigned)flash_count, (unsigned)flash_peak_us, (unsigned)flash_end_us,
             (unsigned)watchdog_count, (unsigned)watchdog_at_us, watchdog_task[0], watchdog_task[1],
             tab5_display_wait_us, tab5_display_wait_peak_us, tab5_lvgl_handler_us, tab5_lvgl_handler_peak_us,
             tab5_display_render_us, tab5_display_frame_flush_us, tab5_display_frame_rotate_us,
             tab5_draw_image_us,tab5_draw_fill_us,tab5_draw_label_us,tab5_draw_blend_us,tab5_full_image_frames,
             tab5_ppa_fills,tab5_ppa_errors,tab5_ppa_ready,
             tab5_rotate_choice,tab5_rotate_baseline_us,tab5_rotate_candidate_us,
             tab5_cache_hits,tab5_cache_builds,tab5_cache_bytes,
             tab5_display_large_frames,tab5_display_large_us,tab5_display_large_peak_us,
             tab5_display_large_total_ms,tab5_display_large_pixels,tab5_display_large_period_us);
    unsigned used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,",%u,%u,%u,%u,%u,%u,%u",tab5_copy_choice,tab5_copy_baseline_us,tab5_copy_candidate_us,
        tab5_display_large_flush_us,tab5_display_large_rotate_us,tab5_ui_internal_buffer_bytes,tab5_ui_internal_free);
    used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,",%u,%u",tab5_native_cache_hits,tab5_native_cache_bytes);
    used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,",%u,%u,%u,%u,%u",tab5_display_large_copy_us,
        tab5_display_large_wait_us,tab5_display_large_yield_us,tab5_display_large_parts,tab5_display_large_native_parts);
    used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,",%u,%u,%u,%u",tab5_cache_snapshot_count,
        tab5_native_snapshot_count,tab5_cache_restart_count,(unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    used=(unsigned)strlen(out);
    if(used+1<size){out[used++]=',';crash_record_previous_runtime(out+used,size-used);}
    used=(unsigned)strlen(out);
    // Optional versioned suffix; preserve every earlier field and crash record.
    if(used<size)snprintf(out+used,size-used,";ortho,1,%u,%u,%u,%u",tab5_orthogonal_calls,
        tab5_orthogonal_pixels,tab5_orthogonal_us,tab5_orthogonal_peak_us);
    used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,";reader,1,%u,%u,%u,%u",tab5_gallery_reader_clicks,
        tab5_gallery_reader_guide_us,tab5_gallery_reader_layout_us,tab5_gallery_reader_paint_us);
    used=(unsigned)strlen(out);
    if(used+1<size){out[used++]=';';display_bandwidth_format(out+used,size-used);}
    used=(unsigned)strlen(out);
    if(used+1<size){out[used++]=';';screen_preview_diagnostics(out+used,size-used);}
    used=(unsigned)strlen(out);
    extern volatile unsigned tab5_asset_copy_failures,tab5_asset_copy_reclaimed,tab5_asset_copy_recoveries;
    extern volatile unsigned tab5_asset_receive_alloc_failures,tab5_asset_crc_failures,tab5_asset_decode_failures,tab5_asset_received;
    if(used<size)snprintf(out+used,size-used,";asset,2,%u,%u,%u,%u,%u,%u,%u",tab5_asset_copy_failures,tab5_asset_copy_reclaimed,tab5_asset_copy_recoveries,tab5_asset_receive_alloc_failures,tab5_asset_crc_failures,tab5_asset_decode_failures,tab5_asset_received);
    used=(unsigned)strlen(out);
    extern void tab5_pinyin_diagnostics(char *,size_t);
    char ime[128];tab5_pinyin_diagnostics(ime,sizeof(ime));
    if(used<size)snprintf(out+used,size-used,";ime,%s,%u",ime,(unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    used=(unsigned)strlen(out);
    if(used<size)snprintf(out+used,size-used,";copy,1,%u,%u,%u",(unsigned)copy_dma_burst,(unsigned)copy_active,(unsigned)copy_count);
    used=(unsigned)strlen(out);
    unsigned sequence=underrun_sequence;
    if(used<size&&frame_count)snprintf(out+used,size-used,";fifo,1,%u,%u,%u",
        (unsigned)MIPI_DSI_BRIDGE.raw_buf_almost_empty_thrd.dsi_raw_buf_almost_empty_thrd,
        (unsigned)MIPI_DSI_BRIDGE.dma_req_cfg.dma_burst_len,
        (unsigned)MIPI_DSI_BRIDGE.dpi_misc_config.fifo_underrun_discard_vcnt);
    used=(unsigned)strlen(out);
    if(used<size&&sequence&&!(sequence&1u)) {
        __asm__ volatile("fence rw,rw" ::: "memory");
        unsigned count=tab5_lcd_underruns,at=underrun_us,location=underrun_location,stages=underrun_stages;
        unsigned active=underrun_copy_active,start_age=underrun_copy_start_age,end_age=underrun_copy_end_age,pixels=underrun_copy_pixels;
        unsigned valid=underrun_copy_valid,frame=underrun_read_frame;
        unsigned begin_frame=underrun_begin_frame,begin_latch=underrun_begin_latch,end_frame=underrun_end_frame,end_latch=underrun_end_latch;
        __asm__ volatile("fence rw,rw" ::: "memory");
        if(sequence==underrun_sequence) {
            int wrote=snprintf(out+used,size-used,";lcd,1,%u,%u,%u,%u,%u;copyfault,1,%u,%u,%u,%u",count,at,location&255u,location>>8,stages,active,start_age,end_age,pixels);
            if(wrote>0&&(unsigned)wrote<size-used&&copy_window&&window_size) {
                int len=snprintf(copy_window,window_size,";copywindow,1,%u,%u,%u,%u,%u,%u",
                    valid,frame,begin_frame,begin_latch,end_frame,end_latch);
                if(len<=0||(unsigned)len>=window_size)copy_window[0]=0;
            }
            if(wrote>0&&(unsigned)wrote<size-used&&before&&before_size)format_before(before,before_size,count);
        }
    }

}
